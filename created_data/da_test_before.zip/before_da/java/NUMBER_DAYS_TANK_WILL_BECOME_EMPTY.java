import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class NUMBER_DAYS_TANK_WILL_BECOME_EMPTY{
static int f_gold ( int C , int l ) {
  if ( l >= C ) return C ;
  double eq_root = ( Math . sqrt ( 1 + 8 * ( C - l ) ) - 1 ) / 2 ;
  return ( int ) ( Math . ceil ( eq_root ) + l ) ;
}
public static void main(String args[]) {
f_gold(91,29);
}
}