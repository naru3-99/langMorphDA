import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class COUNT_NUMBER_OF_OCCURRENCES_OR_FREQUENCY_IN_A_SORTED_ARRAY{
static int f_gold ( int arr [ ] , int n , int x ) {
  int res = 0 ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) if ( x == arr [ i ] ) res ++ ;
  return res ;
}
public static void main(String args[]) {
f_gold(new int[]{16,18,24,27,34,36,41,43,43,52,59,76,86,87,90,91,94,96,98,98},14,43);
}
}