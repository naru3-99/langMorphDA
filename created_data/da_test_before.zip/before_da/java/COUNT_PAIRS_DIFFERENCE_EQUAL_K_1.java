import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class COUNT_PAIRS_DIFFERENCE_EQUAL_K_1{
static int f_gold ( int arr [ ] , int n , int k ) {
  int count = 0 ;
  Arrays . sort ( arr ) ;
  int l = 0 ;
  int r = 0 ;
  while ( r < n ) {
    if ( arr [ r ] - arr [ l ] == k ) {
      count ++ ;
      l ++ ;
      r ++ ;
    }
    else if ( arr [ r ] - arr [ l ] > k ) l ++ ;
    else r ++ ;
  }
  return count ;
}
public static void main(String args[]) {
f_gold(new int[]{5,5,10,19,29,32,40,60,65,70,72,89,92},7,12);
}
}