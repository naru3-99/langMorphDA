import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class FIND_SUM_MODULO_K_FIRST_N_NATURAL_NUMBER{
static int f_gold ( int N , int K ) {
  int ans = 0 ;
  for ( int i = 1 ;
  i <= N ;
  i ++ ) ans += ( i % K ) ;
  return ans ;
}
public static void main(String args[]) {
f_gold(11,5);
}
}