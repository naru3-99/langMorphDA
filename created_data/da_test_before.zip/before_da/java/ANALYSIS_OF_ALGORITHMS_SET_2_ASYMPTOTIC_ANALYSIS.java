import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class ANALYSIS_OF_ALGORITHMS_SET_2_ASYMPTOTIC_ANALYSIS{
static int f_gold ( int arr [ ] , int n , int x ) {
  int i ;
  for ( i = 0 ;
  i < n ;
  i ++ ) {
    if ( arr [ i ] == x ) {
      return i ;
    }
  }
  return - 1 ;
}
public static void main(String args[]) {
f_gold(new int[]{4,5,5,11,13,14,15,19,22,22,23,26,29,29,36,44,48,49,65,65,67,68,70,76,79,79,81,85,88,91,91,92,92,97},17,5);
}
}