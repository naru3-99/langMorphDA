import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class FIND_ONE_EXTRA_CHARACTER_STRING_1{
static char f_gold ( String strA , String strB ) {
  int res = 0 , i ;
  for ( i = 0 ;
  i < strA . length ( ) ;
  i ++ ) {
    res ^= strA . charAt ( i ) ;
  }
  for ( i = 0 ;
  i < strB . length ( ) ;
  i ++ ) {
    res ^= strB . charAt ( i ) ;
  }
  return ( ( char ) ( res ) ) ;
}
public static void main(String args[]) {
f_gold("obfLA mmMYvghH","obfLA mmMYvghH");
}
}