import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class CHECK_TWO_GIVEN_CIRCLES_TOUCH_INTERSECT{
static int f_gold ( int x1 , int y1 , int x2 , int y2 , int r1 , int r2 ) {
  int distSq = ( x1 - x2 ) * ( x1 - x2 ) + ( y1 - y2 ) * ( y1 - y2 ) ;
  int radSumSq = ( r1 + r2 ) * ( r1 + r2 ) ;
  if ( distSq == radSumSq ) return 1 ;
  else if ( distSq > radSumSq ) return - 1 ;
  else return 0 ;
}
public static void main(String args[]) {
f_gold(11,36,62,64,50,4);
}
}