import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MAXIMUM_NUMBER_OF_SQUARES_THAT_CAN_BE_FIT_IN_A_RIGHT_ANGLE_ISOSCELES_TRIANGLE{
static int f_gold ( int b , int m ) {
  return ( b / m - 1 ) * ( b / m ) / 2 ;
}
public static void main(String args[]) {
f_gold(40,74);
}
}