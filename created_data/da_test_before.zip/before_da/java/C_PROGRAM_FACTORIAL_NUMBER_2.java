import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class C_PROGRAM_FACTORIAL_NUMBER_2{
static int f_gold ( int n ) {
  return ( n == 1 || n == 0 ) ? 1 : n * f_gold ( n - 1 ) ;
}
public static void main(String args[]) {
f_gold(66);
}
}