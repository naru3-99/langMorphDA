import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class GIVEN_A_SORTED_AND_ROTATED_ARRAY_FIND_IF_THERE_IS_A_PAIR_WITH_A_GIVEN_SUM{
static boolean f_gold ( int arr [ ] , int n , int x ) {
  int i ;
  for ( i = 0 ;
  i < n - 1 ;
  i ++ ) if ( arr [ i ] > arr [ i + 1 ] ) break ;
  int l = ( i + 1 ) % n ;
  int r = i ;
  while ( l != r ) {
    if ( arr [ l ] + arr [ r ] == x ) return true ;
    if ( arr [ l ] + arr [ r ] < x ) l = ( l + 1 ) % n ;
    else r = ( n + r - 1 ) % n ;
  }
  return false ;
}
public static void main(String args[]) {
f_gold(new int[]{3,8,10,15,18,19,20,20,21,22,26,30,32,34,43,45,50,50,51,52,53,56,57,58,62,63,65,82,86,91,91,92,92,93,97},17,30);
}
}