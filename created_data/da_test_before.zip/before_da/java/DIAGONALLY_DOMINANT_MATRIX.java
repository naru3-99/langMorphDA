import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class DIAGONALLY_DOMINANT_MATRIX{
static boolean f_gold ( int m [ ] [ ] , int n ) {
  for ( int i = 0 ;
  i < n ;
  i ++ ) {
    int sum = 0 ;
    for ( int j = 0 ;
    j < n ;
    j ++ ) sum += Math . abs ( m [ i ] [ j ] ) ;
    sum -= Math . abs ( m [ i ] [ i ] ) ;
    if ( Math . abs ( m [ i ] [ i ] ) < sum ) return false ;
  }
  return true ;
}
public static void main(String args[]) {
f_gold(new int[][]{ new int[] {3, -2, 1,}, new int[] {1 -3, 2}, new int[] {-1, 2, 4}},2);
}
}