import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class HOW_TO_CHECK_IF_A_GIVEN_ARRAY_REPRESENTS_A_BINARY_HEAP{
static boolean f_gold ( int arr [ ] , int i , int n ) {
  if ( i > ( n - 2 ) / 2 ) {
    return true ;
  }
  if ( arr [ i ] >= arr [ 2 * i + 1 ] && arr [ i ] >= arr [ 2 * i + 2 ] && f_gold ( arr , 2 * i + 1 , n ) && f_gold ( arr , 2 * i + 2 , n ) ) {
    return true ;
  }
  return false ;
}
public static void main(String args[]) {
f_gold(new int[]{1,2,3,5,24,24,25,25,36,37,37,39,42,44,46,50,51,54,56,60,62,70,71,73,75,80,80,85,86,89,91,95,99},0,18);
}
}