import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class FIND_SUBARRAY_WITH_GIVEN_SUM{
static int f_gold ( int arr [ ] , int n , int sum ) {
  int curr_sum , i , j ;
  for ( i = 0 ;
  i < n ;
  i ++ ) {
    curr_sum = arr [ i ] ;
    for ( j = i + 1 ;
    j <= n ;
    j ++ ) {
      if ( curr_sum == sum ) {
        int p = j - 1 ;
        System . out . println ( "Sum found between indexes " + i + " and " + p ) ;
        return 1 ;
      }
      if ( curr_sum > sum || j == n ) break ;
      curr_sum = curr_sum + arr [ j ] ;
    }
  }
  System . out . println ( "No subarray found" ) ;
  return 0 ;
}
public static void main(String args[]) {
f_gold(new int[]{4,8,8,10,15,18,19,22,25,26,30,32,35,36,40,41,43,48,53,57,59,63,64,68,71,76,76,77,78,89,96,97},26,23);
}
}