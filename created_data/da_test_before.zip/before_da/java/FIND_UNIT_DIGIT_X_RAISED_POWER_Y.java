import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class FIND_UNIT_DIGIT_X_RAISED_POWER_Y{
static int f_gold ( int x , int y ) {
  int res = 1 ;
  for ( int i = 0 ;
  i < y ;
  i ++ ) res = ( res * x ) % 10 ;
  return res ;
}
public static void main(String args[]) {
f_gold(33,55);
}
}