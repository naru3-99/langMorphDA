import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class PROBABILITY_THREE_RANDOMLY_CHOSEN_NUMBERS_AP{
static double f_gold ( int n ) {
  return ( 3.0 * n ) / ( 4.0 * ( n * n ) - 1 ) ;
}
public static void main(String args[]) {
f_gold(46);
}
}