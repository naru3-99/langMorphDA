import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class EFFICIENT_SEARCH_IN_AN_ARRAY_WHERE_DIFFERENCE_BETWEEN_ADJACENT_IS_1{
static int f_gold ( int arr [ ] , int n , int x ) {
  int i = 0 ;
  while ( i <= n - 1 ) {
    if ( arr [ i ] == x ) return i ;
    i += Math . abs ( arr [ i ] - x ) ;
  }
  return - 1 ;
}
public static void main(String args[]) {
f_gold(new int[]{5, 4, 5, 6, 5, 4, 3, 2},8,6);
}
}