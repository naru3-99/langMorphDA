import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class DIVISIBILITY_9_USING_BITWISE_OPERATORS{
static boolean f_gold ( int n ) {
  if ( n == 0 || n == 9 ) return true ;
  if ( n < 9 ) return false ;
  return f_gold ( ( int ) ( n >> 3 ) - ( int ) ( n & 7 ) ) ;
}
public static void main(String args[]) {
f_gold(96);
}
}