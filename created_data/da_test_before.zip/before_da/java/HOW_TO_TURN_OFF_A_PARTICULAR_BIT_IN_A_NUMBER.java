import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class HOW_TO_TURN_OFF_A_PARTICULAR_BIT_IN_A_NUMBER{
static int f_gold ( int n , int k ) {
  if ( k <= 0 ) return n ;
  return ( n & ~ ( 1 << ( k - 1 ) ) ) ;
}
public static void main(String args[]) {
f_gold(49,15);
}
}