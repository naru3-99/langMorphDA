import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class CEILING_IN_A_SORTED_ARRAY_1{
static int f_gold ( int arr [ ] , int low , int high , int x ) {
  int mid ;
  if ( x <= arr [ low ] ) return low ;
  if ( x > arr [ high ] ) return - 1 ;
  mid = ( low + high ) / 2 ;
  if ( arr [ mid ] == x ) return mid ;
  else if ( arr [ mid ] < x ) {
    if ( mid + 1 <= high && x <= arr [ mid + 1 ] ) return mid + 1 ;
    else return f_gold ( arr , mid + 1 , high , x ) ;
  }
  else {
    if ( mid - 1 >= low && x > arr [ mid - 1 ] ) return mid ;
    else return f_gold ( arr , low , mid - 1 , x ) ;
  }
}
public static void main(String args[]) {
f_gold(new int[]{2,6,13,16,23,24,24,27,30,32,34,34,55,56,56,63,66,81,83,96},13,11,18);
}
}