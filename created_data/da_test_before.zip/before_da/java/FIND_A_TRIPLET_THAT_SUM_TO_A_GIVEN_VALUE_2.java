import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class FIND_A_TRIPLET_THAT_SUM_TO_A_GIVEN_VALUE_2{
static boolean f_gold ( int A [ ] , int arr_size , int sum ) {
  for ( int i = 0 ;
  i < arr_size - 2 ;
  i ++ ) {
    HashSet < Integer > s = new HashSet < Integer > ( ) ;
    int curr_sum = sum - A [ i ] ;
    for ( int j = i + 1 ;
    j < arr_size ;
    j ++ ) {
      if ( s . contains ( curr_sum - A [ j ] ) && curr_sum - A [ j ] != ( int ) s . toArray ( ) [ s . size ( ) - 1 ] ) {
        System . out . printf ( "Triplet is %d, %d, %d" , A [ i ] , A [ j ] , curr_sum - A [ j ] ) ;
        return true ;
      }
      s . add ( A [ j ] ) ;
    }
  }
  return false ;
}
public static void main(String args[]) {
f_gold(new int[]{1,6,8,8,9,11,13,13,15,17,21,24,38,38,42,43,46,46,47,54,55,56,57,58,60,60,60,62,63,63,65,66,67,67,69,81,84,84,85,86,95,99},27,24);
}
}