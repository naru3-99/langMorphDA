import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class COUNT_FREQUENCY_K_MATRIX_SIZE_N_MATRIXI_J_IJ{
public static int f_gold ( int n , int k ) {
  if ( n + 1 >= k ) return ( k - 1 ) ;
  else return ( 2 * n + 1 - k ) ;
}
public static void main(String args[]) {
f_gold(90,74);
}
}