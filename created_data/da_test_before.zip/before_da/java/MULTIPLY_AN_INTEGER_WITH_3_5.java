import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MULTIPLY_AN_INTEGER_WITH_3_5{
static int f_gold ( int x ) {
  return ( x << 1 ) + x + ( x >> 1 ) ;
}
public static void main(String args[]) {
f_gold(58);
}
}