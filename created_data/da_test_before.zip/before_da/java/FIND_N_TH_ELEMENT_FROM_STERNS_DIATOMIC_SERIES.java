import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class FIND_N_TH_ELEMENT_FROM_STERNS_DIATOMIC_SERIES{
static int f_gold ( int n ) {
  int DP [ ] = new int [ n + 1 ] ;
  DP [ 0 ] = 0 ;
  DP [ 1 ] = 1 ;
  for ( int i = 2 ;
  i <= n ;
  i ++ ) {
    if ( i % 2 == 0 ) DP [ i ] = DP [ i / 2 ] ;
    else DP [ i ] = DP [ ( i - 1 ) / 2 ] + DP [ ( i + 1 ) / 2 ] ;
  }
  return DP [ n ] ;
}
public static void main(String args[]) {
f_gold(37);
}
}