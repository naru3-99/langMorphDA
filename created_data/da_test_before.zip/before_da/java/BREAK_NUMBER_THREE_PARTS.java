import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class BREAK_NUMBER_THREE_PARTS{
static long f_gold ( long n ) {
  long count = 0 ;
  for ( int i = 0 ;
  i <= n ;
  i ++ ) for ( int j = 0 ;
  j <= n ;
  j ++ ) for ( int k = 0 ;
  k <= n ;
  k ++ ) if ( i + j + k == n ) count ++ ;
  return count ;
}
public static void main(String args[]) {
f_gold(52L);
}
}