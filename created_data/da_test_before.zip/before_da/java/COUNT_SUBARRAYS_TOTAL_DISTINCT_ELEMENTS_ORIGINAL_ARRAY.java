import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class COUNT_SUBARRAYS_TOTAL_DISTINCT_ELEMENTS_ORIGINAL_ARRAY{
static int f_gold ( int arr [ ] , int n ) {
  HashMap < Integer , Integer > vis = new HashMap < Integer , Integer > ( ) {
    @ Override public Integer get ( Object key ) {
      if ( ! containsKey ( key ) ) return 0 ;
      return super . get ( key ) ;
    }
  };
  for ( int i = 0 ;
  i < n ;
  ++ i ) vis . put ( arr [ i ] , 1 ) ;
  int k = vis . size ( ) ;
  vis . clear ( ) ;
  int ans = 0 , right = 0 , window = 0 ;
  for ( int left = 0 ;
  left < n ;
  ++ left ) {
    while ( right < n && window < k ) {
      vis . put ( arr [ right ] , vis . get ( arr [ right ] ) + 1 ) ;
      if ( vis . get ( arr [ right ] ) == 1 ) ++ window ;
      ++ right ;
    }
    if ( window == k ) ans += ( n - right + 1 ) ;
    vis . put ( arr [ left ] , vis . get ( arr [ left ] ) - 1 ) ;
    if ( vis . get ( arr [ left ] ) == 0 ) -- window ;
  }
  return ans ;
}
public static void main(String args[]) {
f_gold(new int[]{13,39,49,52,53,69,72,79,83,96},5);
}
}