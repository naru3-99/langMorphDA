import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class COUNT_OF_PAIRS_SATISFYING_THE_GIVEN_CONDITION{
static int f_gold ( int a , int b ) {
  String s = String . valueOf ( b ) ;
  int i ;
  for ( i = 0 ;
  i < s . length ( ) ;
  i ++ ) {
    if ( s . charAt ( i ) != '9' ) break ;
  }
  int result ;
  if ( i == s . length ( ) ) result = a * s . length ( ) ;
  else result = a * ( s . length ( ) - 1 ) ;
  return result ;
}
public static void main(String args[]) {
f_gold(31,91);
}
}