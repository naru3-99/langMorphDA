import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class FINDING_POWER_PRIME_NUMBER_P_N_1{
static int f_gold ( int n , int p ) {
  int ans = 0 ;
  int temp = p ;
  while ( temp <= n ) {
    ans += n / temp ;
    temp = temp * p ;
  }
  return ans ;
}
public static void main(String args[]) {
f_gold(76,43);
}
}