import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class NUMBER_INDEXES_EQUAL_ELEMENTS_GIVEN_RANGE{
static int f_gold ( int a [ ] , int n , int l , int r ) {
  int count = 0 ;
  for ( int i = l ;
  i < r ;
  i ++ ) if ( a [ i ] == a [ i + 1 ] ) count += 1 ;
  return count ;
}
public static void main(String args[]) {
f_gold(new int[]{4,13,13,16,16,19,39,41,48,52,57,62,65,67,76,84,88,91,95,96,97,98},18,12,17);
}
}