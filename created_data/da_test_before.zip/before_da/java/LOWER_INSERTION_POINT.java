import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class LOWER_INSERTION_POINT{
static int f_gold ( int arr [ ] , int n , int X ) {
  if ( X < arr [ 0 ] ) return 0 ;
  else if ( X > arr [ n - 1 ] ) return n ;
  int lowerPnt = 0 ;
  int i = 1 ;
  while ( i < n && arr [ i ] < X ) {
    lowerPnt = i ;
    i = i * 2 ;
  }
  while ( lowerPnt < n && arr [ lowerPnt ] < X ) lowerPnt ++ ;
  return lowerPnt ;
}
public static void main(String args[]) {
f_gold(new int[]{1,2,5,5,16,16,20,26,32,35,39,39,41,44,48,48,51,59,59,62,66,66,70,74,75,78,80,86,86,96},17,29);
}
}