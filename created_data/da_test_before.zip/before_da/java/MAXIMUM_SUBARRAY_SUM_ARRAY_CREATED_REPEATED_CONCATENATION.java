import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MAXIMUM_SUBARRAY_SUM_ARRAY_CREATED_REPEATED_CONCATENATION{
static int f_gold ( int a [ ] , int n , int k ) {
  int max_so_far = 0 ;
  int INT_MIN , max_ending_here = 0 ;
  for ( int i = 0 ;
  i < n * k ;
  i ++ ) {
    max_ending_here = max_ending_here + a [ i % n ] ;
    if ( max_so_far < max_ending_here ) max_so_far = max_ending_here ;
    if ( max_ending_here < 0 ) max_ending_here = 0 ;
  }
  return max_so_far ;
}
public static void main(String args[]) {
f_gold(new int[]{5,6,12,20,23,28,33,37,47,51,53,56,63,65,65,68,69,76,76,78,83},18,20);
}
}