import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MAXIMUM_POINTS_INTERSECTION_N_CIRCLES{
static int f_gold ( int n ) {
  return n * ( n - 1 ) ;
}
public static void main(String args[]) {
f_gold(30);
}
}