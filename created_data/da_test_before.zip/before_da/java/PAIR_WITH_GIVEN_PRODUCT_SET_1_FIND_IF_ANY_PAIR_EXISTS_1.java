import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class PAIR_WITH_GIVEN_PRODUCT_SET_1_FIND_IF_ANY_PAIR_EXISTS_1{
static boolean f_gold ( int arr [ ] , int n , int x ) {
  HashSet < Integer > hset = new HashSet < > ( ) ;
  if ( n < 2 ) return false ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) {
    if ( arr [ i ] == 0 ) {
      if ( x == 0 ) return true ;
      else continue ;
    }
    if ( x % arr [ i ] == 0 ) {
      if ( hset . contains ( x / arr [ i ] ) ) return true ;
      hset . add ( arr [ i ] ) ;
    }
  }
  return false ;
}
public static void main(String args[]) {
f_gold(new int[]{1,2,3,7,23,23,25,27,37,42,53,56,58,61,69,78,79,84,85,86,90,93,95},15,17);
}
}