import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class LONGEST_INCREASING_ODD_EVEN_SUBSEQUENCE{
public static int f_gold ( int arr [ ] , int n ) {
  int [ ] lioes = new int [ n ] ;
  int maxLen = 0 ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) lioes [ i ] = 1 ;
  for ( int i = 1 ;
  i < n ;
  i ++ ) for ( int j = 0 ;
  j < i ;
  j ++ ) if ( arr [ i ] > arr [ j ] && ( arr [ i ] + arr [ j ] ) % 2 != 0 && lioes [ i ] < lioes [ j ] + 1 ) lioes [ i ] = lioes [ j ] + 1 ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) if ( maxLen < lioes [ i ] ) maxLen = lioes [ i ] ;
  return maxLen ;
}
public static void main(String args[]) {
f_gold(new int[]{7,8,9,16,16,27,32,33,35,35,39,39,41,42,44,47,48,50,56,59,66,69,70,73,74,76,78,87,87,89,94,96,96,98,98},32);
}
}