import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class PROGRAM_CALCULATE_VOLUME_ELLIPSOID{
public static float f_gold ( float r1 , float r2 , float r3 ) {
  float pi = ( float ) 3.14 ;
  return ( float ) 1.33 * pi * r1 * r2 * r3 ;
}
public static void main(String args[]) {
f_gold(3287.4842316041018F,4503.332888443404F,8590.24729914204F);
}
}