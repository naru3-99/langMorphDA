import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class PROGRAM_PAGE_REPLACEMENT_ALGORITHMS_SET_2_FIFO{
static int f_gold ( int pages [ ] , int n , int capacity ) {
  HashSet < Integer > s = new HashSet < > ( capacity ) ;
  Queue < Integer > indexes = new LinkedList < > ( ) ;
  int page_faults = 0 ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) {
    if ( s . size ( ) < capacity ) {
      if ( ! s . contains ( pages [ i ] ) ) {
        s . add ( pages [ i ] ) ;
        page_faults ++ ;
        indexes . add ( pages [ i ] ) ;
      }
    }
    else {
      if ( ! s . contains ( pages [ i ] ) ) {
        int val = indexes . peek ( ) ;
        indexes . poll ( ) ;
        s . remove ( val ) ;
        s . add ( pages [ i ] ) ;
        indexes . add ( pages [ i ] ) ;
        page_faults ++ ;
      }
    }
  }
  return page_faults ;
}
public static void main(String args[]) {
f_gold(new int[]{4,4,6,7,8,11,13,18,26,35,36,37,45,46,46,47,48,49,51,52,53,56,61,74,75,77,80,83,85,86,87,90,93,95,97,98,99,99},36,37);
}
}