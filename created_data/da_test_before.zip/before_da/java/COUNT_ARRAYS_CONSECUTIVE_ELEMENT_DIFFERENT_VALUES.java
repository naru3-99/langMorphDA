import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class COUNT_ARRAYS_CONSECUTIVE_ELEMENT_DIFFERENT_VALUES{
public static int f_gold ( int n , int k , int x ) {
  int [ ] dp = new int [ 109 ] ;
  dp [ 0 ] = 0 ;
  dp [ 1 ] = 1 ;
  for ( int i = 2 ;
  i < n ;
  i ++ ) dp [ i ] = ( k - 2 ) * dp [ i - 1 ] + ( k - 1 ) * dp [ i - 2 ] ;
  return ( x == 1 ? ( k - 1 ) * dp [ n - 2 ] : dp [ n - 1 ] ) ;
}
public static void main(String args[]) {
f_gold(9,40,38);
}
}