import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class PROGRAM_FOR_SURFACE_AREA_OF_OCTAHEDRON{
static double f_gold ( double side ) {
  return ( 2 * ( Math . sqrt ( 3 ) ) * ( side * side ) ) ;
}
public static void main(String args[]) {
f_gold(1449.255716877097);
}
}