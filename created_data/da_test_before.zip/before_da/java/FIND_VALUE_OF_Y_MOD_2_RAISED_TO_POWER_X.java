import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class FIND_VALUE_OF_Y_MOD_2_RAISED_TO_POWER_X{
static long f_gold ( long y , long x ) {
  if ( ( Math . log ( y ) / Math . log ( 2 ) ) < x ) return y ;
  if ( x > 63 ) return y ;
  return ( y % ( 1 << ( int ) x ) ) ;
}
public static void main(String args[]) {
f_gold(57L,76L);
}
}