import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class FIND_SUBARRAY_WITH_GIVEN_SUM_1{
static int f_gold ( int arr [ ] , int n , int sum ) {
  int curr_sum = arr [ 0 ] , start = 0 , i ;
  for ( i = 1 ;
  i <= n ;
  i ++ ) {
    while ( curr_sum > sum && start < i - 1 ) {
      curr_sum = curr_sum - arr [ start ] ;
      start ++ ;
    }
    if ( curr_sum == sum ) {
      int p = i - 1 ;
      System . out . println ( "Sum found between indexes " + start + " and " + p ) ;
      return 1 ;
    }
    if ( i < n ) curr_sum = curr_sum + arr [ i ] ;
  }
  System . out . println ( "No subarray found" ) ;
  return 0 ;
}
public static void main(String args[]) {
f_gold(new int[]{7,7,8,8,23,24,28,32,48,53,56,62,69,77,81,82,84,87,88,90},16,31);
}
}