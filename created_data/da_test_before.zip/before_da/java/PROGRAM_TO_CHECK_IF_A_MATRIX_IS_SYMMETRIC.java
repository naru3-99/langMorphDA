import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class PROGRAM_TO_CHECK_IF_A_MATRIX_IS_SYMMETRIC{
static boolean f_gold ( int mat [ ] [ ] , int N ) {
  for ( int i = 0 ;
  i < N ;
  i ++ ) for ( int j = 0 ;
  j < N ;
  j ++ ) if ( mat [ i ] [ j ] != mat [ j ] [ i ] ) return false ;
  return true ;
}
public static void main(String args[]) {
f_gold(new int[][]{new int[]{29}},0);
}
}