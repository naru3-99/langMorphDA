import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class COUNT_NUMBERS_CAN_CONSTRUCTED_USING_TWO_NUMBERS{
static int f_gold ( int n , int x , int y ) {
  boolean [ ] arr = new boolean [ n + 1 ] ;
  if ( x <= n ) arr [ x ] = true ;
  if ( y <= n ) arr [ y ] = true ;
  int result = 0 ;
  for ( int i = Math . min ( x , y ) ;
  i <= n ;
  i ++ ) {
    if ( arr [ i ] ) {
      if ( i + x <= n ) arr [ i + x ] = true ;
      if ( i + y <= n ) arr [ i + y ] = true ;
      result ++ ;
    }
  }
  return result ;
}
public static void main(String args[]) {
f_gold(23,16,16);
}
}