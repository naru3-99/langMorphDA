import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class CHECK_WHETHER_GIVEN_NUMBER_EVEN_ODD{
public static boolean f_gold ( int n ) {
  return ( n % 2 == 0 ) ;
}
public static void main(String args[]) {
f_gold(67);
}
}