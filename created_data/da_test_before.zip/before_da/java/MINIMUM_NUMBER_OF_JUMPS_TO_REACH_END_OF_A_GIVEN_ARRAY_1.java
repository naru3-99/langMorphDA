import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MINIMUM_NUMBER_OF_JUMPS_TO_REACH_END_OF_A_GIVEN_ARRAY_1{
private static int f_gold ( int [ ] arr , int n ) {
  int jumps [ ] = new int [ n ] ;
  int i , j ;
  if ( n == 0 || arr [ 0 ] == 0 ) return Integer . MAX_VALUE ;
  jumps [ 0 ] = 0 ;
  for ( i = 1 ;
  i < n ;
  i ++ ) {
    jumps [ i ] = Integer . MAX_VALUE ;
    for ( j = 0 ;
    j < i ;
    j ++ ) {
      if ( i <= j + arr [ j ] && jumps [ j ] != Integer . MAX_VALUE ) {
        jumps [ i ] = Math . min ( jumps [ i ] , jumps [ j ] + 1 ) ;
        break ;
      }
    }
  }
  return jumps [ n - 1 ] ;
}
public static void main(String args[]) {
f_gold(new int[]{2,5,9,9,12,13,13,13,15,16,17,18,20,20,20,25,28,30,30,33,34,34,37,42,45,49,50,52,52,54,65,68,72,74,75,82,85,87,91,91,94,95},22);
}
}