import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class FIND_INDEX_OF_AN_EXTRA_ELEMENT_PRESENT_IN_ONE_SORTED_ARRAY{
static int f_gold ( int arr1 [ ] , int arr2 [ ] , int n ) {
  for ( int i = 0 ;
  i < n ;
  i ++ ) if ( arr1 [ i ] != arr2 [ i ] ) return i ;
  return n ;
}
public static void main(String args[]) {
f_gold(new int[]{1,6,7,10,11,12,12,16,17,29,32,33,35,35,45,49,52,56,57,58,61,62,63,64,68,71,71,77,79,79,81,82,82,83,83,89,89,93,94,94},new int[]{3,12,13,14,15,17,18,19,22,24,28,29,33,37,41,42,44,49,51,51,52,53,56,56,59,60,64,64,67,70,71,78,83,88,88,90,92,93,93,95},36);
}
}