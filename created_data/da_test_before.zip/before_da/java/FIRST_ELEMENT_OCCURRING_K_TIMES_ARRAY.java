import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class FIRST_ELEMENT_OCCURRING_K_TIMES_ARRAY{
static int f_gold ( int arr [ ] , int n , int k ) {
  HashMap < Integer , Integer > count_map = new HashMap < > ( ) ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) {
    int a = 0 ;
    if ( count_map . get ( arr [ i ] ) != null ) {
      a = count_map . get ( arr [ i ] ) ;
    }
    count_map . put ( arr [ i ] , a + 1 ) ;
  }
  for ( int i = 0 ;
  i < n ;
  i ++ ) {
    if ( count_map . get ( arr [ i ] ) == k ) {
      return arr [ i ] ;
    }
  }
  return - 1 ;
}
public static void main(String args[]) {
f_gold(new int[]{2,3,4,4,7,18,20,23,27,30,31,31,32,35,36,43,45,46,49,50,53,55,59,60,64,64,65,68,78,80,80,85,95},30,2);
}
}