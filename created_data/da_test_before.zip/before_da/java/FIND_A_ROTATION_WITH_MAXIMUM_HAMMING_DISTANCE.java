import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class FIND_A_ROTATION_WITH_MAXIMUM_HAMMING_DISTANCE{
static int f_gold ( int arr [ ] , int n ) {
  int brr [ ] = new int [ 2 * n + 1 ] ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) brr [ i ] = arr [ i ] ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) brr [ n + i ] = arr [ i ] ;
  int maxHam = 0 ;
  for ( int i = 1 ;
  i < n ;
  i ++ ) {
    int currHam = 0 ;
    for ( int j = i , k = 0 ;
    j < ( i + n ) ;
    j ++ , k ++ ) if ( brr [ j ] != arr [ k ] ) currHam ++ ;
    if ( currHam == n ) return n ;
    maxHam = Math . max ( maxHam , currHam ) ;
  }
  return maxHam ;
}
public static void main(String args[]) {
f_gold(new int[]{1,4,18,22,28,34,35,39,44,45,67,73,75,79,81,83,89,93,96},12);
}
}