import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MEDIAN_OF_TWO_SORTED_ARRAYS{
static int f_gold ( int ar1 [ ] , int ar2 [ ] , int n ) {
  int i = 0 ;
  int j = 0 ;
  int count ;
  int m1 = - 1 , m2 = - 1 ;
  for ( count = 0 ;
  count <= n ;
  count ++ ) {
    if ( i == n ) {
      m1 = m2 ;
      m2 = ar2 [ 0 ] ;
      break ;
    }
    else if ( j == n ) {
      m1 = m2 ;
      m2 = ar1 [ 0 ] ;
      break ;
    }
    if ( ar1 [ i ] < ar2 [ j ] ) {
      m1 = m2 ;
      m2 = ar1 [ i ] ;
      i ++ ;
    }
    else {
      m1 = m2 ;
      m2 = ar2 [ j ] ;
      j ++ ;
    }
  }
  return ( m1 + m2 ) / 2 ;
}
public static void main(String args[]) {
f_gold(new int[]{2,6,18,21,23,27,44,44,69,72,78,88,90,98},new int[]{6,12,16,18,26,34,48,48,49,56,61,79,81,89},12);
}
}