import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class NUMBER_WAYS_NODE_MAKE_LOOP_SIZE_K_UNDIRECTED_COMPLETE_CONNECTED_GRAPH_N_NODES{
static int f_gold ( int n , int k ) {
  int p = 1 ;
  if ( k % 2 != 0 ) p = - 1 ;
  return ( int ) ( Math . pow ( n - 1 , k ) + p * ( n - 1 ) ) / n ;
}
public static void main(String args[]) {
f_gold(27,59);
}
}