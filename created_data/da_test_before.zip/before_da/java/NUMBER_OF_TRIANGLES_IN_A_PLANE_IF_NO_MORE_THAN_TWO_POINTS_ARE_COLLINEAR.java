import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class NUMBER_OF_TRIANGLES_IN_A_PLANE_IF_NO_MORE_THAN_TWO_POINTS_ARE_COLLINEAR{
static int f_gold ( int n ) {
  return n * ( n - 1 ) * ( n - 2 ) / 6 ;
}
public static void main(String args[]) {
f_gold(67);
}
}