import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class FIND_MAXIMUM_PRODUCT_OF_A_TRIPLET_IN_ARRAY_1{
static int f_gold ( int arr [ ] , int n ) {
  if ( n < 3 ) {
    return - 1 ;
  }
  Arrays . sort ( arr ) ;
  return Math . max ( arr [ 0 ] * arr [ 1 ] * arr [ n - 1 ] , arr [ n - 1 ] * arr [ n - 2 ] * arr [ n - 3 ] ) ;
}
public static void main(String args[]) {
f_gold(new int[]{5,8,14,15,18,21,21,21,27,29,30,33,34,34,35,37,40,41,44,44,46,49,54,58,60,61,61,63,66,69,69,70,81,82,82,90,90,90,91,92,92,96,97,99},39);
}
}