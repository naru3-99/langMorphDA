import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class FIND_WHETHER_AN_ARRAY_IS_SUBSET_OF_ANOTHER_ARRAY_SET_1_1{
static boolean f_gold ( int arr1 [ ] , int arr2 [ ] , int m , int n ) {
  int i = 0 , j = 0 ;
  if ( m < n ) return false ;
  Arrays . sort ( arr1 ) ;
  Arrays . sort ( arr2 ) ;
  while ( i < n && j < m ) {
    if ( arr1 [ j ] < arr2 [ i ] ) j ++ ;
    else if ( arr1 [ j ] == arr2 [ i ] ) {
      j ++ ;
      i ++ ;
    }
    else if ( arr1 [ j ] > arr2 [ i ] ) return false ;
  }
  if ( i < n ) return false ;
  else return true ;
}
public static void main(String args[]) {
f_gold(new int[]{7,10,10,10,13,17,23,24,25,28,30,33,37,49,49,50,57,60,60,63,63,64,65,65,72,81,84,85,85,94,96},new int[]{10,13,17,63},29,4);
}
}