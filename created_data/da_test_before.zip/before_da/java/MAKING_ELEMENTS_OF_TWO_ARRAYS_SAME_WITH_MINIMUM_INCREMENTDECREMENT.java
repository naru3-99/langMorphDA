import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MAKING_ELEMENTS_OF_TWO_ARRAYS_SAME_WITH_MINIMUM_INCREMENTDECREMENT{
static int f_gold ( int a [ ] , int b [ ] , int n ) {
  Arrays . sort ( a ) ;
  Arrays . sort ( b ) ;
  int result = 0 ;
  for ( int i = 0 ;
  i < n ;
  ++ i ) {
    if ( a [ i ] > b [ i ] ) result = result + Math . abs ( a [ i ] - b [ i ] ) ;
    else if ( a [ i ] < b [ i ] ) result = result + Math . abs ( a [ i ] - b [ i ] ) ;
  }
  return result ;
}
public static void main(String args[]) {
f_gold(new int[]{1,6,6,7,10,11,13,18,19,19,19,31,34,37,37,40,41,41,47,47,53,54,55,55,56,56,60,60,62,62,66,73,75,76,78,81,81,85,88,90,91,92,93,95,97,98},new int[]{2,2,4,7,8,8,8,8,8,9,9,12,15,16,21,25,26,27,29,34,34,35,38,40,40,44,44,47,48,54,58,61,63,64,66,69,69,70,73,74,75,76,79,80,80,93},23);
}
}