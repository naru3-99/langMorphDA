import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class PROGRAM_FIND_STRING_START_END_GEEKS{
static boolean f_gold ( String str , String corner ) {
  int n = str . length ( ) ;
  int cl = corner . length ( ) ;
  if ( n < cl ) return false ;
  return ( str . substring ( 0 , cl ) . equals ( corner ) && str . substring ( n - cl , n ) . equals ( corner ) ) ;
}
public static void main(String args[]) {
f_gold("geeksmanishgeeks","geeks");
}
}