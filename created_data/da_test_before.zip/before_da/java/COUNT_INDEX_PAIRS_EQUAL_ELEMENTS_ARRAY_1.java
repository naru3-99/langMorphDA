import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class COUNT_INDEX_PAIRS_EQUAL_ELEMENTS_ARRAY_1{
public static int f_gold ( int arr [ ] , int n ) {
  HashMap < Integer , Integer > hm = new HashMap < > ( ) ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) {
    if ( hm . containsKey ( arr [ i ] ) ) hm . put ( arr [ i ] , hm . get ( arr [ i ] ) + 1 ) ;
    else hm . put ( arr [ i ] , 1 ) ;
  }
  int ans = 0 ;
  for ( Map . Entry < Integer , Integer > it : hm . entrySet ( ) ) {
    int count = it . getValue ( ) ;
    ans += ( count * ( count - 1 ) ) / 2 ;
  }
  return ans ;
}
public static void main(String args[]) {
f_gold(new int[]{5,11,18,22,40,46,50,51,53,55,64,67,73,78,86},14);
}
}