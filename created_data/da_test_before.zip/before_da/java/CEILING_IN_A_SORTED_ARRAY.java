import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class CEILING_IN_A_SORTED_ARRAY{
static int f_gold ( int arr [ ] , int low , int high , int x ) {
  int i ;
  if ( x <= arr [ low ] ) return low ;
  for ( i = low ;
  i < high ;
  i ++ ) {
    if ( arr [ i ] == x ) return i ;
    if ( arr [ i ] < x && arr [ i + 1 ] >= x ) return i + 1 ;
  }
  return - 1 ;
}
public static void main(String args[]) {
f_gold(new int[]{2,3,4,6,8,9,9,10,11,16,19,20,21,21,21,24,24,25,28,30,30,30,32,34,35,39,41,42,49,52,57,59,61,62,66,68,71,73,76,79,83,84,85,86,87,87},23,37,44);
}
}