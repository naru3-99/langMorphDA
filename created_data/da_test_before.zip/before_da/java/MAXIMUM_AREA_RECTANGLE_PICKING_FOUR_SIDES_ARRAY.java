import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MAXIMUM_AREA_RECTANGLE_PICKING_FOUR_SIDES_ARRAY{
static int f_gold ( Integer arr [ ] , int n ) {
  Arrays . sort ( arr , Collections . reverseOrder ( ) ) ;
  int [ ] dimension = {
    0 , 0 };
    for ( int i = 0 , j = 0 ;
    i < n - 1 && j < 2 ;
    i ++ ) if ( arr [ i ] == arr [ i + 1 ] ) dimension [ j ++ ] = arr [ i ++ ] ;
    return ( dimension [ 0 ] * dimension [ 1 ] ) ;
  }
public static void main(String args[]) {
f_gold(new Integer[]{1,5,6,8,9,11,12,14,16,17,24,25,36,40,44,47,49,51,51,52,67,68,72,74,81,82,83,84,92,95,95,96,99},27);
}
}