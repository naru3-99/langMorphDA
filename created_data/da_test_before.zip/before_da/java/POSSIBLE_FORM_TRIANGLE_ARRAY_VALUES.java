import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class POSSIBLE_FORM_TRIANGLE_ARRAY_VALUES{
static boolean f_gold ( int [ ] arr , int N ) {
  if ( N < 3 ) return false ;
  Arrays . sort ( arr ) ;
  for ( int i = 0 ;
  i < N - 2 ;
  i ++ ) if ( arr [ i ] + arr [ i + 1 ] > arr [ i + 2 ] ) return true ;
  return false ;
}
public static void main(String args[]) {
f_gold(new int[]{2,6,8,10,14,15,16,19,21,26,26,26,28,29,30,33,33,35,36,36,41,44,45,45,45,49,51,54,57,59,61,64,68,70,70,72,73,74,76,78,87,89,89,91,92,93,94,95,97},25);
}
}