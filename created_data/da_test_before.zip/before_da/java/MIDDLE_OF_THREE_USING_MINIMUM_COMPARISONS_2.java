import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MIDDLE_OF_THREE_USING_MINIMUM_COMPARISONS_2{
public static int f_gold ( int a , int b , int c ) {
  int x = a - b ;
  int y = b - c ;
  int z = a - c ;
  if ( x * y > 0 ) return b ;
  else if ( x * z > 0 ) return c ;
  else return a ;
}
public static void main(String args[]) {
f_gold(48,46,38);
}
}