import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class NUMBER_OF_PAIRS_IN_AN_ARRAY_HAVING_SUM_EQUAL_TO_PRODUCT{
static int f_gold ( int a [ ] , int n ) {
  int zero = 0 , two = 0 ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) {
    if ( a [ i ] == 0 ) {
      zero ++ ;
    }
    if ( a [ i ] == 2 ) {
      two ++ ;
    }
  }
  int cnt = ( zero * ( zero - 1 ) ) / 2 + ( two * ( two - 1 ) ) / 2 ;
  return cnt ;
}
public static void main(String args[]) {
f_gold(new int[]{9,10,20,26,26,28,31,34,35,36,36,37,39,43,44,44,46,49,54,57,58,63,64,64,65,67,70,70,74,75,77,78,79,81,82,83,84,86,95},31);
}
}