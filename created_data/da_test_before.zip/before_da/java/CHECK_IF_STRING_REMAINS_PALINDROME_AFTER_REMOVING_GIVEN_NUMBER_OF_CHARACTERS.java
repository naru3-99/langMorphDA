import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class CHECK_IF_STRING_REMAINS_PALINDROME_AFTER_REMOVING_GIVEN_NUMBER_OF_CHARACTERS{
static boolean f_gold ( String str , int n ) {
  int len = str . length ( ) ;
  if ( len >= n ) return true ;
  return false ;
}
public static void main(String args[]) {
f_gold("ZCoQhuM",2);
}
}