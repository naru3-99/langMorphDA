import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class BASIC_AND_EXTENDED_EUCLIDEAN_ALGORITHMS{
public static int f_gold ( int a , int b ) {
  if ( a == 0 ) return b ;
  return f_gold ( b % a , a ) ;
}
public static void main(String args[]) {
f_gold(46,89);
}
}