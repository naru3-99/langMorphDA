import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class FIND_MINIMUM_DIFFERENCE_PAIR_1{
static int f_gold ( int [ ] arr , int n ) {
  Arrays . sort ( arr ) ;
  int diff = Integer . MAX_VALUE ;
  for ( int i = 0 ;
  i < n - 1 ;
  i ++ ) if ( arr [ i + 1 ] - arr [ i ] < diff ) diff = arr [ i + 1 ] - arr [ i ] ;
  return diff ;
}
public static void main(String args[]) {
f_gold(new int[]{3,25,44,46,54,60,81},3);
}
}