import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class POSITION_OF_RIGHTMOST_SET_BIT{
public static int f_gold ( int n ) {
  return ( int ) ( ( Math . log10 ( n & - n ) ) / Math . log10 ( 2 ) ) + 1 ;
}
public static void main(String args[]) {
f_gold(45);
}
}