import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class FIND_THE_MINIMUM_DISTANCE_BETWEEN_TWO_NUMBERS{
static int f_gold ( int arr [ ] , int n , int x , int y ) {
  int i , j ;
  int min_dist = Integer . MAX_VALUE ;
  for ( i = 0 ;
  i < n ;
  i ++ ) {
    for ( j = i + 1 ;
    j < n ;
    j ++ ) {
      if ( ( x == arr [ i ] && y == arr [ j ] || y == arr [ i ] && x == arr [ j ] ) && min_dist > Math . abs ( i - j ) ) min_dist = Math . abs ( i - j ) ;
    }
  }
  return min_dist ;
}
public static void main(String args[]) {
f_gold(new int[]{4,7,7,8,11,14,16,25,34,35,36,36,38,40,41,43,45,47,57,60,64,72,73,74,75,82,83,83,84,84,84,92},22,7,40);
}
}