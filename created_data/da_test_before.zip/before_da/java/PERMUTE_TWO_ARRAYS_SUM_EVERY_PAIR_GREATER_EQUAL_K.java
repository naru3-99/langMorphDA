import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class PERMUTE_TWO_ARRAYS_SUM_EVERY_PAIR_GREATER_EQUAL_K{
static boolean f_gold ( Integer a [ ] , int b [ ] , int n , int k ) {
  Arrays . sort ( a , Collections . reverseOrder ( ) ) ;
  Arrays . sort ( b ) ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) if ( a [ i ] + b [ i ] < k ) return false ;
  return true ;
}
public static void main(String args[]) {
f_gold(new Integer[]{9,12,16,25,27,40,43,52,52,70,87,88,90,97,99},new int[]{4,7,11,20,34,35,36,44,46,71,72,78,85,85,91},10,7);
}
}