import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MINIMUM_DIFFERENCE_BETWEEN_GROUPS_OF_SIZE_TWO{
static long f_gold ( long a [ ] , int n ) {
  Arrays . sort ( a ) ;
  int i , j ;
  Vector < Long > s = new Vector < > ( ) ;
  for ( i = 0 , j = n - 1 ;
  i < j ;
  i ++ , j -- ) s . add ( ( a [ i ] + a [ j ] ) ) ;
  long mini = Collections . min ( s ) ;
  long maxi = Collections . max ( s ) ;
  return Math . abs ( maxi - mini ) ;
}
public static void main(String args[]) {
f_gold(new long[]{11L,12L,14L,15L,20L,21L,28L,28L,30L,33L,39L,39L,42L,43L,44L,45L,48L,53L,53L,58L,59L,67L,68L,70L,70L,72L,74L,76L,76L,81L,87L,91L},31);
}
}