import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class PROGRAM_TO_FIND_REMAINDER_WITHOUT_USING_MODULO_OR_OPERATOR{
static int f_gold ( int num , int divisor ) {
  return ( num - divisor * ( num / divisor ) ) ;
}
public static void main(String args[]) {
f_gold(80,54);
}
}