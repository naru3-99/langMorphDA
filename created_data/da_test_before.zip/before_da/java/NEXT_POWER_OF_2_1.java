import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class NEXT_POWER_OF_2_1{
static int f_gold ( int n ) {
  int p = 1 ;
  if ( n > 0 && ( n & ( n - 1 ) ) == 0 ) return n ;
  while ( p < n ) p <<= 1 ;
  return p ;
}
public static void main(String args[]) {
f_gold(8);
}
}