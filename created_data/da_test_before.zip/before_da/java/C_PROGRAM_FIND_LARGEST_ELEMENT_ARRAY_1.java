import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class C_PROGRAM_FIND_LARGEST_ELEMENT_ARRAY_1{
static int f_gold ( int [ ] arr , int n ) {
  Arrays . sort ( arr ) ;
  return arr [ n - 1 ] ;
}
public static void main(String args[]) {
f_gold(new int[]{10,12,14,16,17,17,20,24,26,28,37,38,41,45,49,50,59,61,63,65,65,66,69,70,70,73,73,74,81,81,83,87,94,97},17);
}
}