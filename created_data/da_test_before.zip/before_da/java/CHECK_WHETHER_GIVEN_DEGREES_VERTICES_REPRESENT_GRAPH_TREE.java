import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class CHECK_WHETHER_GIVEN_DEGREES_VERTICES_REPRESENT_GRAPH_TREE{
static boolean f_gold ( int degree [ ] , int n ) {
  int deg_sum = 0 ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) {
    deg_sum += degree [ i ] ;
  }
  return ( 2 * ( n - 1 ) == deg_sum ) ;
}
public static void main(String args[]) {
f_gold(new int[]{2, 3, 1, 1, 1},5);
}
}