import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class POSSIBLE_TO_MAKE_A_DIVISIBLE_BY_3_NUMBER_USING_ALL_DIGITS_IN_AN_ARRAY{
public static boolean f_gold ( int arr [ ] , int n ) {
  int remainder = 0 ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) remainder = ( remainder + arr [ i ] ) % 3 ;
  return ( remainder == 0 ) ;
}
public static void main(String args[]) {
f_gold(new int[]{2,4,9,11,12,15,16,19,21,21,23,23,24,30,31,31,32,34,37,41,41,43,45,46,47,54,58,60,62,66,66,74,74,75,75,77,77,85,89,90,92,92,93,95,98},30);
}
}