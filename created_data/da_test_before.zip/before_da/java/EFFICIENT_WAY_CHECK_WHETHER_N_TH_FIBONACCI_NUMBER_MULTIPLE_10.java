import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class EFFICIENT_WAY_CHECK_WHETHER_N_TH_FIBONACCI_NUMBER_MULTIPLE_10{
static boolean f_gold ( int n ) {
  if ( n % 15 == 0 ) return true ;
  return false ;
}
public static void main(String args[]) {
f_gold(30);
}
}