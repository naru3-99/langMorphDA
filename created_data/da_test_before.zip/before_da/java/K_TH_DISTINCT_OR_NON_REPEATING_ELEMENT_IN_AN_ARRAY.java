import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class K_TH_DISTINCT_OR_NON_REPEATING_ELEMENT_IN_AN_ARRAY{
static int f_gold ( int arr [ ] , int n , int k ) {
  int dist_count = 0 ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) {
    int j ;
    for ( j = 0 ;
    j < n ;
    j ++ ) if ( i != j && arr [ j ] == arr [ i ] ) break ;
    if ( j == n ) dist_count ++ ;
    if ( dist_count == k ) return arr [ i ] ;
  }
  return - 1 ;
}
public static void main(String args[]) {
f_gold(new int[]{2,3,8,18,20,33,53,56,60,71,76,80,81,87,88,89,92,95},16,16);
}
}