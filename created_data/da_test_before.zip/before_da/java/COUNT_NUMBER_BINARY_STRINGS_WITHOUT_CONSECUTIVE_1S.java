import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class COUNT_NUMBER_BINARY_STRINGS_WITHOUT_CONSECUTIVE_1S{
static int f_gold ( int n ) {
  int a [ ] = new int [ n ] ;
  int b [ ] = new int [ n ] ;
  a [ 0 ] = b [ 0 ] = 1 ;
  for ( int i = 1 ;
  i < n ;
  i ++ ) {
    a [ i ] = a [ i - 1 ] + b [ i - 1 ] ;
    b [ i ] = a [ i - 1 ] ;
  }
  return a [ n - 1 ] + b [ n - 1 ] ;
}
public static void main(String args[]) {
f_gold(86);
}
}