import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class C_PROGRAM_CONCATENATE_STRING_GIVEN_NUMBER_TIMES{
static String f_gold ( String s , int n ) {
  String s1 = s ;
  for ( int i = 1 ;
  i < n ;
  i ++ ) s += s1 ;
  return s ;
}
public static void main(String args[]) {
f_gold("LPWsaI",41);
}
}