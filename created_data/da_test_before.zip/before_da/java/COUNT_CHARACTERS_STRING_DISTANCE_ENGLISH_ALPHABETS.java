import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class COUNT_CHARACTERS_STRING_DISTANCE_ENGLISH_ALPHABETS{
static int f_gold ( String str ) {
  int result = 0 ;
  int n = str . length ( ) ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) for ( int j = i + 1 ;
  j < n ;
  j ++ ) if ( Math . abs ( str . charAt ( i ) - str . charAt ( j ) ) == Math . abs ( i - j ) ) result ++ ;
  return result ;
}
public static void main(String args[]) {
f_gold("smnKL");
}
}