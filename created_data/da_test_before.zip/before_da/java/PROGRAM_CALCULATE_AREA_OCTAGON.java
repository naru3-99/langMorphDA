import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class PROGRAM_CALCULATE_AREA_OCTAGON{
static double f_gold ( double side ) {
  return ( float ) ( 2 * ( 1 + Math . sqrt ( 2 ) ) * side * side ) ;
}
public static void main(String args[]) {
f_gold(5859.798616323926);
}
}