import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class FIND_THE_MAXIMUM_ELEMENT_IN_AN_ARRAY_WHICH_IS_FIRST_INCREASING_AND_THEN_DECREASING{
static int f_gold ( int arr [ ] , int low , int high ) {
  int max = arr [ low ] ;
  int i ;
  for ( i = low ;
  i <= high ;
  i ++ ) {
    if ( arr [ i ] > max ) max = arr [ i ] ;
  }
  return max ;
}
public static void main(String args[]) {
f_gold(new int[]{11,15,16,19,24,25,26,28,34,34,43,61,63,66,67,72,77,79,81,83,87,94,99},15,21);
}
}