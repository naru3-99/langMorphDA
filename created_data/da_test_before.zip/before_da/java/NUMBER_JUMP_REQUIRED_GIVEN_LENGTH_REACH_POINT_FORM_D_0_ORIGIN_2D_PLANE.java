import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class NUMBER_JUMP_REQUIRED_GIVEN_LENGTH_REACH_POINT_FORM_D_0_ORIGIN_2D_PLANE{
static int f_gold ( int a , int b , int d ) {
  int temp = a ;
  a = Math . min ( a , b ) ;
  b = Math . max ( temp , b ) ;
  if ( d >= b ) return ( d + b - 1 ) / b ;
  if ( d == 0 ) return 0 ;
  if ( d == a ) return 1 ;
  return 2 ;
}
public static void main(String args[]) {
f_gold(35,8,77);
}
}