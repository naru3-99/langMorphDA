import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class LENGTH_OF_THE_LONGEST_ARITHMATIC_PROGRESSION_IN_A_SORTED_ARRAY{
static int f_gold ( int set [ ] , int n ) {
  if ( n <= 2 ) return n ;
  int L [ ] [ ] = new int [ n ] [ n ] ;
  int llap = 2 ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) L [ i ] [ n - 1 ] = 2 ;
  for ( int j = n - 2 ;
  j >= 1 ;
  j -- ) {
    int i = j - 1 , k = j + 1 ;
    while ( i >= 0 && k <= n - 1 ) {
      if ( set [ i ] + set [ k ] < 2 * set [ j ] ) k ++ ;
      else if ( set [ i ] + set [ k ] > 2 * set [ j ] ) {
        L [ i ] [ j ] = 2 ;
        i -- ;
      }
      else {
        L [ i ] [ j ] = L [ j ] [ k ] + 1 ;
        llap = Math . max ( llap , L [ i ] [ j ] ) ;
        i -- ;
        k ++ ;
      }
    }
    while ( i >= 0 ) {
      L [ i ] [ j ] = 2 ;
      i -- ;
    }
  }
  return llap ;
}
public static void main(String args[]) {
f_gold(new int[]{3,4,4,7,8,19,21,22,25,27,28,29,38,40,41,42,43,46,50,50,53,53,54,55,60,64,64,69,70,75,77,81,81,82,86,87,87,88,91,94,97},27);
}
}