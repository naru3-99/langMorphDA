import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MAXIMUM_TRIPLET_SUM_ARRAY{
static int f_gold ( int arr [ ] , int n ) {
  int sum = - 1000000 ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) for ( int j = i + 1 ;
  j < n ;
  j ++ ) for ( int k = j + 1 ;
  k < n ;
  k ++ ) if ( sum < arr [ i ] + arr [ j ] + arr [ k ] ) sum = arr [ i ] + arr [ j ] + arr [ k ] ;
  return sum ;
}
public static void main(String args[]) {
f_gold(new int[]{6,10,14,19,24,29,42,43,44,47,47,55,57,59,60,61,76,76,77,81,84,92,92,93,95,97},15);
}
}