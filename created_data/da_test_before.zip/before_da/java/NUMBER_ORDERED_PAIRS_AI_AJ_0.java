import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class NUMBER_ORDERED_PAIRS_AI_AJ_0{
static int f_gold ( int a [ ] , int n ) {
  int count = 0 ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) {
    for ( int j = i + 1 ;
    j < n ;
    j ++ ) if ( ( a [ i ] & a [ j ] ) == 0 ) count += 2 ;
  }
  return count ;
}
public static void main(String args[]) {
f_gold(new int[]{17,20,32,35,35,36,43,47,59,59,68,69,70,70,75,82,88,94,96,99},17);
}
}