import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class ADD_1_TO_A_GIVEN_NUMBER_1{
static int f_gold ( int x ) {
  return ( - ( ~ x ) ) ;
}
public static void main(String args[]) {
f_gold(20);
}
}