import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class PROGRAM_CALCULATE_VOLUME_OCTAHEDRON{
static double f_gold ( double side ) {
  return ( ( side * side * side ) * ( Math . sqrt ( 2 ) / 3 ) ) ;
}
public static void main(String args[]) {
f_gold(3355.322051344013);
}
}