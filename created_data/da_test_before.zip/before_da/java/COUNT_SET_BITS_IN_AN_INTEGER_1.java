import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class COUNT_SET_BITS_IN_AN_INTEGER_1{
public static int f_gold ( int n ) {
  if ( n == 0 ) return 0 ;
  else return ( n & 1 ) + f_gold ( n >> 1 ) ;
}
public static void main(String args[]) {
f_gold(43);
}
}