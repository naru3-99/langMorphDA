import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class FIND_SUM_MODULO_K_FIRST_N_NATURAL_NUMBER_1{
static int f_gold ( int N , int K ) {
  int ans = 0 ;
  int y = N / K ;
  int x = N % K ;
  ans = ( K * ( K - 1 ) / 2 ) * y + ( x * ( x + 1 ) ) / 2 ;
  return ans ;
}
public static void main(String args[]) {
f_gold(40,90);
}
}