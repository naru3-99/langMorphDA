import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class FIND_A_FIXED_POINT_IN_A_GIVEN_ARRAY{
static int f_gold ( int arr [ ] , int n ) {
  int i ;
  for ( i = 0 ;
  i < n ;
  i ++ ) {
    if ( arr [ i ] == i ) return i ;
  }
  return - 1 ;
}
public static void main(String args[]) {
f_gold(new int[]{8,16,21,26,27,29,34,35,35,37,38,40,48,52,58,59,60,61,63,63,65,66,69,75,79,83,86,88,91,91,96},23);
}
}