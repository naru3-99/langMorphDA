import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class NTH_PENTAGONAL_NUMBER{
static int f_gold ( int n ) {
  return ( 3 * n * n - n ) / 2 ;
}
public static void main(String args[]) {
f_gold(96);
}
}