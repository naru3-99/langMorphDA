import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class HEXAGONAL_NUMBER{
static int f_gold ( int n ) {
  return n * ( 2 * n - 1 ) ;
}
public static void main(String args[]) {
f_gold(38);
}
}