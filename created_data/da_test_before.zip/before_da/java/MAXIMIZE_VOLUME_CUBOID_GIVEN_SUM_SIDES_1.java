import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MAXIMIZE_VOLUME_CUBOID_GIVEN_SUM_SIDES_1{
static int f_gold ( int s ) {
  int length = s / 3 ;
  s -= length ;
  int breadth = s / 2 ;
  int height = s - breadth ;
  return length * breadth * height ;
}
public static void main(String args[]) {
f_gold(8);
}
}