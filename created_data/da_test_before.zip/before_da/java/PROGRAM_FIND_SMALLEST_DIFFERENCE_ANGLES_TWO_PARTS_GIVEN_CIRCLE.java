import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class PROGRAM_FIND_SMALLEST_DIFFERENCE_ANGLES_TWO_PARTS_GIVEN_CIRCLE{
public static int f_gold ( int arr [ ] , int n ) {
  int l = 0 , sum = 0 , ans = 360 ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) {
    sum += arr [ i ] ;
    while ( sum >= 180 ) {
      ans = Math . min ( ans , 2 * Math . abs ( 180 - sum ) ) ;
      sum -= arr [ l ] ;
      l ++ ;
    }
    ans = Math . min ( ans , 2 * Math . abs ( 180 - sum ) ) ;
  }
  return ans ;
}
public static void main(String args[]) {
f_gold(new int[]{4,4,5,5,13,14,14,16,19,20,30,31,32,33,35,38,38,42,44,44,48,48,52,58,60,64,65,66,68,69,70,70,71,72,73,79,81,83,83,84,86,87,88,88,91,92,95,95,98},27);
}
}