import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class EULERS_CRITERION_CHECK_IF_SQUARE_ROOT_UNDER_MODULO_P_EXISTS{
static boolean f_gold ( int n , int p ) {
  n = n % p ;
  for ( int x = 2 ;
  x < p ;
  x ++ ) if ( ( x * x ) % p == n ) return true ;
  return false ;
}
public static void main(String args[]) {
f_gold(71,78);
}
}