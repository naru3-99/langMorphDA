import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class CHECK_WHETHER_TRIANGLE_VALID_NOT_SIDES_GIVEN{
public static int f_gold ( int a , int b , int c ) {
  if ( a + b <= c || a + c <= b || b + c <= a ) return 0 ;
  else return 1 ;
}
public static void main(String args[]) {
f_gold(29,19,52);
}
}