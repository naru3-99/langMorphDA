import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class NTH_NON_FIBONACCI_NUMBER{
static int f_gold ( int n ) {
  int prevPrev = 1 , prev = 2 , curr = 3 ;
  while ( n > 0 ) {
    prevPrev = prev ;
    prev = curr ;
    curr = prevPrev + prev ;
    n = n - ( curr - prev - 1 ) ;
  }
  n = n + ( curr - prev - 1 ) ;
  return prev + n ;
}
public static void main(String args[]) {
f_gold(76);
}
}