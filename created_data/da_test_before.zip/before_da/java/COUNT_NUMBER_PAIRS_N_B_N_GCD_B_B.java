import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class COUNT_NUMBER_PAIRS_N_B_N_GCD_B_B{
static int f_gold ( int n ) {
  int k = n ;
  int imin = 1 ;
  int ans = 0 ;
  while ( imin <= n ) {
    int imax = n / k ;
    ans += k * ( imax - imin + 1 ) ;
    imin = imax + 1 ;
    k = n / imin ;
  }
  return ans ;
}
public static void main(String args[]) {
f_gold(17);
}
}