import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class NUMBER_VISIBLE_BOXES_PUTTING_ONE_INSIDE_ANOTHER{
static int f_gold ( int [ ] arr , int n ) {
  Queue < Integer > q = new LinkedList < > ( ) ;
  Arrays . sort ( arr ) ;
  q . add ( arr [ 0 ] ) ;
  for ( int i = 1 ;
  i < n ;
  i ++ ) {
    int now = q . element ( ) ;
    if ( arr [ i ] >= 2 * now ) q . remove ( ) ;
    q . add ( arr [ i ] ) ;
  }
  return q . size ( ) ;
}
public static void main(String args[]) {
f_gold(new int[]{2,3,17,17,18,28,28,29,34,43,44,52,54,80,84,84,91,92,97},12);
}
}