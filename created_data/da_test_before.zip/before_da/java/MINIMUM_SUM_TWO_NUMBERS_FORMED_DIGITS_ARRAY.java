import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MINIMUM_SUM_TWO_NUMBERS_FORMED_DIGITS_ARRAY{
static int f_gold ( int arr [ ] , int n ) {
  Arrays . sort ( arr ) ;
  int a = 0 , b = 0 ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) {
    if ( i % 2 != 0 ) a = a * 10 + arr [ i ] ;
    else b = b * 10 + arr [ i ] ;
  }
  return a + b ;
}
public static void main(String args[]) {
f_gold(new int[]{3,4,5,10,14,16,18,42,43,43,45,46,51,52,53,58,61,66,79,81,82,84},19);
}
}