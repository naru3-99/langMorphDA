import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class DYCK_PATH{
public static int f_gold ( int n ) {
  int res = 1 ;
  for ( int i = 0 ;
  i < n ;
  ++ i ) {
    res *= ( 2 * n - i ) ;
    res /= ( i + 1 ) ;
  }
  return res / ( n + 1 ) ;
}
public static void main(String args[]) {
f_gold(72);
}
}