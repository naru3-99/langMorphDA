import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MINIMUM_FLIP_REQUIRED_MAKE_BINARY_MATRIX_SYMMETRIC_1{
static int f_gold ( int mat [ ] [ ] , int n ) {
  int flip = 0 ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) for ( int j = 0 ;
  j < i ;
  j ++ ) if ( mat [ i ] [ j ] != mat [ j ] [ i ] ) flip ++ ;
  return flip ;
}
public static void main(String args[]) {
f_gold(new int[][]{new int[]{16,16,47,49,50,64,70,83,88},new int[]{11,12,24,32,36,39,48,58,62},new int[]{29,31,35,49,71,78,82,92,96},new int[]{6,21,46,53,83,88,94,94,97},new int[]{29,36,41,52,83,89,89,90,90},new int[]{3,11,35,45,47,79,81,85,96},new int[]{31,43,62,62,62,65,66,68,81},new int[]{8,9,10,26,36,43,58,70,95},new int[]{2,8,24,31,42,43,58,90,94}},8);
}
}