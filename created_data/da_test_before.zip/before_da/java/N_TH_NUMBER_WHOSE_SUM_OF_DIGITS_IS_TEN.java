import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class N_TH_NUMBER_WHOSE_SUM_OF_DIGITS_IS_TEN{
public static int f_gold ( int n ) {
  int count = 0 ;
  for ( int curr = 1 ;
  ;
  curr ++ ) {
    int sum = 0 ;
    for ( int x = curr ;
    x > 0 ;
    x = x / 10 ) sum = sum + x % 10 ;
    if ( sum == 10 ) count ++ ;
    if ( count == n ) return curr ;
  }
}
public static void main(String args[]) {
f_gold(37);
}
}