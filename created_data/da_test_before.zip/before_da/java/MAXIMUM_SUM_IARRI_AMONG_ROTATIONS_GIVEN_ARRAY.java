import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MAXIMUM_SUM_IARRI_AMONG_ROTATIONS_GIVEN_ARRAY{
static int f_gold ( int arr [ ] , int n ) {
  int res = Integer . MIN_VALUE ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) {
    int curr_sum = 0 ;
    for ( int j = 0 ;
    j < n ;
    j ++ ) {
      int index = ( i + j ) % n ;
      curr_sum += j * arr [ index ] ;
    }
    res = Math . max ( res , curr_sum ) ;
  }
  return res ;
}
public static void main(String args[]) {
f_gold(new int[]{11,12,16,26,29,40,54,59,65,70,71,73,78,81,87,87,88,90,95,97},11);
}
}