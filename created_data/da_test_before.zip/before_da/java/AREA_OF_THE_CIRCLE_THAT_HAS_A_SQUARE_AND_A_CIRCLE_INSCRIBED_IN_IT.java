import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class AREA_OF_THE_CIRCLE_THAT_HAS_A_SQUARE_AND_A_CIRCLE_INSCRIBED_IN_IT{
static float f_gold ( int a ) {
  float area = ( float ) ( Math . PI * a * a ) / 4 ;
  return area ;
}
public static void main(String args[]) {
f_gold(77);
}
}