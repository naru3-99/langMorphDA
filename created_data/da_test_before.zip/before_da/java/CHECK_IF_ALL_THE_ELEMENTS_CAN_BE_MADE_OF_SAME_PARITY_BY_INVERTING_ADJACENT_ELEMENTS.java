import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class CHECK_IF_ALL_THE_ELEMENTS_CAN_BE_MADE_OF_SAME_PARITY_BY_INVERTING_ADJACENT_ELEMENTS{
static boolean f_gold ( int [ ] a , int n ) {
  int count_odd = 0 , count_even = 0 ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) {
    if ( ( a [ i ] & 1 ) == 1 ) count_odd ++ ;
    else count_even ++ ;
  }
  if ( count_odd % 2 == 1 && count_even % 2 == 1 ) return false ;
  else return true ;
}
public static void main(String args[]) {
f_gold(new int[]{1,1,1,7,7,8,10,10,10,14,15,18,20,23,24,24,26,30,32,32,33,36,42,43,46,48,51,51,52,53,58,58,59,59,59,60,67,71,72,74,76,77,83,84,86,90,91},30);
}
}