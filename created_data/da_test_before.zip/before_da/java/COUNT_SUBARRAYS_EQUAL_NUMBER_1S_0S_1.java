import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class COUNT_SUBARRAYS_EQUAL_NUMBER_1S_0S_1{
static int f_gold ( int [ ] arr , int n ) {
  Map < Integer , Integer > myMap = new HashMap < > ( ) ;
  int sum = 0 ;
  int count = 0 ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) {
    if ( arr [ i ] == 0 ) arr [ i ] = - 1 ;
    sum += arr [ i ] ;
    if ( sum == 0 ) count ++ ;
    if ( myMap . containsKey ( sum ) ) count += myMap . get ( sum ) ;
    if ( ! myMap . containsKey ( sum ) ) myMap . put ( sum , 1 ) ;
    else myMap . put ( sum , myMap . get ( sum ) + 1 ) ;
  }
  return count ;
}
public static void main(String args[]) {
f_gold(new int[]{1,6,6,9,9,9,16,18,19,20,21,22,23,26,26,28,39,40,41,43,43,44,44,45,51,51,55,59,60,62,67,67,68,69,70,71,71,72,82,84,88,88,89,89,91,92,92},44);
}
}