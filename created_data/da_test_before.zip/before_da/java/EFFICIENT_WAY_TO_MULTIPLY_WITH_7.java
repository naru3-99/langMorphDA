import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class EFFICIENT_WAY_TO_MULTIPLY_WITH_7{
static int f_gold ( int n ) {
  return ( ( n << 3 ) - n ) ;
}
public static void main(String args[]) {
f_gold(41);
}
}