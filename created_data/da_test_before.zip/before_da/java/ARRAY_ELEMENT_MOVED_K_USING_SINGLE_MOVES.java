import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class ARRAY_ELEMENT_MOVED_K_USING_SINGLE_MOVES{
static int f_gold ( int a [ ] , int n , int k ) {
  if ( k >= n - 1 ) return n ;
  int best = 0 , times = 0 ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) {
    if ( a [ i ] > best ) {
      best = a [ i ] ;
      if ( i == 1 ) times = 1 ;
    }
    else times += 1 ;
    if ( times >= k ) return best ;
  }
  return best ;
}
public static void main(String args[]) {
f_gold(new int[]{2,5,5,9,10,10,11,14,23,27,31,32,33,33,33,37,39,41,41,42,42,43,47,60,61,68,73,73,73,78,80,80,82,83,86,87,89,92,94,98},33,37);
}
}