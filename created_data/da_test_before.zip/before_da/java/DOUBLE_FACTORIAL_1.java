import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class DOUBLE_FACTORIAL_1{
static int f_gold ( int n ) {
  int res = 1 ;
  for ( int i = n ;
  i >= 0 ;
  i = i - 2 ) {
    if ( i == 0 || i == 1 ) return res ;
    else res *= i ;
  }
  return res ;
}
public static void main(String args[]) {
f_gold(88);
}
}