import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MINIMUM_SWAPS_REQUIRED_BRING_ELEMENTS_LESS_EQUAL_K_TOGETHER{
static int f_gold ( int arr [ ] , int n , int k ) {
  int count = 0 ;
  for ( int i = 0 ;
  i < n ;
  ++ i ) if ( arr [ i ] <= k ) ++ count ;
  int bad = 0 ;
  for ( int i = 0 ;
  i < count ;
  ++ i ) if ( arr [ i ] > k ) ++ bad ;
  int ans = bad ;
  for ( int i = 0 , j = count ;
  j < n ;
  ++ i , ++ j ) {
    if ( arr [ i ] > k ) -- bad ;
    if ( arr [ j ] > k ) ++ bad ;
    ans = Math . min ( ans , bad ) ;
  }
  return ans ;
}
public static void main(String args[]) {
f_gold(new int[]{7,12,15,30,33,34,53,66,73,74,76,77,85,90},9,8);
}
}