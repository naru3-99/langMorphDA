import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class NUMBER_SUBSTRINGS_STRING{
static int f_gold ( String str ) {
  int n = str . length ( ) ;
  return n * ( n + 1 ) / 2 ;
}
public static void main(String args[]) {
f_gold("gZFGZsHCimLf");
}
}