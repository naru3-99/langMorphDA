import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class PROGRAM_TO_FIND_REMAINDER_WITHOUT_USING_MODULO_OR_OPERATOR_2{
static int f_gold ( int num , int divisor ) {
  while ( num >= divisor ) num -= divisor ;
  return num ;
}
public static void main(String args[]) {
f_gold(70,13);
}
}