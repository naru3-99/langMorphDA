import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MAXIMUM_PRODUCT_INCREASING_SUBSEQUENCE{
static int f_gold ( int [ ] arr , int n ) {
  int [ ] mpis = new int [ n ] ;
  int max = Integer . MIN_VALUE ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) mpis [ i ] = arr [ i ] ;
  for ( int i = 1 ;
  i < n ;
  i ++ ) for ( int j = 0 ;
  j < i ;
  j ++ ) if ( arr [ i ] > arr [ j ] && mpis [ i ] < ( mpis [ j ] * arr [ i ] ) ) mpis [ i ] = mpis [ j ] * arr [ i ] ;
  for ( int k = 0 ;
  k < mpis . length ;
  k ++ ) {
    if ( mpis [ k ] > max ) {
      max = mpis [ k ] ;
    }
  }
  return max ;
}
public static void main(String args[]) {
f_gold(new int[]{1,1,4,7,7,9,12,20,45,53,58,63,65,65,86,98,98},12);
}
}