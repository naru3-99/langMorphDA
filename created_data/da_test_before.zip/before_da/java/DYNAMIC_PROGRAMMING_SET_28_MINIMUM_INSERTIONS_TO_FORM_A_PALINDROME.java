import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class DYNAMIC_PROGRAMMING_SET_28_MINIMUM_INSERTIONS_TO_FORM_A_PALINDROME{
static int f_gold ( char str [ ] , int l , int h ) {
  if ( l > h ) return Integer . MAX_VALUE ;
  if ( l == h ) return 0 ;
  if ( l == h - 1 ) return ( str [ l ] == str [ h ] ) ? 0 : 1 ;
  return ( str [ l ] == str [ h ] ) ? f_gold ( str , l + 1 , h - 1 ) : ( Integer . min ( f_gold ( str , l , h - 1 ) , f_gold ( str , l + 1 , h ) ) + 1 ) ;
}
public static void main(String args[]) {
f_gold(new char[]{'F','F','J','K','K','L','P','S','T','V','W','Y','b','d','j','l','t','u','x','y'},11,11);
}
}