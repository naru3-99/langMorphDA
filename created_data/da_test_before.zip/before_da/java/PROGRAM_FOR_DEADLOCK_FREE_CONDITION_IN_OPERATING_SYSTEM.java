import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class PROGRAM_FOR_DEADLOCK_FREE_CONDITION_IN_OPERATING_SYSTEM{
static int f_gold ( int process , int need ) {
  int minResources = 0 ;
  minResources = process * ( need - 1 ) + 1 ;
  return minResources ;
}
public static void main(String args[]) {
f_gold(38,37);
}
}