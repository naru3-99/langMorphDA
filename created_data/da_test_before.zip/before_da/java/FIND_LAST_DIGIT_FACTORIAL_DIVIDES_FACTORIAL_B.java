import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class FIND_LAST_DIGIT_FACTORIAL_DIVIDES_FACTORIAL_B{
static int f_gold ( long A , long B ) {
  int variable = 1 ;
  if ( A == B ) return 1 ;
  else if ( ( B - A ) >= 5 ) return 0 ;
  else {
    for ( long i = A + 1 ;
    i <= B ;
    i ++ ) variable = ( int ) ( variable * ( i % 10 ) ) % 10 ;
    return variable % 10 ;
  }
}
public static void main(String args[]) {
f_gold(79L,84L);
}
}