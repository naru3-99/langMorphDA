import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MAXIMUM_GAMES_PLAYED_WINNER{
static int f_gold ( int N ) {
  int [ ] dp = new int [ N ] ;
  dp [ 0 ] = 1 ;
  dp [ 1 ] = 2 ;
  int i = 2 ;
  do {
    dp [ i ] = dp [ i - 1 ] + dp [ i - 2 ] ;
  }
  while ( dp [ i ++ ] <= N ) ;
  return ( i - 2 ) ;
}
public static void main(String args[]) {
f_gold(73);
}
}