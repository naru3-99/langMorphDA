import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class COUNT_PAIRS_TWO_SORTED_ARRAYS_WHOSE_SUM_EQUAL_GIVEN_VALUE_X_1{
static int f_gold ( int arr1 [ ] , int arr2 [ ] , int m , int n , int x ) {
  int count = 0 ;
  HashSet < Integer > us = new HashSet < Integer > ( ) ;
  for ( int i = 0 ;
  i < m ;
  i ++ ) us . add ( arr1 [ i ] ) ;
  for ( int j = 0 ;
  j < n ;
  j ++ ) if ( us . contains ( x - arr2 [ j ] ) ) count ++ ;
  return count ;
}
public static void main(String args[]) {
f_gold(new int[]{1,2,5,5,9,11,12,14,16,18,35,36,39,44,50,52,52,59,69,81,82,84,85,87,87,87,88,88,89,90,90,92,97},new int[]{5,5,8,20,20,24,25,29,34,37,43,45,48,49,59,60,68,70,70,72,72,75,76,77,79,81,84,85,86,88,95,96,96},17,29,32);
}
}