import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MAXIMUM_AREA_RECTANGLE_PICKING_FOUR_SIDES_ARRAY_1{
static int f_gold ( int arr [ ] , int n ) {
  Set < Integer > s = new HashSet < > ( ) ;
  int first = 0 , second = 0 ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) {
    if ( ! s . contains ( arr [ i ] ) ) {
      s . add ( arr [ i ] ) ;
      continue ;
    }
    if ( arr [ i ] > first ) {
      second = first ;
      first = arr [ i ] ;
    }
    else if ( arr [ i ] > second ) second = arr [ i ] ;
  }
  return ( first * second ) ;
}
public static void main(String args[]) {
f_gold(new int[]{4,6,7,8,12,13,14,15,18,18,19,19,26,26,32,32,33,34,34,36,41,43,47,47,51,51,52,53,55,56,57,60,61,71,74,75,76,77,79,87,87,87,90,95,98,99},37);
}
}