import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class N_TH_NUMBER_WHOSE_SUM_OF_DIGITS_IS_TEN_2{
public static int f_gold ( int n ) {
  int nthElement = 19 + ( n - 1 ) * 9 ;
  int outliersCount = ( int ) Math . log10 ( nthElement ) - 1 ;
  nthElement += 9 * outliersCount ;
  return nthElement ;
}
public static void main(String args[]) {
f_gold(68);
}
}