import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class N_TH_TERM_SERIES_2_12_36_80_150{
public static int f_gold ( int n ) {
  return ( n * n ) + ( n * n * n ) ;
}
public static void main(String args[]) {
f_gold(90);
}
}