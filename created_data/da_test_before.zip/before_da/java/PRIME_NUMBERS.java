import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class PRIME_NUMBERS{
static boolean f_gold ( int n ) {
  if ( n <= 1 ) return false ;
  for ( int i = 2 ;
  i < n ;
  i ++ ) if ( n % i == 0 ) return false ;
  return true ;
}
public static void main(String args[]) {
f_gold(2);
}
}