import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MAXIMUM_PRODUCT_SUBARRAY_ADDED_NEGATIVE_PRODUCT_CASE{
static int f_gold ( int arr [ ] , int n ) {
  int i ;
  int ans = Integer . MIN_VALUE ;
  int maxval = 1 ;
  int minval = 1 ;
  int prevMax ;
  for ( i = 0 ;
  i < n ;
  i ++ ) {
    if ( arr [ i ] > 0 ) {
      maxval = maxval * arr [ i ] ;
      minval = Math . min ( 1 , minval * arr [ i ] ) ;
    }
    else if ( arr [ i ] == 0 ) {
      minval = 1 ;
      maxval = 0 ;
    }
    else if ( arr [ i ] < 0 ) {
      prevMax = maxval ;
      maxval = minval * arr [ i ] ;
      minval = prevMax * arr [ i ] ;
    }
    ans = Math . max ( ans , maxval ) ;
    if ( maxval <= 0 ) {
      maxval = 1 ;
    }
  }
  return ans ;
}
public static void main(String args[]) {
f_gold(new int[]{19,25,34,39,41,51,52,53,54,56,64,67,72,87,92,93,95},15);
}
}