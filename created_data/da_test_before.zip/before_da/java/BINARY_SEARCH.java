import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class BINARY_SEARCH{
static int f_gold ( int arr [ ] , int l , int r , int x ) {
  if ( r >= l ) {
    int mid = l + ( r - l ) / 2 ;
    if ( arr [ mid ] == x ) return mid ;
    if ( arr [ mid ] > x ) return f_gold ( arr , l , mid - 1 , x ) ;
    return f_gold ( arr , mid + 1 , r , x ) ;
  }
  return - 1 ;
}
public static void main(String args[]) {
f_gold(new int[]{3,4,4,8,9,13,13,15,18,27,30,32,42,48,50,52,56,66,69,69,77,84,84,93},19,12,22);
}
}