import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class FIND_THREE_ELEMENT_FROM_DIFFERENT_THREE_ARRAYS_SUCH_THAT_THAT_A_B_C_K{
static boolean f_gold ( int a1 [ ] , int a2 [ ] , int a3 [ ] , int n1 , int n2 , int n3 , int sum ) {
  for ( int i = 0 ;
  i < n1 ;
  i ++ ) for ( int j = 0 ;
  j < n2 ;
  j ++ ) for ( int k = 0 ;
  k < n3 ;
  k ++ ) if ( a1 [ i ] + a2 [ j ] + a3 [ k ] == sum ) return true ;
  return false ;
}
public static void main(String args[]) {
f_gold(new int[]{4,9,10,19,24,25,26,30,36,43,44,49,52,62,66,69,72,77,80,80,82,84,90,93,94,98},new int[]{4,8,17,20,22,25,27,30,31,33,35,35,38,41,49,51,60,61,66,67,69,82,84,85,86,88},new int[]{12,14,17,20,22,27,29,31,32,38,41,43,56,59,59,64,66,67,68,69,71,76,83,83,85,99},25,18,16,222);
}
}