import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class FIND_THREE_ELEMENT_FROM_DIFFERENT_THREE_ARRAYS_SUCH_THAT_THAT_A_B_C_K_1{
static boolean f_gold ( int a1 [ ] , int a2 [ ] , int a3 [ ] , int n1 , int n2 , int n3 , int sum ) {
  HashSet < Integer > s = new HashSet < Integer > ( ) ;
  for ( int i = 0 ;
  i < n1 ;
  i ++ ) {
    s . add ( a1 [ i ] ) ;
  }
  ArrayList < Integer > al = new ArrayList < > ( s ) ;
  for ( int i = 0 ;
  i < n2 ;
  i ++ ) {
    for ( int j = 0 ;
    j < n3 ;
    j ++ ) {
      if ( al . contains ( sum - a2 [ i ] - a3 [ j ] ) & al . indexOf ( sum - a2 [ i ] - a3 [ j ] ) != al . get ( al . size ( ) - 1 ) ) {
        return true ;
      }
    }
  }
  return false ;
}
public static void main(String args[]) {
f_gold(new int[]{6,7,10,15,28,30,30,35,38,43,44,44,54,55,64,68,69,73,75,75,86,87,92,93,94},new int[]{11,17,18,24,26,26,33,35,38,41,55,60,63,63,69,73,78,81,82,87,90,91,93,94,99},new int[]{3,3,8,22,24,24,28,30,32,32,34,39,40,45,46,50,54,59,75,78,79,90,95,95,97},21,16,17,18);
}
}