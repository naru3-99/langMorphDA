import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class CHECK_IF_A_NUMBER_IS_JUMBLED_OR_NOT{
static boolean f_gold ( int num ) {
  if ( num / 10 == 0 ) return true ;
  while ( num != 0 ) {
    if ( num / 10 == 0 ) return true ;
    int digit1 = num % 10 ;
    int digit2 = ( num / 10 ) % 10 ;
    if ( Math . abs ( digit2 - digit1 ) > 1 ) return false ;
    num = num / 10 ;
  }
  return true ;
}
public static void main(String args[]) {
f_gold(67);
}
}