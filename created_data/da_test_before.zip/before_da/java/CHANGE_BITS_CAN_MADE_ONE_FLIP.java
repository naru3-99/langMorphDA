import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class CHANGE_BITS_CAN_MADE_ONE_FLIP{
static boolean f_gold ( String str ) {
  int zeros = 0 , ones = 0 ;
  for ( int i = 0 ;
  i < str . length ( ) ;
  i ++ ) {
    char ch = str . charAt ( i ) ;
    if ( ch == '0' ) ++ zeros ;
    else ++ ones ;
  }
  return ( zeros == 1 || ones == 1 ) ;
}
public static void main(String args[]) {
f_gold("00001");
}
}