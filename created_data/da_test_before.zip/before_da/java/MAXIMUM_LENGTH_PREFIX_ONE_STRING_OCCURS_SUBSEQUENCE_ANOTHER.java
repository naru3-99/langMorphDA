import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MAXIMUM_LENGTH_PREFIX_ONE_STRING_OCCURS_SUBSEQUENCE_ANOTHER{
static int f_gold ( String s , String t ) {
  int count = 0 ;
  for ( int i = 0 ;
  i < t . length ( ) ;
  i ++ ) {
    if ( count == t . length ( ) ) break ;
    if ( t . charAt ( i ) == s . charAt ( count ) ) count ++ ;
  }
  return count ;
}
public static void main(String args[]) {
f_gold("nObYIOjEQZ","uARTDTQbmGI");
}
}