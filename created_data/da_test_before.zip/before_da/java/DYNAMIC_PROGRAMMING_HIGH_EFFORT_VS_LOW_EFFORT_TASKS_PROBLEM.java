import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class DYNAMIC_PROGRAMMING_HIGH_EFFORT_VS_LOW_EFFORT_TASKS_PROBLEM{
static int f_gold ( int high [ ] , int low [ ] , int n ) {
  if ( n <= 0 ) return 0 ;
  return Math . max ( high [ n - 1 ] + f_gold ( high , low , ( n - 2 ) ) , low [ n - 1 ] + f_gold ( high , low , ( n - 1 ) ) ) ;
}
public static void main(String args[]) {
f_gold(new int[]{1,3,9,10,13,14,15,15,17,22,23,28,30,31,37,42,45,62,62,68,68,68,78,79,82,84,87,90,99},new int[]{5,10,11,14,16,22,24,30,34,35,37,37,39,41,42,42,43,55,57,63,71,76,83,83,85,90,91,97,99},18);
}
}