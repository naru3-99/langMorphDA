import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MAXIMIZE_VOLUME_CUBOID_GIVEN_SUM_SIDES{
static int f_gold ( int s ) {
  int maxvalue = 0 ;
  for ( int i = 1 ;
  i <= s - 2 ;
  i ++ ) {
    for ( int j = 1 ;
    j <= s - 1 ;
    j ++ ) {
      int k = s - i - j ;
      maxvalue = Math . max ( maxvalue , i * j * k ) ;
    }
  }
  return maxvalue ;
}
public static void main(String args[]) {
f_gold(67);
}
}