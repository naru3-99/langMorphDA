import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class NUMBER_RECTANGLES_NM_GRID{
public static long f_gold ( int n , int m ) {
  return ( m * n * ( n + 1 ) * ( m + 1 ) ) / 4 ;
}
public static void main(String args[]) {
f_gold(86,70);
}
}