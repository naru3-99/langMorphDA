import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class FIND_THE_ELEMENT_THAT_APPEARS_ONCE{
static int f_gold ( int arr [ ] , int n ) {
  int ones = 0 , twos = 0 ;
  int common_bit_mask ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) {
    twos = twos | ( ones & arr [ i ] ) ;
    ones = ones ^ arr [ i ] ;
    common_bit_mask = ~ ( ones & twos ) ;
    ones &= common_bit_mask ;
    twos &= common_bit_mask ;
  }
  return ones ;
}
public static void main(String args[]) {
f_gold(new int[]{7,26,26,48,59,62,66,70,72,75,76,81,97,98},7);
}
}