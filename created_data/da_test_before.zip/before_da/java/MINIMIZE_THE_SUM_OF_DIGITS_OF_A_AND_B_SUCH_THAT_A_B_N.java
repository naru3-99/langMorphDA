import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MINIMIZE_THE_SUM_OF_DIGITS_OF_A_AND_B_SUCH_THAT_A_B_N{
static int f_gold ( int n ) {
  int sum = 0 ;
  while ( n > 0 ) {
    sum += ( n % 10 ) ;
    n /= 10 ;
  }
  if ( sum == 1 ) return 10 ;
  return sum ;
}
public static void main(String args[]) {
f_gold(2);
}
}