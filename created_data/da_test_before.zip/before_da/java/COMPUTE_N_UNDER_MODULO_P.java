import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class COMPUTE_N_UNDER_MODULO_P{
static int f_gold ( int n , int p ) {
  if ( n >= p ) return 0 ;
  int result = 1 ;
  for ( int i = 1 ;
  i <= n ;
  i ++ ) result = ( result * i ) % p ;
  return result ;
}
public static void main(String args[]) {
f_gold(85,18);
}
}