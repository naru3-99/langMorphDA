import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class FIND_WHETHER_A_GIVEN_NUMBER_IS_A_POWER_OF_4_OR_NOT{
static int f_gold ( int n ) {
  if ( n == 0 ) return 0 ;
  while ( n != 1 ) {
    if ( n % 4 != 0 ) return 0 ;
    n = n / 4 ;
  }
  return 1 ;
}
public static void main(String args[]) {
f_gold(45);
}
}