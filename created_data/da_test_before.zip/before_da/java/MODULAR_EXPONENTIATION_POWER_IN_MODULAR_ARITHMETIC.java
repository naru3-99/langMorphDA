import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MODULAR_EXPONENTIATION_POWER_IN_MODULAR_ARITHMETIC{
static int f_gold ( int x , int y , int p ) {
  int res = 1 ;
  x = x % p ;
  while ( y > 0 ) {
    if ( ( y & 1 ) == 1 ) res = ( res * x ) % p ;
    y = y >> 1 ;
    x = ( x * x ) % p ;
  }
  return res ;
}
public static void main(String args[]) {
f_gold(45,5,68);
}
}