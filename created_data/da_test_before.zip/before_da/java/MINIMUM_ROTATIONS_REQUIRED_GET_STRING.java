import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MINIMUM_ROTATIONS_REQUIRED_GET_STRING{
static int f_gold ( String str ) {
  String tmp = str + str ;
  int n = str . length ( ) ;
  for ( int i = 1 ;
  i <= n ;
  i ++ ) {
    String substring = tmp . substring ( i , str . length ( ) ) ;
    if ( str == substring ) return i ;
  }
  return n ;
}
public static void main(String args[]) {
f_gold("vdevdNdQSopPtj");
}
}