import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class CHECK_REVERSING_SUB_ARRAY_MAKE_ARRAY_SORTED{
static boolean f_gold ( int arr [ ] , int n ) {
  int temp [ ] = new int [ n ] ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) {
    temp [ i ] = arr [ i ] ;
  }
  Arrays . sort ( temp ) ;
  int front ;
  for ( front = 0 ;
  front < n ;
  front ++ ) {
    if ( temp [ front ] != arr [ front ] ) {
      break ;
    }
  }
  int back ;
  for ( back = n - 1 ;
  back >= 0 ;
  back -- ) {
    if ( temp [ back ] != arr [ back ] ) {
      break ;
    }
  }
  if ( front >= back ) {
    return true ;
  }
  do {
    front ++ ;
    if ( arr [ front - 1 ] < arr [ front ] ) {
      return false ;
    }
  }
  while ( front != back ) ;
  return true ;
}
public static void main(String args[]) {
f_gold(new int[]{5,9,9,16,17,22,32,40,45,53,57,58,66,69,76,80,91,93,94},10);
}
}