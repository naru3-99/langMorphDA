import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class PROGRAM_PRINT_SUM_GIVEN_NTH_TERM_1{
static int f_gold ( long n ) {
  return ( int ) Math . pow ( n , 2 ) ;
}
public static void main(String args[]) {
f_gold(42L);
}
}