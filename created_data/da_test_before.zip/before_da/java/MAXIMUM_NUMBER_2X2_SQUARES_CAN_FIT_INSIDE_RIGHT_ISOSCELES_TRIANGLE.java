import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MAXIMUM_NUMBER_2X2_SQUARES_CAN_FIT_INSIDE_RIGHT_ISOSCELES_TRIANGLE{
public static int f_gold ( int base ) {
  base = ( base - 2 ) ;
  base = base / 2 ;
  return base * ( base + 1 ) / 2 ;
}
public static void main(String args[]) {
f_gold(95);
}
}