import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MAXIMUM_TRIPLET_SUM_ARRAY_1{
static int f_gold ( int arr [ ] , int n ) {
  Arrays . sort ( arr ) ;
  return arr [ n - 1 ] + arr [ n - 2 ] + arr [ n - 3 ] ;
}
public static void main(String args[]) {
f_gold(new int[]{6,8,18,18,27,33,33,38,42,43,44,47,52,58,64,65,67,68,71,75,85,89,91,94,94,95,95},26);
}
}