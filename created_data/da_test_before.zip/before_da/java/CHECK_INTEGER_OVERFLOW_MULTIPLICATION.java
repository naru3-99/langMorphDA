import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class CHECK_INTEGER_OVERFLOW_MULTIPLICATION{
static Boolean f_gold ( long a , long b ) {
  if ( a == 0 || b == 0 ) return false ;
  long result = a * b ;
  if ( a == result / b ) return false ;
  else return true ;
}
public static void main(String args[]) {
f_gold(37L,80L);
}
}