import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MAXIMUM_LENGTH_SUBSEQUENCE_DIFFERENCE_ADJACENT_ELEMENTS_EITHER_0_1{
public static int f_gold ( int arr [ ] , int n ) {
  int mls [ ] = new int [ n ] , max = 0 ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) mls [ i ] = 1 ;
  for ( int i = 1 ;
  i < n ;
  i ++ ) for ( int j = 0 ;
  j < i ;
  j ++ ) if ( Math . abs ( arr [ i ] - arr [ j ] ) <= 1 && mls [ i ] < mls [ j ] + 1 ) mls [ i ] = mls [ j ] + 1 ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) if ( max < mls [ i ] ) max = mls [ i ] ;
  return max ;
}
public static void main(String args[]) {
f_gold(new int[]{4,5,9,31,31,37,41,55,56,61,79,81,89,93},12);
}
}