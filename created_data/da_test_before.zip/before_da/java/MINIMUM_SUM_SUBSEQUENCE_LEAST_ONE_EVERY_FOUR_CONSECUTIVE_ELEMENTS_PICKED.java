import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MINIMUM_SUM_SUBSEQUENCE_LEAST_ONE_EVERY_FOUR_CONSECUTIVE_ELEMENTS_PICKED{
static int f_gold ( int [ ] arr , int n ) {
  int [ ] dp = new int [ n ] ;
  if ( n == 1 ) return arr [ 0 ] ;
  if ( n == 2 ) return Math . min ( arr [ 0 ] , arr [ 1 ] ) ;
  if ( n == 3 ) return Math . min ( arr [ 0 ] , Math . min ( arr [ 1 ] , arr [ 2 ] ) ) ;
  if ( n == 4 ) return Math . min ( Math . min ( arr [ 0 ] , arr [ 1 ] ) , Math . min ( arr [ 2 ] , arr [ 3 ] ) ) ;
  dp [ 0 ] = arr [ 0 ] ;
  dp [ 1 ] = arr [ 1 ] ;
  dp [ 2 ] = arr [ 2 ] ;
  dp [ 3 ] = arr [ 3 ] ;
  for ( int i = 4 ;
  i < n ;
  i ++ ) dp [ i ] = arr [ i ] + Math . min ( Math . min ( dp [ i - 1 ] , dp [ i - 2 ] ) , Math . min ( dp [ i - 3 ] , dp [ i - 4 ] ) ) ;
  return Math . min ( Math . min ( dp [ n - 1 ] , dp [ n - 2 ] ) , Math . min ( dp [ n - 4 ] , dp [ n - 3 ] ) ) ;
}
public static void main(String args[]) {
f_gold(new int[]{2,7,11,12,13,14,18,20,22,26,28,29,31,32,33,35,38,38,40,40,41,42,43,44,45,53,54,54,59,62,69,72,74,75,75,76,79,83,84,89,91,96,97,98,99,99},30);
}
}