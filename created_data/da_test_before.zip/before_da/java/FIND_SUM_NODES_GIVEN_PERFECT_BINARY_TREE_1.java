import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class FIND_SUM_NODES_GIVEN_PERFECT_BINARY_TREE_1{
static double f_gold ( int l ) {
  double leafNodeCount = Math . pow ( 2 , l - 1 ) ;
  double sumLastLevel = 0 ;
  sumLastLevel = ( leafNodeCount * ( leafNodeCount + 1 ) ) / 2 ;
  double sum = sumLastLevel * l ;
  return sum ;
}
public static void main(String args[]) {
f_gold(5);
}
}