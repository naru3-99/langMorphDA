import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class ELEMENTS_TO_BE_ADDED_SO_THAT_ALL_ELEMENTS_OF_A_RANGE_ARE_PRESENT_IN_ARRAY_1{
static int f_gold ( int arr [ ] , int n ) {
  HashSet < Integer > s = new HashSet < > ( ) ;
  int count = 0 , maxm = Integer . MIN_VALUE , minm = Integer . MAX_VALUE ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) {
    s . add ( arr [ i ] ) ;
    if ( arr [ i ] < minm ) minm = arr [ i ] ;
    if ( arr [ i ] > maxm ) maxm = arr [ i ] ;
  }
  for ( int i = minm ;
  i <= maxm ;
  i ++ ) if ( ! s . contains ( i ) ) count ++ ;
  return count ;
}
public static void main(String args[]) {
f_gold(new int[]{1,4,5,5,11,11,12,14,16,20,23,23,25,27,29,33,33,35,37,39,39,44,44,45,47,51,51,53,55,65,73,73,75,78,79,79,80,82,86,86,87,87,88,90,91,91,94},26);
}
}