import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class PROGRAM_CIRCUMFERENCE_PARALLELOGRAM{
static float f_gold ( float a , float b ) {
  return ( ( 2 * a ) + ( 2 * b ) ) ;
}
public static void main(String args[]) {
f_gold(801.0366882228715F,456.71190645582783F);
}
}