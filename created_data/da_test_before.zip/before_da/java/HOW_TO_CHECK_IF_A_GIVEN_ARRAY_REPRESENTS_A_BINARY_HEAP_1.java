import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class HOW_TO_CHECK_IF_A_GIVEN_ARRAY_REPRESENTS_A_BINARY_HEAP_1{
static boolean f_gold ( int arr [ ] , int n ) {
  for ( int i = 0 ;
  i <= ( n - 2 ) / 2 ;
  i ++ ) {
    if ( arr [ 2 * i + 1 ] > arr [ i ] ) {
      return false ;
    }
    if ( 2 * i + 2 < n && arr [ 2 * i + 2 ] > arr [ i ] ) {
      return false ;
    }
  }
  return true ;
}
public static void main(String args[]) {
f_gold(new int[]{2,2,2,7,10,14,24,38,42,50,59,60,72,73,79,83,89},9);
}
}