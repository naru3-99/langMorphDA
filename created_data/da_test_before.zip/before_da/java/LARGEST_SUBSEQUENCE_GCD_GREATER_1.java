import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class LARGEST_SUBSEQUENCE_GCD_GREATER_1{
static int f_gold ( int arr [ ] , int n ) {
  int ans = 0 ;
  int maxele = Arrays . stream ( arr ) . max ( ) . getAsInt ( ) ;
  ;
  for ( int i = 2 ;
  i <= maxele ;
  ++ i ) {
    int count = 0 ;
    for ( int j = 0 ;
    j < n ;
    ++ j ) {
      if ( arr [ j ] % i == 0 ) ++ count ;
    }
    ans = Math . max ( ans , count ) ;
  }
  return ans ;
}
public static void main(String args[]) {
f_gold(new int[]{10,18,22,22,22,29,30,32,33,34,37,39,40,41,44,47,49,50,50,51,53,67,69,70,71,71,73,75,78,80,81,82,91,91,93,97,97,99},35);
}
}