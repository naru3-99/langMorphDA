import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class DIVISIBILITY_BY_7{
static boolean f_gold ( int num ) {
  if ( num < 0 ) return f_gold ( - num ) ;
  if ( num == 0 || num == 7 ) return true ;
  if ( num < 10 ) return false ;
  return f_gold ( num / 10 - 2 * ( num - num / 10 * 10 ) ) ;
}
public static void main(String args[]) {
f_gold(0);
}
}