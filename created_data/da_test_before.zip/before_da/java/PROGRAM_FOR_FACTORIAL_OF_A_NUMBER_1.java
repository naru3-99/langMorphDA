import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class PROGRAM_FOR_FACTORIAL_OF_A_NUMBER_1{
static int f_gold ( int n ) {
  int res = 1 , i ;
  for ( i = 2 ;
  i <= n ;
  i ++ ) res *= i ;
  return res ;
}
public static void main(String args[]) {
f_gold(57);
}
}