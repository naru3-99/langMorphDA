import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class FIND_THE_MISSING_NUMBER_2{
static int f_gold ( int a [ ] , int n ) {
  int x1 = a [ 0 ] ;
  int x2 = 1 ;
  for ( int i = 1 ;
  i < n ;
  i ++ ) x1 = x1 ^ a [ i ] ;
  for ( int i = 2 ;
  i <= n + 1 ;
  i ++ ) x2 = x2 ^ i ;
  return ( x1 ^ x2 ) ;
}
public static void main(String args[]) {
f_gold(new int[]{2,5,7,8,10,14,27,32,51,52,57,58,65,68,68,72,73,73,83,92,98},12);
}
}