import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class LONGEST_REPEATING_AND_NON_OVERLAPPING_SUBSTRING{
static String f_gold ( String str ) {
  int n = str . length ( ) ;
  int LCSRe [ ] [ ] = new int [ n + 1 ] [ n + 1 ] ;
  String res = "" ;
  int res_length = 0 ;
  int i , index = 0 ;
  for ( i = 1 ;
  i <= n ;
  i ++ ) {
    for ( int j = i + 1 ;
    j <= n ;
    j ++ ) {
      if ( str . charAt ( i - 1 ) == str . charAt ( j - 1 ) && LCSRe [ i - 1 ] [ j - 1 ] < ( j - i ) ) {
        LCSRe [ i ] [ j ] = LCSRe [ i - 1 ] [ j - 1 ] + 1 ;
        if ( LCSRe [ i ] [ j ] > res_length ) {
          res_length = LCSRe [ i ] [ j ] ;
          index = Math . max ( i , index ) ;
        }
      }
      else {
        LCSRe [ i ] [ j ] = 0 ;
      }
    }
  }
  if ( res_length > 0 ) {
    for ( i = index - res_length + 1 ;
    i <= index ;
    i ++ ) {
      res += str . charAt ( i - 1 ) ;
    }
  }
  return res ;
}
public static void main(String args[]) {
f_gold("fbfHTjE");
}
}