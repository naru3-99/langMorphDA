import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class ELEMENTS_TO_BE_ADDED_SO_THAT_ALL_ELEMENTS_OF_A_RANGE_ARE_PRESENT_IN_ARRAY{
static int f_gold ( int [ ] arr , int n ) {
  int count = 0 ;
  Arrays . sort ( arr ) ;
  for ( int i = 0 ;
  i < n - 1 ;
  i ++ ) if ( arr [ i ] != arr [ i + 1 ] && arr [ i ] != arr [ i + 1 ] - 1 ) count += arr [ i + 1 ] - arr [ i ] - 1 ;
  return count ;
}
public static void main(String args[]) {
f_gold(new int[]{4,4,5,7,7,9,13,15,18,19,25,27,27,29,32,36,48,51,53,53,55,65,66,67,72,74,74,76,77,79,80,81,82,83,83,86,87,97,98,98,99},30);
}
}