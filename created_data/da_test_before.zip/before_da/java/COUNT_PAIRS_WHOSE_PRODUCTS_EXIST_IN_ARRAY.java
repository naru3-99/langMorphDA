import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class COUNT_PAIRS_WHOSE_PRODUCTS_EXIST_IN_ARRAY{
static int f_gold ( int arr [ ] , int n ) {
  int result = 0 ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) {
    for ( int j = i + 1 ;
    j < n ;
    j ++ ) {
      int product = arr [ i ] * arr [ j ] ;
      for ( int k = 0 ;
      k < n ;
      k ++ ) {
        if ( arr [ k ] == product ) {
          result ++ ;
          break ;
        }
      }
    }
  }
  return result ;
}
public static void main(String args[]) {
f_gold(new int[]{3,7,26,40,46,89,99},5);
}
}