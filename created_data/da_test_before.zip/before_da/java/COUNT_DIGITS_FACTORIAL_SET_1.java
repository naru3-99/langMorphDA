import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class COUNT_DIGITS_FACTORIAL_SET_1{
static int f_gold ( int n ) {
  if ( n < 0 ) return 0 ;
  if ( n <= 1 ) return 1 ;
  double digits = 0 ;
  for ( int i = 2 ;
  i <= n ;
  i ++ ) digits += Math . log10 ( i ) ;
  return ( int ) ( Math . floor ( digits ) ) + 1 ;
}
public static void main(String args[]) {
f_gold(66);
}
}