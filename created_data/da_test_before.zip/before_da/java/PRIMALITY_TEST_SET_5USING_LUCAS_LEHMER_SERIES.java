import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class PRIMALITY_TEST_SET_5USING_LUCAS_LEHMER_SERIES{
static boolean f_gold ( int p ) {
  double checkNumber = Math . pow ( 2 , p ) - 1 ;
  double nextval = 4 % checkNumber ;
  for ( int i = 1 ;
  i < p - 1 ;
  i ++ ) nextval = ( nextval * nextval - 2 ) % checkNumber ;
  return ( nextval == 0 ) ;
}
public static void main(String args[]) {
f_gold(11);
}
}