import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class POSITION_ELEMENT_STABLE_SORT{
static int f_gold ( int arr [ ] , int n , int idx ) {
  int result = 0 ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) {
    if ( arr [ i ] < arr [ idx ] ) result ++ ;
    if ( arr [ i ] == arr [ idx ] && i < idx ) result ++ ;
  }
  return result ;
}
public static void main(String args[]) {
f_gold(new int[]{4,8,9,12,15,16,18,28,28,31,33,36,36,37,40,41,44,44,46,50,50,50,52,52,54,55,60,61,65,68,71,75,75,78,81,84,87,89,90,92,94,97,97,98,98,99},37,32);
}
}