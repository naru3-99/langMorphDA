import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class FIND_INDEX_GIVEN_FIBONACCI_NUMBER_CONSTANT_TIME_1{
static int f_gold ( int n ) {
  float fibo = 2.078087F * ( float ) Math . log ( n ) + 1.672276F ;
  return Math . round ( fibo ) ;
}
public static void main(String args[]) {
f_gold(20);
}
}