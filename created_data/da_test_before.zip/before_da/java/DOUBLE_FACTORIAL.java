import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class DOUBLE_FACTORIAL{
static long f_gold ( long n ) {
  if ( n == 0 || n == 1 ) return 1 ;
  return n * f_gold ( n - 2 ) ;
}
public static void main(String args[]) {
f_gold(52L);
}
}