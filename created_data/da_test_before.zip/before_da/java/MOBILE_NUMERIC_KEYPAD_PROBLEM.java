import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MOBILE_NUMERIC_KEYPAD_PROBLEM{
static int f_gold ( char keypad [ ] [ ] , int n ) {
  if ( keypad == null || n <= 0 ) return 0 ;
  if ( n == 1 ) return 10 ;
  int [ ] odd = new int [ 10 ] ;
  int [ ] even = new int [ 10 ] ;
  int i = 0 , j = 0 , useOdd = 0 , totalCount = 0 ;
  for ( i = 0 ;
  i <= 9 ;
  i ++ ) odd [ i ] = 1 ;
  for ( j = 2 ;
  j <= n ;
  j ++ ) {
    useOdd = 1 - useOdd ;
    if ( useOdd == 1 ) {
      even [ 0 ] = odd [ 0 ] + odd [ 8 ] ;
      even [ 1 ] = odd [ 1 ] + odd [ 2 ] + odd [ 4 ] ;
      even [ 2 ] = odd [ 2 ] + odd [ 1 ] + odd [ 3 ] + odd [ 5 ] ;
      even [ 3 ] = odd [ 3 ] + odd [ 2 ] + odd [ 6 ] ;
      even [ 4 ] = odd [ 4 ] + odd [ 1 ] + odd [ 5 ] + odd [ 7 ] ;
      even [ 5 ] = odd [ 5 ] + odd [ 2 ] + odd [ 4 ] + odd [ 8 ] + odd [ 6 ] ;
      even [ 6 ] = odd [ 6 ] + odd [ 3 ] + odd [ 5 ] + odd [ 9 ] ;
      even [ 7 ] = odd [ 7 ] + odd [ 4 ] + odd [ 8 ] ;
      even [ 8 ] = odd [ 8 ] + odd [ 0 ] + odd [ 5 ] + odd [ 7 ] + odd [ 9 ] ;
      even [ 9 ] = odd [ 9 ] + odd [ 6 ] + odd [ 8 ] ;
    }
    else {
      odd [ 0 ] = even [ 0 ] + even [ 8 ] ;
      odd [ 1 ] = even [ 1 ] + even [ 2 ] + even [ 4 ] ;
      odd [ 2 ] = even [ 2 ] + even [ 1 ] + even [ 3 ] + even [ 5 ] ;
      odd [ 3 ] = even [ 3 ] + even [ 2 ] + even [ 6 ] ;
      odd [ 4 ] = even [ 4 ] + even [ 1 ] + even [ 5 ] + even [ 7 ] ;
      odd [ 5 ] = even [ 5 ] + even [ 2 ] + even [ 4 ] + even [ 8 ] + even [ 6 ] ;
      odd [ 6 ] = even [ 6 ] + even [ 3 ] + even [ 5 ] + even [ 9 ] ;
      odd [ 7 ] = even [ 7 ] + even [ 4 ] + even [ 8 ] ;
      odd [ 8 ] = even [ 8 ] + even [ 0 ] + even [ 5 ] + even [ 7 ] + even [ 9 ] ;
      odd [ 9 ] = even [ 9 ] + even [ 6 ] + even [ 8 ] ;
    }
  }
  totalCount = 0 ;
  if ( useOdd == 1 ) {
    for ( i = 0 ;
    i <= 9 ;
    i ++ ) totalCount += even [ i ] ;
  }
  else {
    for ( i = 0 ;
    i <= 9 ;
    i ++ ) totalCount += odd [ i ] ;
  }
  return totalCount ;
}
public static void main(String args[]) {
f_gold(new char[][]{new char[]{' ','A','C','K','R','R','V','c','d','i','i','j','m','o','q','q','r','r','v','v','x','z'},new char[]{'B','D','I','M','N','Q','R','Z','c','f','i','j','j','l','l','n','p','q','s','t','t','w'},new char[]{'A','F','F','G','H','J','K','K','N','V','V','b','c','c','g','i','j','l','l','s','t','y'},new char[]{' ','A','B','B','E','H','I','J','J','P','Q','T','U','V','Z','c','c','j','p','w','y','z'},new char[]{' ',' ','A','C','F','G','H','M','N','R','R','V','c','i','j','o','p','p','q','r','w','y'},new char[]{' ',' ','C','C','D','H','I','J','K','O','S','X','Y','f','h','h','o','p','p','u','u','w'},new char[]{'B','C','D','H','M','M','Q','Q','R','S','X','Z','e','e','e','j','k','l','m','o','v','w'},new char[]{'A','C','C','D','H','H','I','J','L','L','L','M','N','S','U','c','d','f','f','s','u','y'},new char[]{'A','B','D','D','I','J','K','L','L','M','P','S','S','Y','b','e','h','j','m','o','q','s'},new char[]{' ','B','E','H','H','J','M','P','S','T','U','V','Z','d','j','m','m','p','q','v','w','w'},new char[]{'B','E','F','G','H','M','M','M','N','O','Q','R','T','V','a','c','g','g','i','s','x','y'},new char[]{'A','E','G','J','O','R','R','S','T','W','a','b','f','h','h','i','m','n','s','u','v','y'},new char[]{'B','D','E','H','I','I','K','M','N','P','Q','S','a','e','i','j','m','o','p','r','x','z'},new char[]{'A','G','I','K','K','L','O','P','U','U','X','X','Z','a','c','f','g','i','l','o','o','v'},new char[]{' ',' ','E','H','J','J','L','M','N','O','P','S','S','X','c','f','g','r','u','v','x','z'},new char[]{'C','E','F','F','H','H','I','K','M','M','U','Z','e','e','h','h','h','j','k','k','p','r'},new char[]{' ',' ',' ','C','G','I','J','O','O','P','T','V','Y','b','j','n','o','o','s','u','w','x'},new char[]{'A','D','F','F','H','H','N','R','S','W','W','Y','Y','b','f','i','k','o','u','y','y','z'},new char[]{' ','C','G','I','I','L','P','S','X','Y','d','d','f','g','g','k','m','o','r','r','r','x'},new char[]{'F','I','J','N','P','P','Q','Q','R','X','Y','a','b','h','h','j','l','m','n','p','r','y'},new char[]{' ','C','D','E','F','L','Q','Q','V','c','g','h','k','k','l','l','n','o','p','r','u','x'},new char[]{' ','A','G','K','L','M','T','U','U','W','Z','a','f','i','k','k','n','n','p','q','v','z'}},13);
}
}