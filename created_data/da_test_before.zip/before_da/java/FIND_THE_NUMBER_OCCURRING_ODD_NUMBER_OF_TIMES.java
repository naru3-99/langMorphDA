import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class FIND_THE_NUMBER_OCCURRING_ODD_NUMBER_OF_TIMES{
static int f_gold ( int arr [ ] , int arr_size ) {
  int i ;
  for ( i = 0 ;
  i < arr_size ;
  i ++ ) {
    int count = 0 ;
    for ( int j = 0 ;
    j < arr_size ;
    j ++ ) {
      if ( arr [ i ] == arr [ j ] ) count ++ ;
    }
    if ( count % 2 != 0 ) return arr [ i ] ;
  }
  return - 1 ;
}
public static void main(String args[]) {
f_gold(new int[]{1,5,5,8,14,15,17,17,18,23,23,25,26,35,36,39,51,53,56,56,60,62,64,64,65,66,67,68,71,75,80,82,83,88,89,91,91,92,93,95,99},31);
}
}