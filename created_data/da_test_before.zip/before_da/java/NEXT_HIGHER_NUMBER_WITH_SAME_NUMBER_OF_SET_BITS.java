import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class NEXT_HIGHER_NUMBER_WITH_SAME_NUMBER_OF_SET_BITS{
static int f_gold ( int x ) {
  int rightOne , nextHigherOneBit , rightOnesPattern , next = 0 ;
  if ( x > 0 ) {
    rightOne = x & - x ;
    nextHigherOneBit = x + rightOne ;
    rightOnesPattern = x ^ nextHigherOneBit ;
    rightOnesPattern = ( rightOnesPattern ) / rightOne ;
    rightOnesPattern >>= 2 ;
    next = nextHigherOneBit | rightOnesPattern ;
  }
  return next ;
}
public static void main(String args[]) {
f_gold(42);
}
}