import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MINIMUM_PERIMETER_N_BLOCKS{
public static long f_gold ( int n ) {
  int l = ( int ) Math . sqrt ( n ) ;
  int sq = l * l ;
  if ( sq == n ) return l * 4 ;
  else {
    long row = n / l ;
    long perimeter = 2 * ( l + row ) ;
    if ( n % l != 0 ) perimeter += 2 ;
    return perimeter ;
  }
}
public static void main(String args[]) {
f_gold(45);
}
}