import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class LONGEST_SUBSEQUENCE_SUCH_THAT_DIFFERENCE_BETWEEN_ADJACENTS_IS_ONE{
static int f_gold ( int arr [ ] , int n ) {
  int dp [ ] = new int [ n ] ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) dp [ i ] = 1 ;
  for ( int i = 1 ;
  i < n ;
  i ++ ) {
    for ( int j = 0 ;
    j < i ;
    j ++ ) {
      if ( ( arr [ i ] == arr [ j ] + 1 ) || ( arr [ i ] == arr [ j ] - 1 ) ) dp [ i ] = Math . max ( dp [ i ] , dp [ j ] + 1 ) ;
    }
  }
  int result = 1 ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) if ( result < dp [ i ] ) result = dp [ i ] ;
  return result ;
}
public static void main(String args[]) {
f_gold(new int[]{2,13,15,17,18,20,22,24,28,34,37,43,46,47,49,51,52,54,58,64,65,77,78,79,87,90,92,93,94,97},23);
}
}