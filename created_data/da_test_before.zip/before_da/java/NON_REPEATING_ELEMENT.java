import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class NON_REPEATING_ELEMENT{
static int f_gold ( int arr [ ] , int n ) {
  for ( int i = 0 ;
  i < n ;
  i ++ ) {
    int j ;
    for ( j = 0 ;
    j < n ;
    j ++ ) if ( i != j && arr [ i ] == arr [ j ] ) break ;
    if ( j == n ) return arr [ i ] ;
  }
  return - 1 ;
}
public static void main(String args[]) {
f_gold(new int[]{1,2,3,4,6,6,7,9,10,13,16,23,30,32,36,42,42,43,44,47,48,48,49,52,52,53,55,56,58,59,60,60,63,67,68,68,74,75,76,80,81,81,83,83,86,87,91,92,97},47);
}
}