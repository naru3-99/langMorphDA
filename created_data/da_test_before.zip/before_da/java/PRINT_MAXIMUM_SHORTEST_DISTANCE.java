import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class PRINT_MAXIMUM_SHORTEST_DISTANCE{
static int f_gold ( int a [ ] , int n , int k ) {
  HashMap < Integer , Integer > b = new HashMap < Integer , Integer > ( ) ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) {
    int x = a [ i ] ;
    int d = Math . min ( 1 + i , n - i ) ;
    if ( ! b . containsKey ( x ) ) b . put ( x , d ) ;
    else {
      b . put ( x , Math . min ( d , b . get ( x ) ) ) ;
    }
  }
  int ans = Integer . MAX_VALUE ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) {
    int x = a [ i ] ;
    if ( x != k - x && b . containsKey ( k - x ) ) ans = Math . min ( Math . max ( b . get ( x ) , b . get ( k - x ) ) , ans ) ;
  }
  return ans ;
}
public static void main(String args[]) {
f_gold(new int[]{2,27,66,89,96,96},4,4);
}
}