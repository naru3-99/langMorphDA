import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class PROGRAM_TO_CHECK_IF_A_GIVEN_NUMBER_IS_LUCKY_ALL_DIGITS_ARE_DIFFERENT{
static boolean f_gold ( int n ) {
  boolean arr [ ] = new boolean [ 10 ] ;
  for ( int i = 0 ;
  i < 10 ;
  i ++ ) arr [ i ] = false ;
  while ( n > 0 ) {
    int digit = n % 10 ;
    if ( arr [ digit ] ) return false ;
    arr [ digit ] = true ;
    n = n / 10 ;
  }
  return true ;
}
public static void main(String args[]) {
f_gold(474);
}
}