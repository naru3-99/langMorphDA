import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class FRIENDS_PAIRING_PROBLEM{
static int f_gold ( int n ) {
  int dp [ ] = new int [ n + 1 ] ;
  for ( int i = 0 ;
  i <= n ;
  i ++ ) {
    if ( i <= 2 ) dp [ i ] = i ;
    else dp [ i ] = dp [ i - 1 ] + ( i - 1 ) * dp [ i - 2 ] ;
  }
  return dp [ n ] ;
}
public static void main(String args[]) {
f_gold(99);
}
}