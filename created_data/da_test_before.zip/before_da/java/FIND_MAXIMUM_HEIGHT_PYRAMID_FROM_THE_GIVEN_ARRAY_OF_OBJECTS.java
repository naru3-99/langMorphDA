import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class FIND_MAXIMUM_HEIGHT_PYRAMID_FROM_THE_GIVEN_ARRAY_OF_OBJECTS{
static int f_gold ( int [ ] boxes , int n ) {
  Arrays . sort ( boxes ) ;
  int ans = 1 ;
  int prev_width = boxes [ 0 ] ;
  int prev_count = 1 ;
  int curr_count = 0 ;
  int curr_width = 0 ;
  for ( int i = 1 ;
  i < n ;
  i ++ ) {
    curr_width += boxes [ i ] ;
    curr_count += 1 ;
    if ( curr_width > prev_width && curr_count > prev_count ) {
      prev_width = curr_width ;
      prev_count = curr_count ;
      curr_count = 0 ;
      curr_width = 0 ;
      ans ++ ;
    }
  }
  return ans ;
}
public static void main(String args[]) {
f_gold(new int[]{7,8,11,11,14,19,25,27,41,42,46,52,53,54,55,58,59,62,63,66,67,69,74,75,77,81,83,84,88,88,93,93,94},22);
}
}