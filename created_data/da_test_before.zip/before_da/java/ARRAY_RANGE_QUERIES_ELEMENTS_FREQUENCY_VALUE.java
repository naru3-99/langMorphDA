import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class ARRAY_RANGE_QUERIES_ELEMENTS_FREQUENCY_VALUE{
static int f_gold ( int start , int end , int arr [ ] ) {
  Map < Integer , Integer > mp = new HashMap < > ( ) ;
  for ( int i = start ;
  i <= end ;
  i ++ ) mp . put ( arr [ i ] , mp . get ( arr [ i ] ) == null ? 1 : mp . get ( arr [ i ] ) + 1 ) ;
  int count = 0 ;
  for ( Map . Entry < Integer , Integer > entry : mp . entrySet ( ) ) if ( entry . getKey ( ) == entry . getValue ( ) ) count ++ ;
  return count ;
}
public static void main(String args[]) {
f_gold(0,31,new int[]{1,2,2,3,3,3,12,13,18,18,26,28,29,36,37,39,40,49,55,57,63,69,69,73,85,86,87,87,89,89,90,91,92,93,93,93,95,99});
}
}