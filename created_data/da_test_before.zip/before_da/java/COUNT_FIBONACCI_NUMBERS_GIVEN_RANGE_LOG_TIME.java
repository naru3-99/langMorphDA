import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class COUNT_FIBONACCI_NUMBERS_GIVEN_RANGE_LOG_TIME{
static int f_gold ( int low , int high ) {
  int f1 = 0 , f2 = 1 , f3 = 1 ;
  int result = 0 ;
  while ( f1 <= high ) {
    if ( f1 >= low ) result ++ ;
    f1 = f2 ;
    f2 = f3 ;
    f3 = f1 + f2 ;
  }
  return result ;
}
public static void main(String args[]) {
f_gold(76,43);
}
}