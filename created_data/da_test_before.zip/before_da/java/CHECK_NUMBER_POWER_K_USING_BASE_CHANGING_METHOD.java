import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class CHECK_NUMBER_POWER_K_USING_BASE_CHANGING_METHOD{
static boolean f_gold ( int n , int k ) {
  boolean oneSeen = false ;
  while ( n > 0 ) {
    int digit = n % k ;
    if ( digit > 1 ) return false ;
    if ( digit == 1 ) {
      if ( oneSeen ) return false ;
      oneSeen = true ;
    }
    n /= k ;
  }
  return true ;
}
public static void main(String args[]) {
f_gold(64,4);
}
}