import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class COUNT_PAIRS_TWO_SORTED_ARRAYS_WHOSE_SUM_EQUAL_GIVEN_VALUE_X{
static int f_gold ( int [ ] arr1 , int [ ] arr2 , int m , int n , int x ) {
  int count = 0 ;
  for ( int i = 0 ;
  i < m ;
  i ++ ) for ( int j = 0 ;
  j < n ;
  j ++ ) if ( ( arr1 [ i ] + arr2 [ j ] ) == x ) count ++ ;
  return count ;
}
public static void main(String args[]) {
f_gold(new int[]{11,13,16,23,26,28,31,34,37,39,44,48,56,59,79,91,96,98},new int[]{1,1,9,14,17,23,26,31,33,36,53,60,71,75,76,84,87,88},9,15,11);
}
}