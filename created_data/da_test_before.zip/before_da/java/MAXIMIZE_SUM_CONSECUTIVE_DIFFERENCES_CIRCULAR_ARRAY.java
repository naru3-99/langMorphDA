import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MAXIMIZE_SUM_CONSECUTIVE_DIFFERENCES_CIRCULAR_ARRAY{
static int f_gold ( int arr [ ] , int n ) {
  int sum = 0 ;
  Arrays . sort ( arr ) ;
  for ( int i = 0 ;
  i < n / 2 ;
  i ++ ) {
    sum -= ( 2 * arr [ i ] ) ;
    sum += ( 2 * arr [ n - i - 1 ] ) ;
  }
  return sum ;
}
public static void main(String args[]) {
f_gold(new int[]{8,9,12,13,17,21,24,29,37,37,39,40,41,45,49,50,53,54,56,59,60,60,70,71,72,74,77,77,78,85,89,89,90,90,95,98,98},34);
}
}