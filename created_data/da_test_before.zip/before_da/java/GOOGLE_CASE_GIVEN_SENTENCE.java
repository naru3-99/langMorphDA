import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class GOOGLE_CASE_GIVEN_SENTENCE{
static String f_gold ( String s ) {
  int n = s . length ( ) ;
  String s1 = "" ;
  s1 = s1 + Character . toLowerCase ( s . charAt ( 0 ) ) ;
  for ( int i = 1 ;
  i < n ;
  i ++ ) {
    if ( s . charAt ( i ) == ' ' && i < n ) {
      s1 = s1 + " " + Character . toLowerCase ( s . charAt ( i + 1 ) ) ;
      i ++ ;
    }
    else s1 = s1 + Character . toUpperCase ( s . charAt ( i ) ) ;
  }
  return s1 ;
}
public static void main(String args[]) {
f_gold("TEYndweqZA");
}
}