import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class NUMBER_DIGITS_PRODUCT_TWO_NUMBERS{
static int f_gold ( int a , int b ) {
  int count = 0 ;
  int p = Math . abs ( a * b ) ;
  if ( p == 0 ) return 1 ;
  while ( p > 0 ) {
    count ++ ;
    p = p / 10 ;
  }
  return count ;
}
public static void main(String args[]) {
f_gold(86,39);
}
}