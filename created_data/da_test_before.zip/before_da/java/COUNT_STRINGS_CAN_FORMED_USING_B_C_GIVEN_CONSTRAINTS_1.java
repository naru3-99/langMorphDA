import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class COUNT_STRINGS_CAN_FORMED_USING_B_C_GIVEN_CONSTRAINTS_1{
static int f_gold ( int n ) {
  return 1 + ( n * 2 ) + ( n * ( ( n * n ) - 1 ) / 2 ) ;
}
public static void main(String args[]) {
f_gold(55);
}
}