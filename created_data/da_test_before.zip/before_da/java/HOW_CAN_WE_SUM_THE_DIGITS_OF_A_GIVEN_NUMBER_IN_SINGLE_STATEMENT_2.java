import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class HOW_CAN_WE_SUM_THE_DIGITS_OF_A_GIVEN_NUMBER_IN_SINGLE_STATEMENT_2{
static int f_gold ( int no ) {
  return no == 0 ? 0 : no % 10 + f_gold ( no / 10 ) ;
}
public static void main(String args[]) {
f_gold(73);
}
}