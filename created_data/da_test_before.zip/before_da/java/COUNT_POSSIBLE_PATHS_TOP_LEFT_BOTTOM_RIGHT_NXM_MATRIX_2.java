import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class COUNT_POSSIBLE_PATHS_TOP_LEFT_BOTTOM_RIGHT_NXM_MATRIX_2{
static int f_gold ( int m , int n ) {
  int [ ] dp = new int [ n ] ;
  dp [ 0 ] = 1 ;
  for ( int i = 0 ;
  i < m ;
  i ++ ) {
    for ( int j = 1 ;
    j < n ;
    j ++ ) {
      dp [ j ] += dp [ j - 1 ] ;
    }
  }
  return dp [ n - 1 ] ;
}
public static void main(String args[]) {
f_gold(73,75);
}
}