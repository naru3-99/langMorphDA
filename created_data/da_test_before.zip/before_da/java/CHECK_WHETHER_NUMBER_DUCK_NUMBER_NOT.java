import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class CHECK_WHETHER_NUMBER_DUCK_NUMBER_NOT{
static int f_gold ( String num ) {
  int len = num . length ( ) ;
  int count_zero = 0 ;
  char ch ;
  for ( int i = 1 ;
  i < len ;
  i ++ ) {
    ch = num . charAt ( i ) ;
    if ( ch == '0' ) count_zero ++ ;
  }
  return count_zero ;
}
public static void main(String args[]) {
f_gold("HLlQWSphZcIC");
}
}