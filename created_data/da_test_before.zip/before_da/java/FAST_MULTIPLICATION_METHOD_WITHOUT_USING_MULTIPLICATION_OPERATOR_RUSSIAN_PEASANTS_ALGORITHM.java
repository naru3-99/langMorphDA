import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class FAST_MULTIPLICATION_METHOD_WITHOUT_USING_MULTIPLICATION_OPERATOR_RUSSIAN_PEASANTS_ALGORITHM{
static int f_gold ( int a , int b ) {
  int res = 0 ;
  while ( b > 0 ) {
    if ( ( b & 1 ) != 0 ) res = res + a ;
    a = a << 1 ;
    b = b >> 1 ;
  }
  return res ;
}
public static void main(String args[]) {
f_gold(4,33);
}
}