import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MARKOV_MATRIX{
static boolean f_gold ( double m [ ] [ ] ) {
  for ( int i = 0 ;
  i < m . length ;
  i ++ ) {
    double sum = 0 ;
    for ( int j = 0 ;
    j < m [ i ] . length ;
    j ++ ) sum = sum + m [ i ] [ j ] ;
    if ( sum != 1 ) return false ;
  }
  return true ;
}
public static void main(String args[]) {
f_gold(new double[][]{new double[]{ 0, 0, 1 }, new double[]{ 0.5, 0, 0.5 }, new double[]{ 1, 0, 0 }});
}
}