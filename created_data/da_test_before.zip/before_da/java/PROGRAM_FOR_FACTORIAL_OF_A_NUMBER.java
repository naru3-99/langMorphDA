import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class PROGRAM_FOR_FACTORIAL_OF_A_NUMBER{
static int f_gold ( int n ) {
  if ( n == 0 ) return 1 ;
  return n * f_gold ( n - 1 ) ;
}
public static void main(String args[]) {
f_gold(79);
}
}