import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MIDDLE_OF_THREE_USING_MINIMUM_COMPARISONS_1{
public static int f_gold ( int a , int b , int c ) {
  if ( a > b ) {
    if ( b > c ) return b ;
    else if ( a > c ) return c ;
    else return a ;
  }
  else {
    if ( a > c ) return a ;
    else if ( b > c ) return c ;
    else return b ;
  }
}
public static void main(String args[]) {
f_gold(43,24,7);
}
}