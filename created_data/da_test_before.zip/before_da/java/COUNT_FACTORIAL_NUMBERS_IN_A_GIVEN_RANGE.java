import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class COUNT_FACTORIAL_NUMBERS_IN_A_GIVEN_RANGE{
static int f_gold ( int low , int high ) {
  int fact = 1 , x = 1 ;
  while ( fact < low ) {
    fact = fact * x ;
    x ++ ;
  }
  int res = 0 ;
  while ( fact <= high ) {
    res ++ ;
    fact = fact * x ;
    x ++ ;
  }
  return res ;
}
public static void main(String args[]) {
f_gold(57,79);
}
}