import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class BREAK_NUMBER_THREE_PARTS_1{
static long f_gold ( long n ) {
  long count = 0 ;
  count = ( n + 1 ) * ( n + 2 ) / 2 ;
  return count ;
}
public static void main(String args[]) {
f_gold(71L);
}
}