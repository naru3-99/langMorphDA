import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class FREQUENT_ELEMENT_ARRAY{
static int f_gold ( int arr [ ] , int n ) {
  Arrays . sort ( arr ) ;
  int max_count = 1 , res = arr [ 0 ] ;
  int curr_count = 1 ;
  for ( int i = 1 ;
  i < n ;
  i ++ ) {
    if ( arr [ i ] == arr [ i - 1 ] ) curr_count ++ ;
    else {
      if ( curr_count > max_count ) {
        max_count = curr_count ;
        res = arr [ i - 1 ] ;
      }
      curr_count = 1 ;
    }
  }
  if ( curr_count > max_count ) {
    max_count = curr_count ;
    res = arr [ n - 1 ] ;
  }
  return res ;
}
public static void main(String args[]) {
f_gold(new int[]{1,1,3,11,11,11,18,20,26,26,27,30,33,39,39,42,42,48,51,51,51,51,60,66,66,68,68,69,71,72,73,76,76,77,77,77,78,90,96},25);
}
}