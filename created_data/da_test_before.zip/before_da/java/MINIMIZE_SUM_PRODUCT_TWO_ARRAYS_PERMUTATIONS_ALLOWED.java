import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MINIMIZE_SUM_PRODUCT_TWO_ARRAYS_PERMUTATIONS_ALLOWED{
static int f_gold ( int A [ ] , int B [ ] , int n ) {
  Arrays . sort ( A ) ;
  Arrays . sort ( B ) ;
  int result = 0 ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) result += ( A [ i ] * B [ n - i - 1 ] ) ;
  return result ;
}
public static void main(String args[]) {
f_gold(new int[]{31,85},new int[]{18,33},1);
}
}