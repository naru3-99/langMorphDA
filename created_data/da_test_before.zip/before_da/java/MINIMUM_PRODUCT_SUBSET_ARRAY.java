import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MINIMUM_PRODUCT_SUBSET_ARRAY{
static int f_gold ( int a [ ] , int n ) {
  if ( n == 1 ) return a [ 0 ] ;
  int negmax = Integer . MIN_VALUE ;
  int posmin = Integer . MAX_VALUE ;
  int count_neg = 0 , count_zero = 0 ;
  int product = 1 ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) {
    if ( a [ i ] == 0 ) {
      count_zero ++ ;
      continue ;
    }
    if ( a [ i ] < 0 ) {
      count_neg ++ ;
      negmax = Math . max ( negmax , a [ i ] ) ;
    }
    if ( a [ i ] > 0 && a [ i ] < posmin ) posmin = a [ i ] ;
    product *= a [ i ] ;
  }
  if ( count_zero == n || ( count_neg == 0 && count_zero > 0 ) ) return 0 ;
  if ( count_neg == 0 ) return posmin ;
  if ( count_neg % 2 == 0 && count_neg != 0 ) {
    product = product / negmax ;
  }
  return product ;
}
public static void main(String args[]) {
f_gold(new int[]{3,6,7,8,8,9,12,12,12,13,15,15,15,16,18,18,18,19,20,21,22,22,23,28,29,30,30,33,33,35,35,36,40,43,58,63,73,78,82,83,84,87,89,89,92,94},23);
}
}