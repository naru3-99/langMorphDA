import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class NUMBER_NON_NEGATIVE_INTEGRAL_SOLUTIONS_B_C_N{
static int f_gold ( int n ) {
  int result = 0 ;
  for ( int i = 0 ;
  i <= n ;
  i ++ ) for ( int j = 0 ;
  j <= n - i ;
  j ++ ) for ( int k = 0 ;
  k <= ( n - i - j ) ;
  k ++ ) if ( i + j + k == n ) result ++ ;
  return result ;
}
public static void main(String args[]) {
f_gold(62);
}
}