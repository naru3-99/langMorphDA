import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MAXIMUM_DISTANCE_TWO_OCCURRENCES_ELEMENT_ARRAY{
static int f_gold ( int [ ] arr , int n ) {
  HashMap < Integer , Integer > map = new HashMap < > ( ) ;
  int max_dist = 0 ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) {
    if ( ! map . containsKey ( arr [ i ] ) ) map . put ( arr [ i ] , i ) ;
    else max_dist = Math . max ( max_dist , i - map . get ( arr [ i ] ) ) ;
  }
  return max_dist ;
}
public static void main(String args[]) {
f_gold(new int[]{1,20,25,28,29,31,34,35,38,39,41,43,46,55,56,60,65,66,74,77,79,80,81,83,84,88,88,88,90,91,99},27);
}
}