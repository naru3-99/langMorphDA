import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class COUNT_NUMBER_OF_SOLUTIONS_OF_X2_1_MOD_P_IN_GIVEN_RANGE{
static int f_gold ( int n , int p ) {
  int ans = 0 ;
  for ( int x = 1 ;
  x < p ;
  x ++ ) {
    if ( ( x * x ) % p == 1 ) {
      int last = x + p * ( n / p ) ;
      if ( last > n ) last -= p ;
      ans += ( ( last - x ) / p + 1 ) ;
    }
  }
  return ans ;
}
public static void main(String args[]) {
f_gold(94,36);
}
}