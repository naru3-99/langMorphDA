import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class CHECK_POSSIBLE_SORT_ARRAY_CONDITIONAL_SWAPPING_ADJACENT_ALLOWED{
static boolean f_gold ( int arr [ ] , int n ) {
  for ( int i = 0 ;
  i < n - 1 ;
  i ++ ) {
    if ( arr [ i ] > arr [ i + 1 ] ) {
      if ( arr [ i ] - arr [ i + 1 ] == 1 ) {
        int temp = arr [ i ] ;
        arr [ i ] = arr [ i + 1 ] ;
        arr [ i + 1 ] = temp ;
      }
      else return false ;
    }
  }
  return true ;
}
public static void main(String args[]) {
f_gold(new int[]{1,4,12,16,37,44,47,51,55,57,57,62,62,62,64,69,69,70,72,81,81,88,89,97},15);
}
}