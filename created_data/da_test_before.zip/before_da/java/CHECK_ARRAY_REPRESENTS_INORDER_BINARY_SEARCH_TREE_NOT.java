import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class CHECK_ARRAY_REPRESENTS_INORDER_BINARY_SEARCH_TREE_NOT{
static boolean f_gold ( int [ ] arr , int n ) {
  if ( n == 0 || n == 1 ) {
    return true ;
  }
  for ( int i = 1 ;
  i < n ;
  i ++ ) {
    if ( arr [ i - 1 ] > arr [ i ] ) {
      return false ;
    }
  }
  return true ;
}
public static void main(String args[]) {
f_gold(new int[]{2,3,4,10,11,13,17,19,23,26,28,29,30,34,35,37,38,38,43,49,49,50,52,53,55,55,57,58,58,59,64,66,67,70,72,72,75,77,77,87,89,89,90,91,98,99,99,99},46);
}
}