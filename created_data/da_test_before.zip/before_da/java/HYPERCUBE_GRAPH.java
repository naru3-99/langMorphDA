import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class HYPERCUBE_GRAPH{
static int f_gold ( int n ) {
  if ( n == 1 ) return 2 ;
  return 2 * f_gold ( n - 1 ) ;
}
public static void main(String args[]) {
f_gold(72);
}
}