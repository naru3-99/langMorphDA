import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class NUMBER_DIGITS_PRODUCT_TWO_NUMBERS_1{
public static int f_gold ( int a , int b ) {
  if ( a == 0 || b == 0 ) return 1 ;
  return ( int ) Math . floor ( Math . log10 ( Math . abs ( a ) ) + Math . log10 ( Math . abs ( b ) ) ) + 1 ;
}
public static void main(String args[]) {
f_gold(97,91);
}
}