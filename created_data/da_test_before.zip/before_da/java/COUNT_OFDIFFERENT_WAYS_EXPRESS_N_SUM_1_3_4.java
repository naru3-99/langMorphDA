import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class COUNT_OFDIFFERENT_WAYS_EXPRESS_N_SUM_1_3_4{
static int f_gold ( int n ) {
  int DP [ ] = new int [ n + 1 ] ;
  DP [ 0 ] = DP [ 1 ] = DP [ 2 ] = 1 ;
  DP [ 3 ] = 2 ;
  for ( int i = 4 ;
  i <= n ;
  i ++ ) DP [ i ] = DP [ i - 1 ] + DP [ i - 3 ] + DP [ i - 4 ] ;
  return DP [ n ] ;
}
public static void main(String args[]) {
f_gold(44);
}
}