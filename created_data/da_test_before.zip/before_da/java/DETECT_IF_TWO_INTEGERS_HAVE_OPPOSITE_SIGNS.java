import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class DETECT_IF_TWO_INTEGERS_HAVE_OPPOSITE_SIGNS{
static boolean f_gold ( int x , int y ) {
  return ( ( x ^ y ) < 0 ) ;
}
public static void main(String args[]) {
f_gold(59,-99);
}
}