import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class FIND_SMALLEST_VALUE_REPRESENTED_SUM_SUBSET_GIVEN_ARRAY{
static int f_gold ( int arr [ ] , int n ) {
  int res = 1 ;
  for ( int i = 0 ;
  i < n && arr [ i ] <= res ;
  i ++ ) res = res + arr [ i ] ;
  return res ;
}
public static void main(String args[]) {
f_gold(new int[]{16,23,24,41,48,58,72,75},4);
}
}