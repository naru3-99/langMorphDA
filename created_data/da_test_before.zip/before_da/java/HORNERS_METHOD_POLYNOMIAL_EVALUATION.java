import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class HORNERS_METHOD_POLYNOMIAL_EVALUATION{
static int f_gold ( int poly [ ] , int n , int x ) {
  int result = poly [ 0 ] ;
  for ( int i = 1 ;
  i < n ;
  i ++ ) result = result * x + poly [ i ] ;
  return result ;
}
public static void main(String args[]) {
f_gold(new int[]{3,18,22,27,31,33,36,36,37,37,40,48,49,49,50,58,66,71,75,85,89,91},16,16);
}
}