import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MINIMUM_DIFFERENCE_MAX_MIN_K_SIZE_SUBSETS{
static int f_gold ( int arr [ ] , int N , int K ) {
  Arrays . sort ( arr ) ;
  int res = 2147483647 ;
  for ( int i = 0 ;
  i <= ( N - K ) ;
  i ++ ) {
    int curSeqDiff = arr [ i + K - 1 ] - arr [ i ] ;
    res = Math . min ( res , curSeqDiff ) ;
  }
  return res ;
}
public static void main(String args[]) {
f_gold(new int[]{1,1,4,18,21,35,37,39,76,81,86,92,96},7,6);
}
}