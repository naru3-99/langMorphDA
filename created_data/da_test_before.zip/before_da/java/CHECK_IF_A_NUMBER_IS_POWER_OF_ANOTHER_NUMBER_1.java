import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class CHECK_IF_A_NUMBER_IS_POWER_OF_ANOTHER_NUMBER_1{
static boolean f_gold ( int x , int y ) {
  int res1 = ( int ) Math . log ( y ) / ( int ) Math . log ( x ) ;
  double res2 = Math . log ( y ) / Math . log ( x ) ;
  return ( res1 == res2 ) ;
}
public static void main(String args[]) {
f_gold(57,1);
}
}