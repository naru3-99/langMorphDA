import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class DYNAMIC_PROGRAMMING_SET_36_CUT_A_ROPE_TO_MAXIMIZE_PRODUCT_1{
static int f_gold ( int n ) {
  if ( n == 2 || n == 3 ) return ( n - 1 ) ;
  int res = 1 ;
  while ( n > 4 ) {
    n -= 3 ;
    res *= 3 ;
  }
  return ( n * res ) ;
}
public static void main(String args[]) {
f_gold(62);
}
}