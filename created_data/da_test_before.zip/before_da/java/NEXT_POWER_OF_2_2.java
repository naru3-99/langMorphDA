import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class NEXT_POWER_OF_2_2{
static int f_gold ( int n ) {
  n -- ;
  n |= n >> 1 ;
  n |= n >> 2 ;
  n |= n >> 4 ;
  n |= n >> 8 ;
  n |= n >> 16 ;
  n ++ ;
  return n ;
}
public static void main(String args[]) {
f_gold(63);
}
}