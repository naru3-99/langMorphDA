import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class COUNT_TRAILING_ZEROES_FACTORIAL_NUMBER{
static int f_gold ( int n ) {
  int count = 0 ;
  for ( int i = 5 ;
  n / i >= 1 ;
  i *= 5 ) count += n / i ;
  return count ;
}
public static void main(String args[]) {
f_gold(9);
}
}