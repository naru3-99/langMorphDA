import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class FIND_THE_FIRST_MISSING_NUMBER{
static int f_gold ( int array [ ] , int start , int end ) {
  if ( start > end ) return end + 1 ;
  if ( start != array [ start ] ) return start ;
  int mid = ( start + end ) / 2 ;
  if ( array [ mid ] == mid ) return f_gold ( array , mid + 1 , end ) ;
  return f_gold ( array , start , mid ) ;
}
public static void main(String args[]) {
f_gold(new int[]{3,6,7,9,11,14,18,30,30,32,32,34,37,44,45,45,48,48,48,52,58,60,63,67,69,69,81,83,87,89,97,99},24,18);
}
}