import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class COUNT_SET_BITS_IN_AN_INTEGER{
static int f_gold ( int n ) {
  int count = 0 ;
  while ( n > 0 ) {
    count += n & 1 ;
    n >>= 1 ;
  }
  return count ;
}
public static void main(String args[]) {
f_gold(58);
}
}