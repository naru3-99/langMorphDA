import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class DISTRIBUTING_ITEMS_PERSON_CANNOT_TAKE_TWO_ITEMS_TYPE{
static boolean f_gold ( int [ ] arr , int n , int k ) {
  int count ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) {
    count = 0 ;
    for ( int j = 0 ;
    j < n ;
    j ++ ) {
      if ( arr [ j ] == arr [ i ] ) count ++ ;
      if ( count > 2 * k ) return false ;
    }
  }
  return true ;
}
public static void main(String args[]) {
f_gold(new int[]{1,1,2,3,1},5,2);
}
}