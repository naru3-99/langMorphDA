import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class FIND_MAXIMUM_AVERAGE_SUBARRAY_OF_K_LENGTH{
static int f_gold ( int [ ] arr , int n , int k ) {
  if ( k > n ) return - 1 ;
  int [ ] csum = new int [ n ] ;
  csum [ 0 ] = arr [ 0 ] ;
  for ( int i = 1 ;
  i < n ;
  i ++ ) csum [ i ] = csum [ i - 1 ] + arr [ i ] ;
  int max_sum = csum [ k - 1 ] , max_end = k - 1 ;
  for ( int i = k ;
  i < n ;
  i ++ ) {
    int curr_sum = csum [ i ] - csum [ i - k ] ;
    if ( curr_sum > max_sum ) {
      max_sum = curr_sum ;
      max_end = i ;
    }
  }
  return max_end - k + 1 ;
}
public static void main(String args[]) {
f_gold(new int[]{2,4,6,19,21,23,32,34,47,51,56,57,57,65,68,68,69,70,71,73,74,74,77,77,79,82,82,86,87,87,88,89,90,91,92},29,20);
}
}