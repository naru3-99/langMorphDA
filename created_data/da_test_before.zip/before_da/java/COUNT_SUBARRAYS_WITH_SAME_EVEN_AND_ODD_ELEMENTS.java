import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class COUNT_SUBARRAYS_WITH_SAME_EVEN_AND_ODD_ELEMENTS{
static int f_gold ( int [ ] arr , int n ) {
  int difference = 0 ;
  int ans = 0 ;
  int [ ] hash_positive = new int [ n + 1 ] ;
  int [ ] hash_negative = new int [ n + 1 ] ;
  hash_positive [ 0 ] = 1 ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) {
    if ( ( arr [ i ] & 1 ) == 1 ) {
      difference ++ ;
    }
    else {
      difference -- ;
    }
    if ( difference < 0 ) {
      ans += hash_negative [ - difference ] ;
      hash_negative [ - difference ] ++ ;
    }
    else {
      ans += hash_positive [ difference ] ;
      hash_positive [ difference ] ++ ;
    }
  }
  return ans ;
}
public static void main(String args[]) {
f_gold(new int[]{7,8,12,13,14,19,20,22,28,30,31,31,32,34,34,39,39,43,45,46,47,62,63,63,65,66,69,69,71,76,79,82,83,88,89,92,93,95,97,97},26);
}
}