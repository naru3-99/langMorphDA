import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class AREA_SQUARE_CIRCUMSCRIBED_CIRCLE{
static int f_gold ( int r ) {
  return ( 2 * r * r ) ;
}
public static void main(String args[]) {
f_gold(14);
}
}