import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class NTH_EVEN_LENGTH_PALINDROME{
static String f_gold ( String n ) {
  String res = n ;
  for ( int j = n . length ( ) - 1 ;
  j >= 0 ;
  -- j ) res += n . charAt ( j ) ;
  return res ;
}
public static void main(String args[]) {
f_gold("lSUhEvxcgfI");
}
}