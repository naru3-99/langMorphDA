import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class COUNT_ENTRIES_EQUAL_TO_X_IN_A_SPECIAL_MATRIX{
static int f_gold ( int n , int x ) {
  int f_gold = 0 ;
  for ( int i = 1 ;
  i <= n && i <= x ;
  i ++ ) {
    if ( x / i <= n && x % i == 0 ) f_gold ++ ;
  }
  return f_gold ;
}
public static void main(String args[]) {
f_gold(47,30);
}
}