import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class LARGEST_SUBARRAY_WITH_EQUAL_NUMBER_OF_0S_AND_1S_1{
static int f_gold ( int arr [ ] , int n ) {
  HashMap < Integer , Integer > hM = new HashMap < Integer , Integer > ( ) ;
  int sum = 0 ;
  int max_len = 0 ;
  int ending_index = - 1 ;
  int start_index = 0 ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) {
    arr [ i ] = ( arr [ i ] == 0 ) ? - 1 : 1 ;
  }
  for ( int i = 0 ;
  i < n ;
  i ++ ) {
    sum += arr [ i ] ;
    if ( sum == 0 ) {
      max_len = i + 1 ;
      ending_index = i ;
    }
    if ( hM . containsKey ( sum + n ) ) {
      if ( max_len < i - hM . get ( sum + n ) ) {
        max_len = i - hM . get ( sum + n ) ;
        ending_index = i ;
      }
    }
    else hM . put ( sum + n , i ) ;
  }
  for ( int i = 0 ;
  i < n ;
  i ++ ) {
    arr [ i ] = ( arr [ i ] == - 1 ) ? 0 : 1 ;
  }
  int end = ending_index - max_len + 1 ;
  System . out . println ( end + " to " + ending_index ) ;
  return max_len ;
}
public static void main(String args[]) {
f_gold(new int[]{3,6,16,16,18,19,22,39,40,42,60,66,69,70,70,73,74,80,99},9);
}
}