import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class FIND_PERIMETER_CYLINDER{
static int f_gold ( int diameter , int height ) {
  return 2 * ( diameter + height ) ;
}
public static void main(String args[]) {
f_gold(70,78);
}
}