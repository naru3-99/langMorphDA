import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class COUNT_INDEX_PAIRS_EQUAL_ELEMENTS_ARRAY{
static int f_gold ( int arr [ ] , int n ) {
  int ans = 0 ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) for ( int j = i + 1 ;
  j < n ;
  j ++ ) if ( arr [ i ] == arr [ j ] ) ans ++ ;
  return ans ;
}
public static void main(String args[]) {
f_gold(new int[]{4,6,9,16,16,21,36,41,58,60,62,73,77,81,95},12);
}
}