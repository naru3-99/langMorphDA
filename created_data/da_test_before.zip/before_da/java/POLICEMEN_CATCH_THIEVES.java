import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class POLICEMEN_CATCH_THIEVES{
static int f_gold ( char arr [ ] , int n , int k ) {
  int res = 0 ;
  ArrayList < Integer > thi = new ArrayList < Integer > ( ) ;
  ArrayList < Integer > pol = new ArrayList < Integer > ( ) ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) {
    if ( arr [ i ] == 'P' ) pol . add ( i ) ;
    else if ( arr [ i ] == 'T' ) thi . add ( i ) ;
  }
  int l = 0 , r = 0 ;
  while ( l < thi . size ( ) && r < pol . size ( ) ) {
    if ( Math . abs ( thi . get ( l ) - pol . get ( r ) ) <= k ) {
      res ++ ;
      l ++ ;
      r ++ ;
    }
    else if ( thi . get ( l ) < pol . get ( r ) ) l ++ ;
    else r ++ ;
  }
  return res ;
}
public static void main(String args[]) {
f_gold(new char[]{'A','B','B','D','E','E','F','G','G','G','I','J','O','P','Q','Q','Q','Q','R','R','S','U','X','Y','Y','c','d','h','i','i','i','i','k','k','l','l','l','l','m','p','r','r','s','t','t','u','x','z'},33,45);
}
}