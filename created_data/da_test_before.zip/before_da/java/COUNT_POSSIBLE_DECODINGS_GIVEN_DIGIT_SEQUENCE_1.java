import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class COUNT_POSSIBLE_DECODINGS_GIVEN_DIGIT_SEQUENCE_1{
static int f_gold ( char digits [ ] , int n ) {
  int count [ ] = new int [ n + 1 ] ;
  count [ 0 ] = 1 ;
  count [ 1 ] = 1 ;
  if ( digits [ 0 ] == '0' ) return 0 ;
  for ( int i = 2 ;
  i <= n ;
  i ++ ) {
    count [ i ] = 0 ;
    if ( digits [ i - 1 ] > '0' ) count [ i ] = count [ i - 1 ] ;
    if ( digits [ i - 2 ] == '1' || ( digits [ i - 2 ] == '2' && digits [ i - 1 ] < '7' ) ) count [ i ] += count [ i - 2 ] ;
  }
  return count [ n ] ;
}
public static void main(String args[]) {
f_gold(new char[]{'B','C','E','E','F','F','G','J','K','K','L','L','M','O','O','P','Q','R','V','X','Z','a','a','a','c','c','c','d','e','g','g','k','k','k','l','m','m','n','p','t','y','z'},31);
}
}