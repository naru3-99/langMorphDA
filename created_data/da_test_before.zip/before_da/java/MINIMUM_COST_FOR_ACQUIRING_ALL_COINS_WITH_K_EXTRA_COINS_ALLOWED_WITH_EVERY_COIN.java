import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MINIMUM_COST_FOR_ACQUIRING_ALL_COINS_WITH_K_EXTRA_COINS_ALLOWED_WITH_EVERY_COIN{
static int f_gold ( int coin [ ] , int n , int k ) {
  Arrays . sort ( coin ) ;
  int coins_needed = ( int ) Math . ceil ( 1.0 * n / ( k + 1 ) ) ;
  int ans = 0 ;
  for ( int i = 0 ;
  i <= coins_needed - 1 ;
  i ++ ) ans += coin [ i ] ;
  return ans ;
}
public static void main(String args[]) {
f_gold(new int[]{2,4,5,9,10,10,11,14,15,19,21,22,29,36,36,38,39,39,39,41,41,42,45,45,48,55,56,57,64,66,66,66,66,69,74,76,80,81,82,82,85,87,95,95},33,27);
}
}