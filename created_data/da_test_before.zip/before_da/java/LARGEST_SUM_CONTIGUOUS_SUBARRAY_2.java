import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class LARGEST_SUM_CONTIGUOUS_SUBARRAY_2{
static int f_gold ( int a [ ] , int size ) {
  int max_so_far = a [ 0 ] ;
  int curr_max = a [ 0 ] ;
  for ( int i = 1 ;
  i < size ;
  i ++ ) {
    curr_max = Math . max ( a [ i ] , curr_max + a [ i ] ) ;
    max_so_far = Math . max ( max_so_far , curr_max ) ;
  }
  return max_so_far ;
}
public static void main(String args[]) {
f_gold(new int[]{1,3,4,7,8,8,10,12,16,19,19,20,20,21,21,22,26,27,29,34,36,38,38,39,41,43,44,47,47,49,57,57,60,62,63,65,75,77,77,78,81,82,82,83,83,84,85,98,99},38);
}
}