import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class CHECK_IF_A_NUMBER_IS_POWER_OF_ANOTHER_NUMBER{
public static boolean f_gold ( int x , int y ) {
  if ( x == 1 ) return ( y == 1 ) ;
  int pow = 1 ;
  while ( pow < y ) pow = pow * x ;
  return ( pow == y ) ;
}
public static void main(String args[]) {
f_gold(57,1);
}
}