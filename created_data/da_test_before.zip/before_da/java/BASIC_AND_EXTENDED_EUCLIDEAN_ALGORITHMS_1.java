import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class BASIC_AND_EXTENDED_EUCLIDEAN_ALGORITHMS_1{
public static int f_gold ( int a , int b , int x , int y ) {
  if ( a == 0 ) {
    x = 0 ;
    y = 1 ;
    return b ;
  }
  int x1 = 1 , y1 = 1 ;
  int gcd = f_gold ( b % a , a , x1 , y1 ) ;
  x = y1 - ( b / a ) * x1 ;
  y = x1 ;
  return gcd ;
}
public static void main(String args[]) {
f_gold(44,17,10,65);
}
}