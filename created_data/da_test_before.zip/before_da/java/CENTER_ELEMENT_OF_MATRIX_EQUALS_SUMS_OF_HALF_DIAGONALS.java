import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class CENTER_ELEMENT_OF_MATRIX_EQUALS_SUMS_OF_HALF_DIAGONALS{
static boolean f_gold ( int mat [ ] [ ] , int n ) {
  int diag1_left = 0 , diag1_right = 0 ;
  int diag2_left = 0 , diag2_right = 0 ;
  for ( int i = 0 , j = n - 1 ;
  i < n ;
  i ++ , j -- ) {
    if ( i < n / 2 ) {
      diag1_left += mat [ i ] [ i ] ;
      diag2_left += mat [ j ] [ i ] ;
    }
    else if ( i > n / 2 ) {
      diag1_right += mat [ i ] [ i ] ;
      diag2_right += mat [ j ] [ i ] ;
    }
  }
  return ( diag1_left == diag2_right && diag2_right == diag2_left && diag1_right == diag2_left && diag2_right == mat [ n / 2 ] [ n / 2 ] ) ;
}
public static void main(String args[]) {
f_gold(new int[][]{  new int[]{ 2, 9, 1, 4, -2},  new int[]{ 6, 7, 2, 11, 4},  new int[]{ 4, 2, 9, 2, 4},  new int[]{ 1, 9, 2, 4, 4},  new int[]{ 0, 2, 4, 2, 5} },5);
}
}