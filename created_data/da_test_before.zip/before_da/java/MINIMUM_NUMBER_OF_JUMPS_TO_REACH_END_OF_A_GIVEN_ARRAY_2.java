import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MINIMUM_NUMBER_OF_JUMPS_TO_REACH_END_OF_A_GIVEN_ARRAY_2{
static int f_gold ( int arr [ ] , int n ) {
  int [ ] jumps = new int [ n ] ;
  int min ;
  jumps [ n - 1 ] = 0 ;
  for ( int i = n - 2 ;
  i >= 0 ;
  i -- ) {
    if ( arr [ i ] == 0 ) jumps [ i ] = Integer . MAX_VALUE ;
    else if ( arr [ i ] >= n - i - 1 ) jumps [ i ] = 1 ;
    else {
      min = Integer . MAX_VALUE ;
      for ( int j = i + 1 ;
      j < n && j <= arr [ i ] + i ;
      j ++ ) {
        if ( min > jumps [ j ] ) min = jumps [ j ] ;
      }
      if ( min != Integer . MAX_VALUE ) jumps [ i ] = min + 1 ;
      else jumps [ i ] = min ;
    }
  }
  return jumps [ 0 ] ;
}
public static void main(String args[]) {
f_gold(new int[]{1,6,7,14,22,32,42,42,43,48,54,57,59,69,84,92,98},11);
}
}