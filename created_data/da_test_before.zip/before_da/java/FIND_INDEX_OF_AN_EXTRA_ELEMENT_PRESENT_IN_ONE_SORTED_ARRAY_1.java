import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class FIND_INDEX_OF_AN_EXTRA_ELEMENT_PRESENT_IN_ONE_SORTED_ARRAY_1{
static int f_gold ( int arr1 [ ] , int arr2 [ ] , int n ) {
  int index = n ;
  int left = 0 , right = n - 1 ;
  while ( left <= right ) {
    int mid = ( left + right ) / 2 ;
    if ( arr2 [ mid ] == arr1 [ mid ] ) left = mid + 1 ;
    else {
      index = mid ;
      right = mid - 1 ;
    }
  }
  return index ;
}
public static void main(String args[]) {
f_gold(new int[]{7,18,19,25,26,27,31,39,44,46,59,60,66,72,78,83,84,92,94},new int[]{2,5,12,13,17,20,22,46,51,63,64,66,66,76,87,87,90,91,96},11);
}
}