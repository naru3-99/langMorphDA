import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class GCD_ELEMENTS_GIVEN_RANGE{
static int f_gold ( int n , int m ) {
  return ( n == m ) ? n : 1 ;
}
public static void main(String args[]) {
f_gold(57,57);
}
}