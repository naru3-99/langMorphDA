import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class FIND_SUM_EVEN_INDEX_BINOMIAL_COEFFICIENTS_1{
static int f_gold ( int n ) {
  return ( 1 << ( n - 1 ) ) ;
}
public static void main(String args[]) {
f_gold(56);
}
}