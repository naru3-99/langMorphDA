import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MULTIPLY_TWO_NUMBERS_WITHOUT_USING_MULTIPLY_DIVISION_BITWISE_OPERATORS_AND_NO_LOOPS{
static int f_gold ( int x , int y ) {
  if ( y == 0 ) return 0 ;
  if ( y > 0 ) return ( x + f_gold ( x , y - 1 ) ) ;
  if ( y < 0 ) return - f_gold ( x , - y ) ;
  return - 1 ;
}
public static void main(String args[]) {
f_gold(18,94);
}
}