import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class COUNT_MINIMUM_NUMBER_SUBSETS_SUBSEQUENCES_CONSECUTIVE_NUMBERS{
static int f_gold ( int arr [ ] , int n ) {
  Arrays . sort ( arr ) ;
  int count = 1 ;
  for ( int i = 0 ;
  i < n - 1 ;
  i ++ ) {
    if ( arr [ i ] + 1 != arr [ i + 1 ] ) count ++ ;
  }
  return count ;
}
public static void main(String args[]) {
f_gold(new int[]{3,7,7,11,14,14,14,16,17,17,21,22,24,27,27,27,31,33,35,36,36,37,38,43,45,49,52,54,57,59,59,60,67,73,74,74,74,75,75,79,83,87,90,93,97},42);
}
}