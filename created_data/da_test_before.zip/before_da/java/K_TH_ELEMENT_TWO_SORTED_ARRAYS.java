import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class K_TH_ELEMENT_TWO_SORTED_ARRAYS{
static int f_gold ( int arr1 [ ] , int arr2 [ ] , int m , int n , int k ) {
  int [ ] sorted1 = new int [ m + n ] ;
  int i = 0 , j = 0 , d = 0 ;
  while ( i < m && j < n ) {
    if ( arr1 [ i ] < arr2 [ j ] ) sorted1 [ d ++ ] = arr1 [ i ++ ] ;
    else sorted1 [ d ++ ] = arr2 [ j ++ ] ;
  }
  while ( i < m ) sorted1 [ d ++ ] = arr1 [ i ++ ] ;
  while ( j < n ) sorted1 [ d ++ ] = arr2 [ j ++ ] ;
  return sorted1 [ k - 1 ] ;
}
public static void main(String args[]) {
f_gold(new int[]{2,2,4,4,9,10,14,16,16,19,20,21,25,26,29,36,36,37,38,44,44,49,53,54,56,61,62,64,72,72,73,77,80,84,84,87,93,94},new int[]{6,8,10,10,12,14,24,31,33,33,35,35,35,41,46,47,49,51,52,56,57,59,62,65,72,72,73,73,79,80,82,83,83,84,87,87,93,99},27,21,23);
}
}