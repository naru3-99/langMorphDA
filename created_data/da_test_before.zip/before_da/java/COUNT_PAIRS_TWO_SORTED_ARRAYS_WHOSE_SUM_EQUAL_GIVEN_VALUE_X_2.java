import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class COUNT_PAIRS_TWO_SORTED_ARRAYS_WHOSE_SUM_EQUAL_GIVEN_VALUE_X_2{
static int f_gold ( int arr1 [ ] , int arr2 [ ] , int m , int n , int x ) {
  int count = 0 ;
  int l = 0 , r = n - 1 ;
  while ( l < m && r >= 0 ) {
    if ( ( arr1 [ l ] + arr2 [ r ] ) == x ) {
      l ++ ;
      r -- ;
      count ++ ;
    }
    else if ( ( arr1 [ l ] + arr2 [ r ] ) < x ) l ++ ;
    else r -- ;
  }
  return count ;
}
public static void main(String args[]) {
f_gold(new int[]{5,5,7,10,14,14,17,21,32,34,37,40,40,40,46,46,50,50,51,55,57,62,65,67,67,69,70,70,72,73,76,77,77,78,84,85,85,86,87,88,88,89,89,90,93,99},new int[]{2,5,8,8,10,12,13,15,17,18,20,20,21,27,28,31,34,37,40,46,48,52,53,54,54,58,59,60,66,68,68,69,70,71,72,73,77,77,80,84,84,92,92,95,97,97},28,29,23);
}
}