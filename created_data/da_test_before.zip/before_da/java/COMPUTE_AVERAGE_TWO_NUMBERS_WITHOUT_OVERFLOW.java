import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class COMPUTE_AVERAGE_TWO_NUMBERS_WITHOUT_OVERFLOW{
static int f_gold ( int a , int b ) {
  return ( a + b ) / 2 ;
}
public static void main(String args[]) {
f_gold(1,44);
}
}