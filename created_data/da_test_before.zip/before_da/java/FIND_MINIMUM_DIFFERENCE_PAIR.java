import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class FIND_MINIMUM_DIFFERENCE_PAIR{
static int f_gold ( int [ ] arr , int n ) {
  int diff = Integer . MAX_VALUE ;
  for ( int i = 0 ;
  i < n - 1 ;
  i ++ ) for ( int j = i + 1 ;
  j < n ;
  j ++ ) if ( Math . abs ( ( arr [ i ] - arr [ j ] ) ) < diff ) diff = Math . abs ( ( arr [ i ] - arr [ j ] ) ) ;
  return diff ;
}
public static void main(String args[]) {
f_gold(new int[]{1,1,2,3,5,8,10,11,15,15,16,20,26,28,30,30,33,33,39,50,50,50,54,62,66,68,69,69,74,74,75,75,76,78,82,83,85,86,86,89,89,91,91,92,92,92,93,94,98},32);
}
}