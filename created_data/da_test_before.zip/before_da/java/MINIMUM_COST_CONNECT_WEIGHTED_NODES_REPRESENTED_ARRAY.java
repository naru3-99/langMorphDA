import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MINIMUM_COST_CONNECT_WEIGHTED_NODES_REPRESENTED_ARRAY{
static int f_gold ( int a [ ] , int n ) {
  int mn = Integer . MAX_VALUE ;
  int sum = 0 ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) {
    mn = Math . min ( a [ i ] , mn ) ;
    sum += a [ i ] ;
  }
  return mn * ( sum - mn ) ;
}
public static void main(String args[]) {
f_gold(new int[]{3,8,14,15,17,17,19,21,22,23,29,32,36,37,43,45,46,47,47,53,57,57,70,71,72,76,81,82,90,95,96,98,99},32);
}
}