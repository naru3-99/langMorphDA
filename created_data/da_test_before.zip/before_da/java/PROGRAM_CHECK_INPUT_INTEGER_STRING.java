import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class PROGRAM_CHECK_INPUT_INTEGER_STRING{
static boolean f_gold ( String s ) {
  for ( int i = 0 ;
  i < s . length ( ) ;
  i ++ ) if ( Character . isDigit ( s . charAt ( i ) ) == false ) return false ;
  return true ;
}
public static void main(String args[]) {
f_gold("MgTOyHo NT");
}
}