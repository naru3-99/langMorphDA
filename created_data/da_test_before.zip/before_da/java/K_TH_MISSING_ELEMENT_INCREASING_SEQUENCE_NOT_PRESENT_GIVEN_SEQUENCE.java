import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class K_TH_MISSING_ELEMENT_INCREASING_SEQUENCE_NOT_PRESENT_GIVEN_SEQUENCE{
static int f_gold ( int a [ ] , int b [ ] , int k , int n1 , int n2 ) {
  LinkedHashSet < Integer > s = new LinkedHashSet < > ( ) ;
  for ( int i = 0 ;
  i < n2 ;
  i ++ ) s . add ( b [ i ] ) ;
  int missing = 0 ;
  for ( int i = 0 ;
  i < n1 ;
  i ++ ) {
    if ( ! s . contains ( a [ i ] ) ) missing ++ ;
    if ( missing == k ) return a [ i ] ;
  }
  return - 1 ;
}
public static void main(String args[]) {
f_gold(new int[]{2,9,9,13,38,41,50,59,64,64,72,78,79,80,84,92,94,98,99},new int[]{5,9,11,21,24,27,30,35,38,39,40,45,48,48,51,58,61,91,92},11,9,18);
}
}