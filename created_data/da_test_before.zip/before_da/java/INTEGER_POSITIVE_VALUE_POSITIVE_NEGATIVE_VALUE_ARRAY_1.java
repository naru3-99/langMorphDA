import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class INTEGER_POSITIVE_VALUE_POSITIVE_NEGATIVE_VALUE_ARRAY_1{
static int f_gold ( int arr [ ] , int n ) {
  int neg = 0 , pos = 0 ;
  int sum = 0 ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) {
    sum += arr [ i ] ;
    if ( arr [ i ] < 0 ) neg ++ ;
    else pos ++ ;
  }
  return ( sum / Math . abs ( neg - pos ) ) ;
}
public static void main(String args[]) {
f_gold(new int[]{49,98},1);
}
}