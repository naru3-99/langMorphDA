import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class CHECK_NUMBER_IS_PERFECT_SQUARE_USING_ADDITIONSUBTRACTION{
static boolean f_gold ( int n ) {
  for ( int sum = 0 , i = 1 ;
  sum < n ;
  i += 2 ) {
    sum += i ;
    if ( sum == n ) return true ;
  }
  return false ;
}
public static void main(String args[]) {
f_gold(1);
}
}