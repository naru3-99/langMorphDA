import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class DISTRIBUTING_M_ITEMS_CIRCLE_SIZE_N_STARTING_K_TH_POSITION{
static int f_gold ( int n , int m , int k ) {
  if ( m <= n - k + 1 ) return m + k - 1 ;
  m = m - ( n - k + 1 ) ;
  return ( m % n == 0 ) ? n : ( m % n ) ;
}
public static void main(String args[]) {
f_gold(19,14,34);
}
}