import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MINIMUM_SUM_SUBSEQUENCE_LEAST_ONE_EVERY_FOUR_CONSECUTIVE_ELEMENTS_PICKED_1{
static int f_gold ( int ar [ ] , int n ) {
  if ( n <= 4 ) return Arrays . stream ( ar ) . min ( ) . getAsInt ( ) ;
  int [ ] sum = new int [ n ] ;
  sum [ 0 ] = ar [ 0 ] ;
  sum [ 1 ] = ar [ 1 ] ;
  sum [ 2 ] = ar [ 2 ] ;
  sum [ 3 ] = ar [ 3 ] ;
  for ( int i = 4 ;
  i < n ;
  i ++ ) sum [ i ] = ar [ i ] + Arrays . stream ( Arrays . copyOfRange ( sum , i - 4 , i ) ) . min ( ) . getAsInt ( ) ;
  return Arrays . stream ( Arrays . copyOfRange ( sum , n - 4 , n ) ) . min ( ) . getAsInt ( ) ;
}
public static void main(String args[]) {
f_gold(new int[]{4,4,9,26,31,31,33,35,40,45,48,52,57,60,69,75,82,89,90,92,95,97},19);
}
}