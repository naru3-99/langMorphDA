import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class HIGHWAY_BILLBOARD_PROBLEM{
static int f_gold ( int m , int [ ] x , int [ ] revenue , int n , int t ) {
  int [ ] maxRev = new int [ m + 1 ] ;
  for ( int i = 0 ;
  i < m + 1 ;
  i ++ ) maxRev [ i ] = 0 ;
  int nxtbb = 0 ;
  for ( int i = 1 ;
  i <= m ;
  i ++ ) {
    if ( nxtbb < n ) {
      if ( x [ nxtbb ] != i ) maxRev [ i ] = maxRev [ i - 1 ] ;
      else {
        if ( i <= t ) maxRev [ i ] = Math . max ( maxRev [ i - 1 ] , revenue [ nxtbb ] ) ;
        else maxRev [ i ] = Math . max ( maxRev [ i - t - 1 ] + revenue [ nxtbb ] , maxRev [ i - 1 ] ) ;
        nxtbb ++ ;
      }
    }
    else maxRev [ i ] = maxRev [ i - 1 ] ;
  }
  return maxRev [ m ] ;
}
public static void main(String args[]) {
f_gold(16,new int[]{6,15,15,18,23,29,32,36,37,39,40,41,44,49,51,52,53,57,66,68,82,89,96},new int[]{1,2,5,5,24,26,31,32,33,41,57,59,71,75,79,87,87,88,92,94,96,96,99},12,12);
}
}