import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class PROGRAM_CHECK_ARRAY_SORTED_NOT_ITERATIVE_RECURSIVE_1{
static boolean f_gold ( int arr [ ] , int n ) {
  if ( n == 0 || n == 1 ) return true ;
  for ( int i = 1 ;
  i < n ;
  i ++ ) if ( arr [ i - 1 ] > arr [ i ] ) return false ;
  return true ;
}
public static void main(String args[]) {
f_gold(new int[]{6,8,8,16,19,19,21,23,26,33,34,36,38,39,41,41,45,47,52,52,55,57,60,60,60,61,69,69,70,70,72,73,73,75,78,81,84,84,85,88,88,89,90,91,97},22);
}
}