import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MINIMUM_COST_CUT_BOARD_SQUARES{
static int f_gold ( Integer X [ ] , Integer Y [ ] , int m , int n ) {
  int res = 0 ;
  Arrays . sort ( X , Collections . reverseOrder ( ) ) ;
  Arrays . sort ( Y , Collections . reverseOrder ( ) ) ;
  int hzntl = 1 , vert = 1 ;
  int i = 0 , j = 0 ;
  while ( i < m && j < n ) {
    if ( X [ i ] > Y [ j ] ) {
      res += X [ i ] * vert ;
      hzntl ++ ;
      i ++ ;
    }
    else {
      res += Y [ j ] * hzntl ;
      vert ++ ;
      j ++ ;
    }
  }
  int total = 0 ;
  while ( i < m ) total += X [ i ++ ] ;
  res += total * vert ;
  total = 0 ;
  while ( j < n ) total += Y [ j ++ ] ;
  res += total * hzntl ;
  return res ;
}
public static void main(String args[]) {
f_gold(new Integer[]{1,9,9,16,18,20,22,22,23,25,25,26,28,32,33,33,33,34,37,40,44,46,46,52,53,56,58,58,59,60,61,67,67,69,70,70,73,75,77,83,87,87,87,90,90,93,97,98},new Integer[]{2,3,9,10,13,16,17,19,20,23,25,27,29,30,30,35,37,39,39,45,47,50,55,55,55,56,59,60,62,63,67,70,70,71,72,73,73,74,77,86,87,88,91,92,95,96,97,99},25,27);
}
}