import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class COUNT_PAIRS_DIFFERENCE_EQUAL_K{
static int f_gold ( int arr [ ] , int n , int k ) {
  int count = 0 ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) {
    for ( int j = i + 1 ;
    j < n ;
    j ++ ) if ( arr [ i ] - arr [ j ] == k || arr [ j ] - arr [ i ] == k ) count ++ ;
  }
  return count ;
}
public static void main(String args[]) {
f_gold(new int[]{9,14,17,19,22,23,23,27,30,31,34,37,37,39,39,42,57,61,68,73,77,79,91,96,97},19,19);
}
}