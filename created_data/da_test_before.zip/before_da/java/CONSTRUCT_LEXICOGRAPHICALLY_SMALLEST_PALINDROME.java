import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class CONSTRUCT_LEXICOGRAPHICALLY_SMALLEST_PALINDROME{
static String f_gold ( char [ ] str , int len ) {
  int i = 0 , j = len - 1 ;
  for ( ;
  i < j ;
  i ++ , j -- ) {
    if ( str [ i ] == str [ j ] && str [ i ] != '*' ) continue ;
    else if ( str [ i ] == str [ j ] && str [ i ] == '*' ) {
      str [ i ] = 'a' ;
      str [ j ] = 'a' ;
      continue ;
    }
    else if ( str [ i ] == '*' ) {
      str [ i ] = str [ j ] ;
      continue ;
    }
    else if ( str [ j ] == '*' ) {
      str [ j ] = str [ i ] ;
      continue ;
    }
    System . out . println ( "Not Possible" ) ;
    return "" ;
  }
  return String . valueOf ( str ) ;
}
public static void main(String args[]) {
f_gold(new char[]{'A','B','C','G','I','L','L','O','O','P','Q','S','W','Y','c','d','e','f','f','i','m','m','o','q','v','w','x','x','y','z'},27);
}
}