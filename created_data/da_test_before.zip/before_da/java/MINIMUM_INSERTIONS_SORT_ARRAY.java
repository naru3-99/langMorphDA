import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MINIMUM_INSERTIONS_SORT_ARRAY{
static int f_gold ( int arr [ ] , int N ) {
  int [ ] lis = new int [ N ] ;
  for ( int i = 0 ;
  i < N ;
  i ++ ) lis [ i ] = 1 ;
  for ( int i = 1 ;
  i < N ;
  i ++ ) for ( int j = 0 ;
  j < i ;
  j ++ ) if ( arr [ i ] >= arr [ j ] && lis [ i ] < lis [ j ] + 1 ) lis [ i ] = lis [ j ] + 1 ;
  int max = 0 ;
  for ( int i = 0 ;
  i < N ;
  i ++ ) if ( max < lis [ i ] ) max = lis [ i ] ;
  return ( N - max ) ;
}
public static void main(String args[]) {
f_gold(new int[]{4,7,20,22,23,31,33,36,47,61,63,63,71,74,82,91,95,99},15);
}
}