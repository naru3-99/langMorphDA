import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MINIMUM_COST_MAKE_ARRAY_SIZE_1_REMOVING_LARGER_PAIRS{
static int f_gold ( int [ ] a , int n ) {
  int min = a [ 0 ] ;
  for ( int i = 1 ;
  i < a . length ;
  i ++ ) {
    if ( a [ i ] < min ) min = a [ i ] ;
  }
  return ( n - 1 ) * min ;
}
public static void main(String args[]) {
f_gold(new int[]{1,2,3,4,7,8,10,10,16,20,22,22,23,23,23,27,29,32,35,39,41,46,51,53,54,59,59,60,61,69,70,70,79,79,81,84,90,91,98},25);
}
}