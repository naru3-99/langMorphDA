import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MAXIMUM_HEIGHT_OF_TRIANGULAR_ARRANGEMENT_OF_ARRAY_VALUES{
static int f_gold ( int [ ] a , int n ) {
  int result = 1 ;
  for ( int i = 1 ;
  i <= n ;
  ++ i ) {
    int y = ( i * ( i + 1 ) ) / 2 ;
    if ( y < n ) result = i ;
    else break ;
  }
  return result ;
}
public static void main(String args[]) {
f_gold(new int[]{8,10,11,14,14,17,20,20,22,22,22,23,25,30,33,39,39,41,43,45,46,46,46,50,51,53,57,59,60,64,64,66,72,72,75,77,85,85,87,88,90,91,93,94,94,95},38);
}
}