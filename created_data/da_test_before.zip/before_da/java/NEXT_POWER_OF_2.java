import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class NEXT_POWER_OF_2{
static int f_gold ( int n ) {
  int count = 0 ;
  if ( n > 0 && ( n & ( n - 1 ) ) == 0 ) return n ;
  while ( n != 0 ) {
    n >>= 1 ;
    count += 1 ;
  }
  return 1 << count ;
}
public static void main(String args[]) {
f_gold(74);
}
}