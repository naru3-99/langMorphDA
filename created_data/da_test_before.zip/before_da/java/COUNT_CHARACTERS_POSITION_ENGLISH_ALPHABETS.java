import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class COUNT_CHARACTERS_POSITION_ENGLISH_ALPHABETS{
static int f_gold ( String str ) {
  int result = 0 ;
  for ( int i = 0 ;
  i < str . length ( ) ;
  i ++ ) {
    if ( i == ( str . charAt ( i ) - 'a' ) || i == ( str . charAt ( i ) - 'A' ) ) {
      result ++ ;
    }
  }
  return result ;
}
public static void main(String args[]) {
f_gold("lLkhFeZGcb");
}
}