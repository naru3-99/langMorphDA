import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MAXIMUM_SUM_PAIRS_SPECIFIC_DIFFERENCE_1{
static int f_gold ( int arr [ ] , int N , int k ) {
  int maxSum = 0 ;
  Arrays . sort ( arr ) ;
  for ( int i = N - 1 ;
  i > 0 ;
  -- i ) {
    if ( arr [ i ] - arr [ i - 1 ] < k ) {
      maxSum += arr [ i ] ;
      maxSum += arr [ i - 1 ] ;
      -- i ;
    }
  }
  return maxSum ;
}
public static void main(String args[]) {
f_gold(new int[]{2,10,11,11,12,14,15,17,27,27,28,36,36,44,47,47,54,55,62,64,68,69,70,70,75,76,78,85,85,91,95,97},26,18);
}
}