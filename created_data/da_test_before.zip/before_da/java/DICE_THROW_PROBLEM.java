import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class DICE_THROW_PROBLEM{
public static long f_gold ( int m , int n , int x ) {
  long [ ] [ ] table = new long [ n + 1 ] [ x + 1 ] ;
  for ( int j = 1 ;
  j <= m && j <= x ;
  j ++ ) table [ 1 ] [ j ] = 1 ;
  for ( int i = 2 ;
  i <= n ;
  i ++ ) {
    for ( int j = 1 ;
    j <= x ;
    j ++ ) {
      for ( int k = 1 ;
      k < j && k <= m ;
      k ++ ) table [ i ] [ j ] += table [ i - 1 ] [ j - k ] ;
    }
  }
  return table [ n ] [ x ] ;
}
public static void main(String args[]) {
f_gold(94,4,69);
}
}