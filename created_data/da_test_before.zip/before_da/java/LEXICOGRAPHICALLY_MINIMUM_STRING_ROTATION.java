import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class LEXICOGRAPHICALLY_MINIMUM_STRING_ROTATION{
static String f_gold ( String str ) {
  int n = str . length ( ) ;
  String arr [ ] = new String [ n ] ;
  String concat = str + str ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) {
    arr [ i ] = concat . substring ( i , i + n ) ;
  }
  Arrays . sort ( arr ) ;
  return arr [ 0 ] ;
}
public static void main(String args[]) {
f_gold("onWEchl");
}
}