import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class CHECK_WHETHER_ARITHMETIC_PROGRESSION_CAN_FORMED_GIVEN_ARRAY{
static boolean f_gold ( int arr [ ] , int n ) {
  if ( n == 1 ) return true ;
  Arrays . sort ( arr ) ;
  int d = arr [ 1 ] - arr [ 0 ] ;
  for ( int i = 2 ;
  i < n ;
  i ++ ) if ( arr [ i ] - arr [ i - 1 ] != d ) return false ;
  return true ;
}
public static void main(String args[]) {
f_gold(new int[]{1,4,64,16},4);
}
}