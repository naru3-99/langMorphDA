import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MAXIMUM_SUM_2_X_N_GRID_NO_TWO_ELEMENTS_ADJACENT{
public static int f_gold ( int grid [ ] [ ] , int n ) {
  int incl = Math . max ( grid [ 0 ] [ 0 ] , grid [ 1 ] [ 0 ] ) ;
  int excl = 0 , excl_new ;
  for ( int i = 1 ;
  i < n ;
  i ++ ) {
    excl_new = Math . max ( excl , incl ) ;
    incl = excl + Math . max ( grid [ 0 ] [ i ] , grid [ 1 ] [ i ] ) ;
    excl = excl_new ;
  }
  return Math . max ( excl , incl ) ;
}
public static void main(String args[]) {
f_gold(new int[][]{new int[]{6,10,23,28,35,55,91},new int[]{11,14,15,54,55,62,81},new int[]{18,26,40,43,47,89,93},new int[]{3,11,19,53,65,82,92},new int[]{14,32,43,44,51,77,83},new int[]{6,6,30,30,33,73,74},new int[]{2,2,10,61,70,81,84}},3);
}
}