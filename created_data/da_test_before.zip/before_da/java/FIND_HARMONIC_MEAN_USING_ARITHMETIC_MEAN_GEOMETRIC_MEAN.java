import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class FIND_HARMONIC_MEAN_USING_ARITHMETIC_MEAN_GEOMETRIC_MEAN{
static double f_gold ( int a , int b ) {
  double AM , GM , HM ;
  AM = ( a + b ) / 2 ;
  GM = Math . sqrt ( a * b ) ;
  HM = ( GM * GM ) / AM ;
  return HM ;
}
public static void main(String args[]) {
f_gold(54,83);
}
}