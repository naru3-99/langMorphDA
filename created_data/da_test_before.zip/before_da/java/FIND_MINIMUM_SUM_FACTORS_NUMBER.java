import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class FIND_MINIMUM_SUM_FACTORS_NUMBER{
static int f_gold ( int num ) {
  int sum = 0 ;
  for ( int i = 2 ;
  i * i <= num ;
  i ++ ) {
    while ( num % i == 0 ) {
      sum += i ;
      num /= i ;
    }
  }
  sum += num ;
  return sum ;
}
public static void main(String args[]) {
f_gold(83);
}
}