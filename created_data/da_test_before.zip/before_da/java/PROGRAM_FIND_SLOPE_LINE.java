import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class PROGRAM_FIND_SLOPE_LINE{
static float f_gold ( float x1 , float y1 , float x2 , float y2 ) {
  return ( y2 - y1 ) / ( x2 - x1 ) ;
}
public static void main(String args[]) {
f_gold(236.27324548309292F,5792.493225762838F,7177.837879115863F,1289.5700425822731F);
}
}