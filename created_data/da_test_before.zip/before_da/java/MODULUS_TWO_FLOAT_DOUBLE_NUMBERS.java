import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MODULUS_TWO_FLOAT_DOUBLE_NUMBERS{
static double f_gold ( double a , double b ) {
  if ( a < 0 ) a = - a ;
  if ( b < 0 ) b = - b ;
  double mod = a ;
  while ( mod >= b ) mod = mod - b ;
  if ( a < 0 ) return - mod ;
  return mod ;
}
public static void main(String args[]) {
f_gold(3243.229719038493,5659.926861939672);
}
}