import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MINIMUM_CHARACTERS_ADDED_FRONT_MAKE_STRING_PALINDROME{
static boolean f_gold ( String s ) {
  int l = s . length ( ) ;
  for ( int i = 0 , j = l - 1 ;
  i <= j ;
  i ++ , j -- ) {
    if ( s . charAt ( i ) != s . charAt ( j ) ) {
      return false ;
    }
  }
  return true ;
}
public static void main(String args[]) {
f_gold("aadaa");
}
}