import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class HOW_TO_AVOID_OVERFLOW_IN_MODULAR_MULTIPLICATION{
static long f_gold ( long a , long b , long mod ) {
  long res = 0 ;
  a = a % mod ;
  while ( b > 0 ) {
    if ( b % 2 == 1 ) {
      res = ( res + a ) % mod ;
    }
    a = ( a * 2 ) % mod ;
    b /= 2 ;
  }
  return res % mod ;
}
public static void main(String args[]) {
f_gold(99L,75L,40L);
}
}