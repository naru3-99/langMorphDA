import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class AREA_OF_A_HEXAGON{
public static double f_gold ( double s ) {
  return ( ( 3 * Math . sqrt ( 3 ) * ( s * s ) ) / 2 ) ;
}
public static void main(String args[]) {
f_gold(1772.6589509256596);
}
}