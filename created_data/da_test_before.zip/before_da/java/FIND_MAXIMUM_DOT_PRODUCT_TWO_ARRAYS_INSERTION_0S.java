import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class FIND_MAXIMUM_DOT_PRODUCT_TWO_ARRAYS_INSERTION_0S{
static int f_gold ( int A [ ] , int B [ ] , int m , int n ) {
  int dp [ ] [ ] = new int [ n + 1 ] [ m + 1 ] ;
  for ( int [ ] row : dp ) Arrays . fill ( row , 0 ) ;
  for ( int i = 1 ;
  i <= n ;
  i ++ ) for ( int j = i ;
  j <= m ;
  j ++ ) dp [ i ] [ j ] = Math . max ( ( dp [ i - 1 ] [ j - 1 ] + ( A [ j - 1 ] * B [ i - 1 ] ) ) , dp [ i ] [ j - 1 ] ) ;
  return dp [ n ] [ m ] ;
}
public static void main(String args[]) {
f_gold(new int[]{7,9,22,68},new int[]{14,22,54,58},3,2);
}
}