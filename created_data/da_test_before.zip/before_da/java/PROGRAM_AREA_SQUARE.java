import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class PROGRAM_AREA_SQUARE{
static int f_gold ( int side ) {
  int area = side * side ;
  return area ;
}
public static void main(String args[]) {
f_gold(50);
}
}