import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class CHECK_LINE_PASSES_ORIGIN{
static boolean f_gold ( int x1 , int y1 , int x2 , int y2 ) {
  return ( x1 * ( y2 - y1 ) == y1 * ( x2 - x1 ) ) ;
}
public static void main(String args[]) {
f_gold(1,28,2,56);
}
}