import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class COUNT_PAIRS_WHOSE_PRODUCTS_EXIST_IN_ARRAY_1{
static int f_gold ( int arr [ ] , int n ) {
  int result = 0 ;
  HashSet < Integer > Hash = new HashSet < > ( ) ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) {
    Hash . add ( arr [ i ] ) ;
  }
  for ( int i = 0 ;
  i < n ;
  i ++ ) {
    for ( int j = i + 1 ;
    j < n ;
    j ++ ) {
      int product = arr [ i ] * arr [ j ] ;
      if ( Hash . contains ( product ) ) {
        result ++ ;
      }
    }
  }
  return result ;
}
public static void main(String args[]) {
f_gold(new int[]{7,10,17,17,18,20,27,28,29,29,31,32,41,43,45,46,63,66,69,69,70,75,87,95},17);
}
}