import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class FIND_SUM_NON_REPEATING_DISTINCT_ELEMENTS_ARRAY{
static int f_gold ( int arr [ ] , int n ) {
  int sum = 0 ;
  HashSet < Integer > s = new HashSet < Integer > ( ) ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) {
    if ( ! s . contains ( arr [ i ] ) ) {
      sum += arr [ i ] ;
      s . add ( arr [ i ] ) ;
    }
  }
  return sum ;
}
public static void main(String args[]) {
f_gold(new int[]{5,6,8,10,21,22,27,32,35,36,43,44,46,48,49,55,60,61,69,69,71,72,73,78,88,94},24);
}
}