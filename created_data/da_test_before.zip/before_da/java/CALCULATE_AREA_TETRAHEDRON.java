import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class CALCULATE_AREA_TETRAHEDRON{
static double f_gold ( int side ) {
  double volume = ( Math . pow ( side , 3 ) / ( 6 * Math . sqrt ( 2 ) ) ) ;
  return volume ;
}
public static void main(String args[]) {
f_gold(58);
}
}