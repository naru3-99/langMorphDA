import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class PROGRAM_COUNT_OCCURRENCE_GIVEN_CHARACTER_STRING{
public static int f_gold ( String s , char c ) {
  int res = 0 ;
  for ( int i = 0 ;
  i < s . length ( ) ;
  i ++ ) {
    if ( s . charAt ( i ) == c ) res ++ ;
  }
  return res ;
}
public static void main(String args[]) {
f_gold("mhjnKfd",'l');
}
}