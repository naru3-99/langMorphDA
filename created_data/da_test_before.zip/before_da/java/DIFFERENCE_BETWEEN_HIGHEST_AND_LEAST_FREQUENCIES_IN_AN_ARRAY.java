import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class DIFFERENCE_BETWEEN_HIGHEST_AND_LEAST_FREQUENCIES_IN_AN_ARRAY{
static int f_gold ( int arr [ ] , int n ) {
  Arrays . sort ( arr ) ;
  int count = 0 , max_count = 0 , min_count = n ;
  for ( int i = 0 ;
  i < ( n - 1 ) ;
  i ++ ) {
    if ( arr [ i ] == arr [ i + 1 ] ) {
      count += 1 ;
      continue ;
    }
    else {
      max_count = Math . max ( max_count , count ) ;
      min_count = Math . min ( min_count , count ) ;
      count = 0 ;
    }
  }
  return ( max_count - min_count ) ;
}
public static void main(String args[]) {
f_gold(new int[]{5,15,19,22,28,29,39,46,46,49,51,55,62,69,72,72,72,74,79,92,92,93,95,96},15);
}
}