import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class HOW_CAN_WE_SUM_THE_DIGITS_OF_A_GIVEN_NUMBER_IN_SINGLE_STATEMENT_1{
static int f_gold ( int n ) {
  int sum ;
  for ( sum = 0 ;
  n > 0 ;
  sum += n % 10 , n /= 10 ) ;
  return sum ;
}
public static void main(String args[]) {
f_gold(50);
}
}