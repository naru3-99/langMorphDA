import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MAXIMUM_HEIGHT_OF_TRIANGULAR_ARRANGEMENT_OF_ARRAY_VALUES_1{
static int f_gold ( int a [ ] , int n ) {
  return ( int ) Math . floor ( ( - 1 + Math . sqrt ( 1 + ( 8 * n ) ) ) / 2 ) ;
}
public static void main(String args[]) {
f_gold(new int[]{1,2,2,3,5,6,7,8,8,12,15,16,18,18,20,21,21,22,22,24,24,25,30,35,42,49,52,55,55,63,68,70,72,73,77,80,83,87,87,88,88,94,95,97},22);
}
}