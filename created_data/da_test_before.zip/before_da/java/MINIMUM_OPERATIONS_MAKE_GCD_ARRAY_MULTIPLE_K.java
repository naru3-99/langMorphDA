import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MINIMUM_OPERATIONS_MAKE_GCD_ARRAY_MULTIPLE_K{
static int f_gold ( int a [ ] , int n , int k ) {
  int result = 0 ;
  for ( int i = 0 ;
  i < n ;
  ++ i ) {
    if ( a [ i ] != 1 && a [ i ] > k ) {
      result = result + Math . min ( a [ i ] % k , k - a [ i ] % k ) ;
    }
    else {
      result = result + k - a [ i ] ;
    }
  }
  return result ;
}
public static void main(String args[]) {
f_gold(new int[]{3,7,27,32,36,37,44,48,50,64,86},5,10);
}
}