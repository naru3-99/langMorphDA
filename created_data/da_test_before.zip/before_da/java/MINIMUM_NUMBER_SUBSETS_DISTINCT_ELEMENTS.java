import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MINIMUM_NUMBER_SUBSETS_DISTINCT_ELEMENTS{
public static int f_gold ( int ar [ ] , int n ) {
  int res = 0 ;
  Arrays . sort ( ar ) ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) {
    int count = 1 ;
    for ( ;
    i < n - 1 ;
    i ++ ) {
      if ( ar [ i ] == ar [ i + 1 ] ) count ++ ;
      else break ;
    }
    res = Math . max ( res , count ) ;
  }
  return res ;
}
public static void main(String args[]) {
f_gold(new int[]{1,2,5,8,16,21,21,22,23,26,26,27,27,29,31,33,36,37,37,38,42,45,47,50,57,58,60,60,62,63,66,66,76,84,84,88,96,99},25);
}
}