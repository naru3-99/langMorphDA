import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class FIRST_UPPERCASE_LETTER_IN_A_STRING_ITERATIVE_AND_RECURSIVE{
static char f_gold ( String str ) {
  for ( int i = 0 ;
  i < str . length ( ) ;
  i ++ ) if ( Character . isUpperCase ( str . charAt ( i ) ) ) return str . charAt ( i ) ;
  return 0 ;
}
public static void main(String args[]) {
f_gold("pH");
}
}