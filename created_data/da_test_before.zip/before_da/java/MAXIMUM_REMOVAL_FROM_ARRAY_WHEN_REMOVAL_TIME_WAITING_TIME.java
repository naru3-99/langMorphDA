import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MAXIMUM_REMOVAL_FROM_ARRAY_WHEN_REMOVAL_TIME_WAITING_TIME{
static int f_gold ( int arr [ ] , int n ) {
  int count = 0 ;
  int cummulative_sum = 0 ;
  Arrays . sort ( arr ) ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) {
    if ( arr [ i ] >= cummulative_sum ) {
      count ++ ;
      cummulative_sum += arr [ i ] ;
    }
  }
  return count ;
}
public static void main(String args[]) {
f_gold(new int[]{7,33,34,42,42,45,73},5);
}
}