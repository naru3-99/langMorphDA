import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MAXIMUM_NUMBER_CHOCOLATES_DISTRIBUTED_EQUALLY_AMONG_K_STUDENTS{
static int f_gold ( int arr [ ] , int n , int k ) {
  HashMap < Integer , Integer > um = new HashMap < Integer , Integer > ( ) ;
  int [ ] sum = new int [ n ] ;
  int curr_rem ;
  int maxSum = 0 ;
  sum [ 0 ] = arr [ 0 ] ;
  for ( int i = 1 ;
  i < n ;
  i ++ ) sum [ i ] = sum [ i - 1 ] + arr [ i ] ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) {
    curr_rem = sum [ i ] % k ;
    if ( curr_rem == 0 ) {
      if ( maxSum < sum [ i ] ) maxSum = sum [ i ] ;
    }
    else if ( ! um . containsKey ( curr_rem ) ) um . put ( curr_rem , i ) ;
    else if ( maxSum < ( sum [ i ] - sum [ um . get ( curr_rem ) ] ) ) maxSum = sum [ i ] - sum [ um . get ( curr_rem ) ] ;
  }
  return ( maxSum / k ) ;
}
public static void main(String args[]) {
f_gold(new int[]{2,3,8,8,12,14,23,25,25,27,27,29,40,42,49,52,52,54,56,57,61,68,74,77,81,82,83,84,85,85,85,87,87,88,88,90,92,96,96},27,32);
}
}