import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MAXIMUM_SUBSEQUENCE_SUM_SUCH_THAT_NO_THREE_ARE_CONSECUTIVE{
static int f_gold ( int arr [ ] , int n ) {
  int sum [ ] = new int [ n ] ;
  if ( n >= 1 ) sum [ 0 ] = arr [ 0 ] ;
  if ( n >= 2 ) sum [ 1 ] = arr [ 0 ] + arr [ 1 ] ;
  if ( n > 2 ) sum [ 2 ] = Math . max ( sum [ 1 ] , Math . max ( arr [ 1 ] + arr [ 2 ] , arr [ 0 ] + arr [ 2 ] ) ) ;
  for ( int i = 3 ;
  i < n ;
  i ++ ) sum [ i ] = Math . max ( Math . max ( sum [ i - 1 ] , sum [ i - 2 ] + arr [ i ] ) , arr [ i ] + arr [ i - 1 ] + sum [ i - 3 ] ) ;
  return sum [ n - 1 ] ;
}
public static void main(String args[]) {
f_gold(new int[]{5,6,8,9,10,10,16,17,17,20,21,22,23,28,29,32,36,37,40,41,42,43,47,47,48,48,49,49,52,52,53,59,61,64,65,79,79,81,87,91,92,98},35);
}
}