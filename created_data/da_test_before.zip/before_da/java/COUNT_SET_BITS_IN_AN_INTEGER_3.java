import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class COUNT_SET_BITS_IN_AN_INTEGER_3{
public static int f_gold ( int n ) {
  if ( n == 0 ) return 0 ;
  else return 1 + f_gold ( n & ( n - 1 ) ) ;
}
public static void main(String args[]) {
f_gold(6);
}
}