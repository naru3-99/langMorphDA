import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MAXIMIZE_SUM_ARRII{
static int f_gold ( int arr [ ] , int n ) {
  Arrays . sort ( arr ) ;
  int sum = 0 ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) sum += ( arr [ i ] * i ) ;
  return sum ;
}
public static void main(String args[]) {
f_gold(new int[]{2,3,4,6,7,8,9,11,19,23,24,30,31,31,32,41,43,43,46,47,50,50,51,53,57,63,63,69,73,74,79,80,81,81,85,86,88,92,93,95,98,99},22);
}
}