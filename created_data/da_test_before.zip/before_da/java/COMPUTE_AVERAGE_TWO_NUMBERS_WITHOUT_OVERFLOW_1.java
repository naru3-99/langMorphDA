import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class COMPUTE_AVERAGE_TWO_NUMBERS_WITHOUT_OVERFLOW_1{
static int f_gold ( int a , int b ) {
  return ( a / 2 ) + ( b / 2 ) + ( ( a % 2 + b % 2 ) / 2 ) ;
}
public static void main(String args[]) {
f_gold(9,81);
}
}