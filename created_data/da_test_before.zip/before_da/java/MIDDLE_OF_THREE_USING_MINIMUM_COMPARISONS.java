import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MIDDLE_OF_THREE_USING_MINIMUM_COMPARISONS{
public static int f_gold ( int a , int b , int c ) {
  if ( ( a < b && b < c ) || ( c < b && b < a ) ) return b ;
  else if ( ( b < a && a < c ) || ( c < a && a < b ) ) return a ;
  else return c ;
}
public static void main(String args[]) {
f_gold(56,5,82);
}
}