import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class LEXICOGRAPHICAL_MAXIMUM_SUBSTRING_STRING{
static String f_gold ( String str ) {
  String mx = "" ;
  for ( int i = 0 ;
  i < str . length ( ) ;
  ++ i ) {
    if ( mx . compareTo ( str . substring ( i ) ) <= 0 ) {
      mx = str . substring ( i ) ;
    }
  }
  return mx ;
}
public static void main(String args[]) {
f_gold("HCoAefoaan");
}
}