import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class DYNAMIC_PROGRAMMING_SET_14_MAXIMUM_SUM_INCREASING_SUBSEQUENCE{
static int f_gold ( int arr [ ] , int n ) {
  int i , j , max = 0 ;
  int msis [ ] = new int [ n ] ;
  for ( i = 0 ;
  i < n ;
  i ++ ) msis [ i ] = arr [ i ] ;
  for ( i = 1 ;
  i < n ;
  i ++ ) for ( j = 0 ;
  j < i ;
  j ++ ) if ( arr [ i ] > arr [ j ] && msis [ i ] < msis [ j ] + arr [ i ] ) msis [ i ] = msis [ j ] + arr [ i ] ;
  for ( i = 0 ;
  i < n ;
  i ++ ) if ( max < msis [ i ] ) max = msis [ i ] ;
  return max ;
}
public static void main(String args[]) {
f_gold(new int[]{4,5,7,12,23,31,31,45,47,60,67,70,84,85,91,96},11);
}
}