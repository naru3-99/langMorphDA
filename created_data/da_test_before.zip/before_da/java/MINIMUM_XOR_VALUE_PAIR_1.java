import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MINIMUM_XOR_VALUE_PAIR_1{
static int f_gold ( int arr [ ] , int n ) {
  Arrays . parallelSort ( arr ) ;
  int minXor = Integer . MAX_VALUE ;
  int val = 0 ;
  for ( int i = 0 ;
  i < n - 1 ;
  i ++ ) {
    val = arr [ i ] ^ arr [ i + 1 ] ;
    minXor = Math . min ( minXor , val ) ;
  }
  return minXor ;
}
public static void main(String args[]) {
f_gold(new int[]{8,11,12,27,32,32,36,56,57,66,68,70,74,78,82,83,96},10);
}
}