import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MINIMUM_NUMBER_PLATFORMS_REQUIRED_RAILWAYBUS_STATION{
static int f_gold ( int arr [ ] , int dep [ ] , int n ) {
  Arrays . sort ( arr ) ;
  Arrays . sort ( dep ) ;
  int plat_needed = 1 , result = 1 ;
  int i = 1 , j = 0 ;
  while ( i < n && j < n ) {
    if ( arr [ i ] <= dep [ j ] ) {
      plat_needed ++ ;
      i ++ ;
      if ( plat_needed > result ) result = plat_needed ;
    }
    else {
      plat_needed -- ;
      j ++ ;
    }
  }
  return result ;
}
public static void main(String args[]) {
f_gold(new int[]{8,24,28,64,75,86,93,95},new int[]{19,30,41,51,62,68,85,96},6);
}
}