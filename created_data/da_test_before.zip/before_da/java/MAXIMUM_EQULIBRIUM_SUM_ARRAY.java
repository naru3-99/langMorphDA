import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MAXIMUM_EQULIBRIUM_SUM_ARRAY{
static int f_gold ( int [ ] arr , int n ) {
  int res = Integer . MIN_VALUE ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) {
    int prefix_sum = arr [ i ] ;
    for ( int j = 0 ;
    j < i ;
    j ++ ) prefix_sum += arr [ j ] ;
    int suffix_sum = arr [ i ] ;
    for ( int j = n - 1 ;
    j > i ;
    j -- ) suffix_sum += arr [ j ] ;
    if ( prefix_sum == suffix_sum ) res = Math . max ( res , prefix_sum ) ;
  }
  return res ;
}
public static void main(String args[]) {
f_gold(new int[]{3,3,9,19,22,27,32,41,45,63,66,67,81,91},13);
}
}