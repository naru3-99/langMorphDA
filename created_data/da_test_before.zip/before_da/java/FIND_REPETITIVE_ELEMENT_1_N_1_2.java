import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class FIND_REPETITIVE_ELEMENT_1_N_1_2{
static int f_gold ( int arr [ ] , int n ) {
  int res = 0 ;
  for ( int i = 0 ;
  i < n - 1 ;
  i ++ ) res = res ^ ( i + 1 ) ^ arr [ i ] ;
  res = res ^ arr [ n - 1 ] ;
  return res ;
}
public static void main(String args[]) {
f_gold(new int[]{2,2,4,5,5,7,7,7,8,11,14,15,18,19,20,25,25,29,29,31,32,32,33,38,42,48,52,55,60,61,63,71,74,78,82,82,84,84,87,87,88,90,93,94,94},31);
}
}