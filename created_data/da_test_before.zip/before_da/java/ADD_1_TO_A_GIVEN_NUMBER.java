import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class ADD_1_TO_A_GIVEN_NUMBER{
static int f_gold ( int x ) {
  int m = 1 ;
  while ( ( int ) ( x & m ) >= 1 ) {
    x = x ^ m ;
    m <<= 1 ;
  }
  x = x ^ m ;
  return x ;
}
public static void main(String args[]) {
f_gold(96);
}
}