import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MAXIMUM_POSSIBLE_SUM_WINDOW_ARRAY_ELEMENTS_WINDOW_ARRAY_UNIQUE{
static int f_gold ( int A [ ] , int B [ ] , int n ) {
  Set < Integer > mp = new HashSet < Integer > ( ) ;
  int result = 0 ;
  int curr_sum = 0 , curr_begin = 0 ;
  for ( int i = 0 ;
  i < n ;
  ++ i ) {
    while ( mp . contains ( A [ i ] ) ) {
      mp . remove ( A [ curr_begin ] ) ;
      curr_sum -= B [ curr_begin ] ;
      curr_begin ++ ;
    }
    mp . add ( A [ i ] ) ;
    curr_sum += B [ i ] ;
    result = Integer . max ( result , curr_sum ) ;
  }
  return result ;
}
public static void main(String args[]) {
f_gold(new int[]{4,8,10,10,16,23,33,36,43,47,50,55,56,72,84,85,86,86,88,90,92,99},new int[]{8,26,30,35,45,47,55,56,59,61,64,66,67,69,73,77,78,81,82,85,86,99},20);
}
}