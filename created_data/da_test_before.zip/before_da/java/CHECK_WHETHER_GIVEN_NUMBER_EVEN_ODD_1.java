import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class CHECK_WHETHER_GIVEN_NUMBER_EVEN_ODD_1{
public static boolean f_gold ( int n ) {
  if ( ( n & 1 ) == 0 ) return true ;
  else return false ;
}
public static void main(String args[]) {
f_gold(57);
}
}