import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class PROGRAM_DECIMAL_BINARY_CONVERSION_2{
static int f_gold ( int N ) {
  int B_Number = 0 ;
  int cnt = 0 ;
  while ( N != 0 ) {
    int rem = N % 2 ;
    double c = Math . pow ( 10 , cnt ) ;
    B_Number += rem * c ;
    N /= 2 ;
    cnt ++ ;
  }
  return B_Number ;
}
public static void main(String args[]) {
f_gold(18);
}
}