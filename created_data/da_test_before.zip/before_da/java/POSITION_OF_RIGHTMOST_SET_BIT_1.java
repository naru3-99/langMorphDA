import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class POSITION_OF_RIGHTMOST_SET_BIT_1{
static int f_gold ( int n ) {
  int position = 1 ;
  int m = 1 ;
  while ( ( n & m ) == 0 ) {
    m = m << 1 ;
    position ++ ;
  }
  return position ;
}
public static void main(String args[]) {
f_gold(17);
}
}