import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class FIND_WHETHER_A_GIVEN_NUMBER_IS_A_POWER_OF_4_OR_NOT_2{
static boolean f_gold ( int n ) {
  return n != 0 && ( ( n & ( n - 1 ) ) == 0 ) && ( n & 0xAAAAAAAA ) == 0 ;
}
public static void main(String args[]) {
f_gold(1);
}
}