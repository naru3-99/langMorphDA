import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class FIND_UNIT_DIGIT_X_RAISED_POWER_Y_1{
static int f_gold ( int x , int y ) {
  x = x % 10 ;
  if ( y != 0 ) y = y % 4 + 4 ;
  return ( ( ( int ) ( Math . pow ( x , y ) ) ) % 10 ) ;
}
public static void main(String args[]) {
f_gold(37,17);
}
}