import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MAXIMUM_AVERAGE_SUM_PARTITION_ARRAY{
static double f_gold ( int [ ] A , int K ) {
  int n = A . length ;
  double [ ] pre_sum = new double [ n + 1 ] ;
  pre_sum [ 0 ] = 0 ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) pre_sum [ i + 1 ] = pre_sum [ i ] + A [ i ] ;
  double [ ] dp = new double [ n ] ;
  double sum = 0 ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) dp [ i ] = ( pre_sum [ n ] - pre_sum [ i ] ) / ( n - i ) ;
  for ( int k = 0 ;
  k < K - 1 ;
  k ++ ) for ( int i = 0 ;
  i < n ;
  i ++ ) for ( int j = i + 1 ;
  j < n ;
  j ++ ) dp [ i ] = Math . max ( dp [ i ] , ( pre_sum [ j ] - pre_sum [ i ] ) / ( j - i ) + dp [ j ] ) ;
  return dp [ 0 ] ;
}
public static void main(String args[]) {
f_gold(new int[]{4,11,14,27,32,37,39,49,52,53,57,62,67,67,68,69,76,77,78,81,85,85,87,91,91,91,99,99,99},24);
}
}