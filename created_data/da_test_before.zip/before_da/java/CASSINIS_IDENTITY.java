import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class CASSINIS_IDENTITY{
static int f_gold ( int n ) {
  return ( n & 1 ) != 0 ? - 1 : 1 ;
}
public static void main(String args[]) {
f_gold(67);
}
}