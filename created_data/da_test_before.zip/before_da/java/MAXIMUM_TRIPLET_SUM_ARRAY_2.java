import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class MAXIMUM_TRIPLET_SUM_ARRAY_2{
static int f_gold ( int arr [ ] , int n ) {
  int maxA = - 100000000 , maxB = - 100000000 ;
  int maxC = - 100000000 ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) {
    if ( arr [ i ] > maxA ) {
      maxC = maxB ;
      maxB = maxA ;
      maxA = arr [ i ] ;
    }
    else if ( arr [ i ] > maxB ) {
      maxC = maxB ;
      maxB = arr [ i ] ;
    }
    else if ( arr [ i ] > maxC ) maxC = arr [ i ] ;
  }
  return ( maxA + maxB + maxC ) ;
}
public static void main(String args[]) {
f_gold(new int[]{4,7,12,21,22,25,27,28,28,31,32,32,41,45,47,51,53,60,61,61,63,71,74,82,83,85,88,92,96,96},28);
}
}