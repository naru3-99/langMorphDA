import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class FIND_LARGEST_D_IN_ARRAY_SUCH_THAT_A_B_C_D{
static int f_gold ( int [ ] S , int n ) {
  boolean found = false ;
  Arrays . sort ( S ) ;
  for ( int i = n - 1 ;
  i >= 0 ;
  i -- ) {
    for ( int j = 0 ;
    j < n ;
    j ++ ) {
      if ( i == j ) continue ;
      for ( int k = j + 1 ;
      k < n ;
      k ++ ) {
        if ( i == k ) continue ;
        for ( int l = k + 1 ;
        l < n ;
        l ++ ) {
          if ( i == l ) continue ;
          if ( S [ i ] == S [ j ] + S [ k ] + S [ l ] ) {
            found = true ;
            return S [ i ] ;
          }
        }
      }
    }
  }
  if ( found == false ) return Integer . MAX_VALUE ;
  return - 1 ;
}
public static void main(String args[]) {
f_gold(new int[]{8,12,14,15,16,20,27,28,29,30,35,41,46,51,53,55,55,58,63,64,72,73,75,75,75,82,82,86,89,91,92,94,95,95,97,97,98},24);
}
}