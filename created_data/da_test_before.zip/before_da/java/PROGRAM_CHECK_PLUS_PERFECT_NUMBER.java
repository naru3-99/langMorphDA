import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class PROGRAM_CHECK_PLUS_PERFECT_NUMBER{
static boolean f_gold ( int x ) {
  int temp = x ;
  int n = 0 ;
  while ( x != 0 ) {
    x /= 10 ;
    n ++ ;
  }
  x = temp ;
  int sum = 0 ;
  while ( x != 0 ) {
    sum += Math . pow ( x % 10 , n ) ;
    x /= 10 ;
  }
  return ( sum == temp ) ;
}
public static void main(String args[]) {
f_gold(371);
}
}