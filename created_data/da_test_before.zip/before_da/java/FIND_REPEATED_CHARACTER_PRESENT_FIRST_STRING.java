import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class FIND_REPEATED_CHARACTER_PRESENT_FIRST_STRING{
static int f_gold ( String s ) {
  int p = - 1 , i , j ;
  for ( i = 0 ;
  i < s . length ( ) ;
  i ++ ) {
    for ( j = i + 1 ;
    j < s . length ( ) ;
    j ++ ) {
      if ( s . charAt ( i ) == s . charAt ( j ) ) {
        p = i ;
        break ;
      }
    }
    if ( p != - 1 ) break ;
  }
  return p ;
}
public static void main(String args[]) {
f_gold("ORXMflacQFBv");
}
}