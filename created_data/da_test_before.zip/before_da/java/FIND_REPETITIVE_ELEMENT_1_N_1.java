import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class FIND_REPETITIVE_ELEMENT_1_N_1{
static int f_gold ( int [ ] arr , int n ) {
  int sum = 0 ;
  for ( int i = 0 ;
  i < n ;
  i ++ ) sum += arr [ i ] ;
  return sum - ( ( ( n - 1 ) * n ) / 2 ) ;
}
public static void main(String args[]) {
f_gold(new int[]{4,8,27,34,39,42,43,54,72},5);
}
}