import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class COMPUTE_MODULUS_DIVISION_BY_A_POWER_OF_2_NUMBER{
static int f_gold ( int n , int d ) {
  return ( n & ( d - 1 ) ) ;
}
public static void main(String args[]) {
f_gold(54,59);
}
}