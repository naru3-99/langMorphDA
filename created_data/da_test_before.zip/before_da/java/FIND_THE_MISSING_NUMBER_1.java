import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class FIND_THE_MISSING_NUMBER_1{
static int f_gold ( int a [ ] , int n ) {
  int total = 1 ;
  for ( int i = 2 ;
  i <= ( n + 1 ) ;
  i ++ ) {
    total += i ;
    total -= a [ i - 2 ] ;
  }
  return total ;
}
public static void main(String args[]) {
f_gold(new int[]{13,27,46,59,62,82,92},6);
}
}