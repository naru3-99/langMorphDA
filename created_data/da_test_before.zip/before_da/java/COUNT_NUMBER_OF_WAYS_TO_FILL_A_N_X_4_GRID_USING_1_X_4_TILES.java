import java.util. *;
import java.util.stream.*;
import java.lang.*;
public class COUNT_NUMBER_OF_WAYS_TO_FILL_A_N_X_4_GRID_USING_1_X_4_TILES{
static int f_gold ( int n ) {
  int [ ] dp = new int [ n + 1 ] ;
  dp [ 0 ] = 0 ;
  for ( int i = 1 ;
  i <= n ;
  i ++ ) {
    if ( i >= 1 && i <= 3 ) dp [ i ] = 1 ;
    else if ( i == 4 ) dp [ i ] = 2 ;
    else {
      dp [ i ] = dp [ i - 1 ] + dp [ i - 4 ] ;
    }
  }
  return dp [ n ] ;
}
public static void main(String args[]) {
f_gold(61);
}
}